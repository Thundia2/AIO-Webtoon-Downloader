# Tablet ↔ PC Chapter-Count Delta — Findings

Companion to `REDOWNLOAD_FOR_KOMIKKU.md`. For every push-from-PC series whose
tablet and PC chapter counts disagree, this document explains **why**.

**Snapshot:** 2026-05-23.
**Source data:** `tablet_files.txt` (ADB dump) + live PC scan of
`C:\Users\legoc\OneDrive\Belgeler\AIO-Webtoon-Downloader\mangas`.
**Analysis script:** `_delta_findings.py` → `delta_findings.json`.

> "Delta" here is `PC unique chapter labels − tablet unique chapter labels`.
> Negative means tablet has more, positive means PC has more.

## TL;DR — answer to "is it because of partial chapters?"

**Largely yes**, for negative deltas in the [-50, -1] range. The dominant
cause is sub-chapter splits (`.1` / `.5` style scan entries that mangafire
emits and the PC's AIO downloader either consolidates or skips), often
combined with a tablet-side Ch 0 prologue that PC starts at Ch 1.

For larger negative deltas (≤ -85) the cause is usually **a different
chapter-numbering system** — tablet uses mangafire's running scan-count, PC
uses the published chapter count from a different source. That's the same
class of mismatch we already moved JoJo Parts 4 & 6 to the fresh-download
list for, and JoJo Part 5 + Is the Order a Rabbit fall in this bucket too.

For positive deltas, the cause is almost always **PC has been re-downloaded
more recently than the tablet snapshot**, so the PC library has chapters past
the tablet's high-water mark.

## Distribution of causes

Each series is tagged with its dominant cause(s); a series can appear in more
than one bucket if it has compound causes (e.g. Bleach = "Ch 0 prologue" +
"sub-chapter splits").

| Cause | Series count | Typical Δ |
|--|--:|--|
| Sub-chapter splits only (tablet has `.1`/`.5`, PC consolidated)            | 12 | -1 to -44 |
| Tablet Ch 0 prologue + sub-chapter splits                                  |  6 | -3 to -54 |
| Tablet has Berserk-style fine prologue split (`0.01`–`0.6`)                |  1 | -11 |
| PC ahead (newer integer chapters than tablet)                              | 10 | +1 to +235 |
| Tablet ahead (tablet snapshot has integers PC doesn't, PC out of date)     |  2 | -5, -112 |
| Different chapter numbering systems (mangafire scan vs published)          |  2 | -87, -168 |
| Mid-range integer mismatch (one side has a chapter the other doesn't)      |  6 | -54 to +13 |
| Other / minor mixes                                                        |  4 | ±1 to ±5 |

(Counts overlap — a single series may carry several tags.)

## Implications for the push step

- **"Sub-chapter splits only"**: Pushing PC → tablet drops `N` mangafire
  scan-split entries. Usually these `.1`/`.5` files are partial-chapter scans
  (single-page omakes, mid-chapter cliffhanger splits) rather than separate
  content, so losing them is acceptable. **Spot-check one of these per series
  before mass-pushing** to confirm they're scan artifacts, not actual content.
- **"Tablet Ch 0 prologue"**: pushing PC keeps the prologue *if* PC has
  `Ch.000`, drops it otherwise. Berserk and a couple of others have PC's
  `Ch.000` — fine. For Bleach, SPY×FAMILY, CØDEBREAKER, Konosuba, Bungo Stray
  Dogs, Undead Unluck — PC starts at Ch 1, so the tablet's Ch 0 is lost.
- **"PC ahead"**: pushing is a strict upgrade.
- **"Tablet ahead"**: pushing **loses real chapters**. Re-download PC for
  these before pushing — explicit list in the corresponding section below.
- **"Different chapter numbering"**: pushing PC gives the published-chapter
  view, drops the mangafire scan-numbering. JoJo Part 5 was kept as a push
  per user direction; Is the Order a Rabbit shows the same issue.
- **"Mid-range integer mismatch"**: small number of chapters one side has and
  the other doesn't; flagged per-series below so you can decide whether to
  refresh.

---

## Per-series findings

Ordered by `|Δ|` descending. Tablet-only and PC-only label samples are
truncated to first/last 3 when the list is long; full lists are in
`delta_findings.json`.

### Δ +235: Sakamoto Days
**Tablet 23 → PC 258.** PC has been re-downloaded recently and is *vastly*
ahead. PC has 235 chapters the tablet doesn't, including 1 chapter (21) in
the tablet's range — tablet skipped Ch 21 for some reason.

- **Cause:** PC ahead (newer chapters).
- **Push outcome:** strict upgrade; tablet's Ch 21 hole gets filled.

### Δ -168: JoJo's Bizarre Adventure Part 5 Golden Wind
**Tablet 323 → PC 155.** Tablet uses mangafire scan-numbering (integer chapter
labels go up to 594, 155 of those are unique to tablet) plus 13 sub-chapter
splits. PC's "Ougon no Kaze" folder uses published-chapter numbering 1–155.

- **Cause:** different chapter numbering systems (mangafire vs MangaDex JP).
- **Push outcome:** loses tablet's scan-numbering view (155 integers + 13
  sub-chapter splits) in favor of PC's published chapters. Same class of
  issue as JoJo Parts 4 & 6 — kept as push per user direction.

### Δ +147: Rinjin-chan ga Shinpai
**Tablet 5 → PC 152.** PC has 147 more chapters: 143 integers + 4 sub-chapters
beyond tablet's max of 5.

- **Cause:** PC ahead (PC was re-downloaded after tablet snapshot).
- **Push outcome:** strict upgrade.

### Δ -112: Horimiya
**Tablet 254 → PC 142.** Tablet is **ahead** here: 74 additional integer
chapters (128–201) PC doesn't have, plus 38 sub-chapter splits (`6.1`,
`13.1`, ..., `125.7`, `125.8`, `130.1`).

- **Cause:** tablet ahead + sub-chapter splits.
- **Push outcome:** loses chapters 128–201 (real content) + 38 sub-chapter
  scans. **Re-download Horimiya on PC before pushing.**

### Δ -90: Fly Me to the Moon
**Tablet 460 → PC 370.** Mixed: tablet has a 4-chapter prologue
(`0.1`–`0.4`), 89 sub-chapter splits in the 1.x–305.x range, and 2 integers
(168, 215) PC doesn't. PC has 1 integer (346) past tablet's range.

- **Cause:** tablet prologue + sub-chapter splits + 2 mid-range gaps; PC
  marginally ahead.
- **Push outcome:** drops prologue, drops sub-chapter splits, drops Ch 168 &
  215. PC has 1 newer chapter to gain. Probably worth re-downloading PC to
  pick up Ch 168 & 215 first.

### Δ -87: Is the Order a Rabbit (Gochuumon wa Usagi desu ka)
**Tablet 184 → PC 97.** Tablet has 91 integers (15–106) PC doesn't have, plus
1 sub-chapter (13.5). PC has 5 integers (182–186) past tablet's range.

- **Cause:** different chapter numbering systems (tablet's mangafire splits a
  published chapter into many parts, PC's MangaDex source uses the published
  numbering). PC also marginally ahead.
- **Push outcome:** drops tablet's 91 mangafire scan-splits; gains 5 newer
  chapters. Effectively a re-numbering. Treat like JoJo Part 5.

### Δ +78: Chainsaw Man
**Tablet 215 → PC 293.** PC has 17 integers + 61 sub-chapters past tablet,
all from chapter 126.1 onwards.

- **Cause:** PC ahead with continuation through Part 2 (which uses many
  sub-chapter splits in its current run).
- **Push outcome:** strict upgrade.

### Δ -54: One-Punch Man (Official)
**Tablet 299 → PC 245.** Tablet has 71 sub-chapter splits PC doesn't. PC has
16 integers + 1 sub-chapter PC has that tablet doesn't (mid-range gaps where
the official One-Punch Man release added re-drawn chapters).

- **Cause:** tablet sub-chapter splits + PC mid-range integer extras.
- **Push outcome:** drops 71 mangafire splits; gains 17 chapters. Net loss of
  ~54 file count, but probably similar content coverage; the PC integers are
  the canonical "Official" remake chapters.

### Δ -54: SPY×FAMILY
**Tablet 204 → PC 150.** Tablet has Ch 0 + Ch 0.1 prologue + 58 sub-chapter
splits (`5.5`, `8.5`, `11.1`, ...). PC has 5 chapters (112, 131–134) past
tablet plus 1 mid-range integer.

- **Cause:** tablet Ch 0 prologue + sub-chapter splits; PC marginally ahead.
- **Push outcome:** drops prologue (tablet's Ch 0/0.1) + scan-split bonus
  pages; gains 5 newer chapters.

### Δ +51: No Longer Allowed In Another World
**Tablet 11 → PC 62.** PC has 51 integers past tablet's max of 11.

- **Cause:** PC ahead.
- **Push outcome:** strict upgrade.

### Δ -47: Bleach
**Tablet 742 → PC 694.** Tablet has Ch 0 ("Bleach Ch 0.pdf" — likely the
prologue / zero-issue) + 46 sub-chapter splits (`1.1`, `25.2`, `61.1`,
`88.1`, `88.2`, `107.1`, `130.1`, `168.1`, ..., `686.5`). PC starts at Ch 1.

- **Cause:** tablet Ch 0 prologue + many sub-chapter splits across the run.
- **Push outcome:** drops the Ch 0 prologue + 46 mangafire bonus splits.

### Δ -46: A Certain Scientific Railgun (PC: Toaru ... Railgun)
**Tablet 235 → PC 189.** Tablet has 1 integer (143) + 51 sub-chapter splits PC
doesn't. PC has 6 mid-range integers (158, 164, 165, 168, 169, 170) tablet
doesn't.

- **Cause:** tablet sub-chapter splits + small mid-range integer mismatch
  both ways.
- **Push outcome:** drops 51 mangafire splits + Ch 143; gains 6 PC integers.

### Δ -44: Solo Leveling
**Tablet 245 → PC 201.** **Textbook "all sub-chapters" case:** every
tablet-only label is a `.1` (occasionally `.2`) sub-chapter. PC has 0 extras.

- **Cause:** pure sub-chapter splits — the cleanest example of the
  "partial chapters" pattern.
- **Push outcome:** drops 44 mangafire scan splits, content otherwise
  identical.

### Δ -42: JoJo's Bizarre Adventure Part 3 Stardust Crusaders
**Tablet 445 → PC 403.** Tablet has 52 sub-chapter splits (mostly `.1`/`.2`/`.3`
style scan continuations). PC has 10 sub-chapter splits (all `.5` style —
likely 1.5 / 2.5 published bonus/omake chapters).

- **Cause:** both sides have sub-chapter conventions but different ones
  (mangafire scan-splits vs published `.5` bonus chapters).
- **Push outcome:** trades 52 scan splits for 10 omake chapters.

### Δ +35: Pandora Seven
**Tablet 19 → PC 54.** PC has 33 integers + 2 sub-chapters past tablet. Also
note: tablet starts at Ch 4, PC starts at Ch 1 — tablet snapshot was missing
the first 3 chapters.

- **Cause:** PC ahead + tablet missing early chapters.
- **Push outcome:** strict upgrade.

### Δ -30: Bungo Stray Dogs
**Tablet 167 → PC 137.** Tablet has Ch 0 + 29 sub-chapter splits (`0.1`,
`12.1`, `33.1`, `33.2`, ...). PC starts at Ch 1.

- **Cause:** tablet Ch 0 prologue + sub-chapter splits.
- **Push outcome:** drops prologue + 29 scan splits.

### Δ -21: Komi Can't Communicate
**Tablet 526 → PC 505.** Tablet has 23 sub-chapter splits (mostly `.5`s like
`19.5`, `34.5`, `47.5`). PC has 2 `.5` sub-chapters tablet doesn't (`388.5`,
`442.5`).

- **Cause:** both sides have `.5` extras but the sets are different — neither
  source is a strict superset.
- **Push outcome:** trades 23 tablet `.5`s for 2 PC `.5`s.

### Δ +21: Makeine (PC: Too Many Losing Heroines!)
**Tablet 4 → PC 25.** PC has 20 integers + 1 sub-chapter past tablet.

- **Cause:** PC ahead.
- **Push outcome:** strict upgrade.

### Δ -19: Undead Unluck
**Tablet 259 → PC 240.** Tablet has Ch 0 + 18 sub-chapter splits.

- **Cause:** tablet Ch 0 prologue + sub-chapter splits.
- **Push outcome:** drops prologue + 18 splits.

### Δ -15: That Time I Got Reincarnated as a Slime
**Tablet 183 → PC 167.** Tablet has 17 sub-chapter splits. PC has 1 integer +
1 sub-chapter tablet doesn't.

- **Cause:** tablet sub-chapter splits; PC has minor extras.
- **Push outcome:** drops 17 splits, gains 2.

### Δ +13: Record of Ragnarok (PC: Shuumatsu no Valkyrie)
**Tablet 119 → PC 132.** Tablet has 2 sub-chapter splits PC doesn't. PC has 9
integers + 6 sub-chapters past tablet.

- **Cause:** PC mostly ahead + tablet has 2 leftover splits.
- **Push outcome:** mostly an upgrade.

### Δ -13: You and I are Polar Opposites
**Tablet 80 → PC 67.** Pure sub-chapter case: 13 tablet-only sub-chapters,
0 PC-only.

- **Cause:** pure sub-chapter splits.
- **Push outcome:** drops 13 mangafire splits.

### Δ -11: Berserk
**Tablet 400 → PC 389.** *Special case:* the Berserk tablet copy uses
"Chap 0.01 Black Swordsman Arc.pdf" through "Chap 0.6 Golden Age (7).pdf"
(15 fine-grained prologue chunks). PC has just `Ch.000 - Prologue 10` +
`Ch.000.7 - Golden Age (8)` and starts the main numbering at Ch 1. So tablet
splits the prologue into 15 sub-units while PC consolidates it into 2.
Additionally PC has 3 mid-series `.5` chapters tablet lacks (`114.5`,
`350.5`, `356.5`).

- **Cause:** completely different prologue-splitting conventions + PC has
  3 `.5` extras.
- **Push outcome:** drops the 15-chunk prologue split for PC's 2-chunk
  prologue; gains 3 `.5` mid-series chapters. Content-wise probably
  equivalent.

### Δ -9: 'Tis Time for Torture, Princess
**Tablet 294 → PC 285.** 9 tablet-only sub-chapter splits, 0 PC-only.

- **Cause:** pure sub-chapter splits.

### Δ -8: My Youth Romantic Comedy Is Wrong, As I Expected
**Tablet 97 → PC 89.** 8 tablet-only sub-chapter splits, 0 PC-only.

- **Cause:** pure sub-chapter splits.

### Δ -7: Demon Slayer Kimetsu no Yaiba
**Tablet 244 → PC 237.** 8 tablet-only sub-chapter splits, 1 PC-only mid-range
integer.

- **Cause:** tablet sub-chapter splits + 1 PC mid-range gap.

### Δ +6: A Couple of Cuckoos
**Tablet 291 → PC 297.** PC has 6 integers past tablet's max of 290.

- **Cause:** PC ahead.

### Δ +5: Attack on Titan
**Tablet 142 → PC 147.** Tablet has 2 sub-chapters PC doesn't. PC has 5
integers + 2 sub-chapters past tablet.

- **Cause:** PC mostly ahead.

### Δ +5: JoJo's Bizarre Adventure Part 1 Phantom Blood
**Tablet 44 → PC 49.** PC has 1 integer + 4 sub-chapters tablet doesn't.

- **Cause:** PC has bonus / .5 chapters (likely volume-special omake) tablet
  lacks.

### Δ -5: Claymore
**Tablet 159 → PC 154.** 1 integer + 4 sub-chapters on tablet only.

- **Cause:** mostly sub-chapter splits.

### Δ -5: Sentenced to Be a Hero
**Tablet 15 → PC 10.** Tablet has integers 11, 12, 13 (continuation past PC's
max of 10) + 2 sub-chapters (`1.2`, `6.5`).

- **Cause:** tablet ahead by 3 chapters + 2 sub-chapter splits.
- **Push outcome:** **loses real chapters 11–13.** Re-download PC for this one
  before pushing.

### Δ -5: You Are Ms. Servant
**Tablet 92 → PC 87.** 6 sub-chapter splits on tablet; 1 PC mid-range integer.

- **Cause:** sub-chapter splits + minor PC gap.

### Δ +4: JoJo's Bizarre Adventure Part 2 Battle Tendency
**Tablet 113 → PC 117.** PC has 4 sub-chapters tablet doesn't.

- **Cause:** PC has bonus / `.5` chapters (same pattern as Part 1).

### Δ -4: Angel Beats! Heaven's Door
**Tablet 89 → PC 85.** 4 tablet-only sub-chapter splits.

- **Cause:** pure sub-chapter splits.

### Δ -3: CØDEBREAKER (PC: Code Breaker)
**Tablet 236 → PC 233.** Tablet has Ch 0 + 2 sub-chapters.

- **Cause:** Ch 0 prologue + 2 splits.

### Δ -3: Konosuba God's Blessing on This Wonderful World!
**Tablet 136 → PC 133.** Tablet has Ch 0 + 2 sub-chapters.

- **Cause:** Ch 0 prologue + 2 splits.

### Δ +3: The Angel Next Door Spoils Me Rotten
**Tablet 29 → PC 32.** PC has Ch 0 + 3 integers + 3 sub-chapters tablet
doesn't; tablet has 1 integer + 2 sub-chapters PC doesn't.

- **Cause:** PC has a Ch 0 prologue tablet lacks + PC has newer chapters;
  mid-range mismatches both ways.

### Δ +2: Kagurabachi
**Tablet 124 → PC 126.** Both sides have a few sub-chapter extras (3 on
tablet, 5 on PC).

- **Cause:** minor mid-range mismatches with different sub-chapter conventions.

### Δ -2: Sleepy Princess in the Demon Castle
**Tablet 455 → PC 453.** PC has 3 chapters past tablet (the most recent ones);
tablet has 5 sub-chapter splits PC doesn't.

- **Cause:** PC marginally ahead + tablet sub-chapter splits.

### Δ -1: The Legend of the Northern Blade
**Tablet 207 → PC 206.** Tablet has 2 sub-chapter splits; PC has 1.

- **Cause:** trivial mismatch.

### Δ +1: Shiunji-ke no Kodomotachi
**Tablet 71 → PC 72.** PC has 1 newer chapter.

- **Cause:** PC marginally ahead.

### Δ +1: The Angel Next Door Spoils Me Rotten After the Rain
**Tablet 39 → PC 40.** PC has 1 newer chapter.

- **Cause:** PC marginally ahead.

### Δ +1: Tower of God
**Tablet 652 → PC 653.** PC has 1 chapter past tablet; tablet has 1 integer in
PC's range that PC doesn't.

- **Cause:** trivial mid-range gap + 1 newer chapter on PC.

---

## Series where push will lose real content (re-download PC first)

These are the cases where tablet has *integer* chapters (i.e. real published
chapters, not scan splits) that PC doesn't have:

| Series | Tablet ahead by | What you'd lose if you push without refresh |
|--|--:|--|
| Horimiya              | 74 ch  | Chapters 128–201 (entire late run) |
| Sentenced to Be a Hero | 3 ch  | Chapters 11, 12, 13 |
| Fly Me to the Moon    | 2 ch  | Chapters 168, 215 (mid-range gaps) |

(The "different numbering" cases — JoJo Part 5, Is the Order a Rabbit — aren't
listed here because the lost integers are mangafire scan-splits, not real
chapters in the published numbering scheme.)

---

## Methodology

For each series in the push-from-PC list:

1. **Tablet labels** parsed from `tablet_files.txt` by extracting the chapter
   number from filenames matching one of:
   - `<series>_<site>_Ch_<num>.{pdf,cbz}`  (mangafire underscored)
   - `<series> Ch <num>.{pdf,cbz}`  (spaced)
   - `Chap <num> <title>.{pdf,cbz}`  (Berserk-style)
   - `Chapter <num>.{pdf,cbz}`
   - `#<num> - ...`
   - `Vol <num>.{pdf,cbz}`
2. **PC labels** parsed by globbing the matched PC folder (per
   `tablet_vs_pc.json`'s alias-resolved mapping) and extracting the chapter
   number from `Ch.<NNN[.M]> - <title>.{pdf,cbz}` (AIO's standard output).
3. The `~` decimal separator used by some tablet filenames (e.g.
   `Bleach Ch 168~1.pdf`) is normalized to `.` so it sorts and compares
   alongside `.1` / `.5` sub-chapter labels.
4. Leading zeros stripped (`Ch.001` and tablet `Ch_1` both → `1`).
5. The set diff `(tablet_labels − pc_labels)` and `(pc_labels − tablet_labels)`
   was computed and each side bucketed into "integer" vs "sub-chapter" entries.

**Unparsed files** (4 total, all on the tablet side): single full-series
mangafire dumps like `Bleach.pdf`, `JoJo's_Bizarre_Adventure_Part_5_Golden_Wind_mangafire.pdf`,
`That_Time_I_Got_Reincarnated_as_a_Slime_mangafire.pdf`,
`A Certain Scientific Railgun.pdf`. Not chapter files — excluded.

**Dragon Ball** is omitted from this analysis (PC count was 0 at scan time —
mid-re-download per the user's update).

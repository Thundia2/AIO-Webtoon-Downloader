# Re-download Plan — Tablet → Komikku-compatible Library

**Snapshot:** 2026-05-23
**Tablet:** `3CEF42502E91537` — `/storage/self/primary/Documents/`
**PC library:** `C:\Users\legoc\OneDrive\Belgeler\AIO-Webtoon-Downloader\mangas`
**Spec:** `../../AIO-Webtoon-Downloader/komikkuspec.md`

Of the 67 series on the tablet, 1 already meets Komikku spec (Eleceed) and 66
do not. Cross-referencing against the PC library:

- **51** are already present on PC as CBZ with `cover.jpg` — just push the PC
  folder to the tablet (after deleting the existing tablet copy).
- **15** need a fresh AIO download: 13 are absent from PC entirely, and 2
  (JoJo Parts 4 & 6) have PC folders that use a different chapter-numbering
  source from the tablet's mangafire scans, so pushing isn't 1:1.

> **Chapter-count caveat:** in several series the PC library has *fewer*
> chapters than the tablet (e.g. JoJo Part 5: PC 155, tablet 324). Pushing PC
> → tablet fixes the format but leaves those series shorter. Where the delta
> column shows a negative number, consider re-running the AIO downloader on
> that series first to catch up before pushing. See the dedicated shortfall
> table further down for the Δ ≤ -50 cases.

## Summary

| Bucket (why it's on the list) | Push from PC | Fresh download | Total |
|--|--:|--:|--:|
| 1. PDF-only                       | 44 | 15 | 59 |
| 2. Mixed CBZ + PDF                |  1 |  0 |  1 |
| 3. CBZ-only, missing `cover.jpg`  |  6 |  0 |  6 |
| **Total to act on**               | **51** | **15** | **66** |
| (Excluded — already compliant)    |    |    |  1 |

---

## A. Fresh download needed (15 series)

The first 13 have no corresponding PC folder at all. The last 2 (JoJo Parts 4 &
6) **do** have PC folders, but those use a different chapter-numbering source
than the tablet's mangafire scans, so they're not a 1:1 push — they're listed
here so a fresh AIO download under the tablet-style name produces a
1:1-replaceable CBZ folder.

### A.1 Not on PC at all

- [ ] **DARLING in the FRANXX** — tablet has 8 PDF chapters
- [ ] **Daughter of the Spirit King** — 170 PDF chapters
- [ ] **Every Day Is a Holiday (Colored)** — 310 PDF chapters
- [ ] **Fullmetal Alchemist** — 311 PDF chapters
- [ ] **Ghost Sore wa rei no Shiwaza desu** — 7 PDF chapters
- [ ] **Let's do it already** — 9 PDF chapters
- [ ] **Like a Butterfly** — 12 PDF chapters
- [ ] **My Dress-Up Darling** — 14 PDF chapters
- [ ] **No More Love With the Girls** — 143 PDF chapters
- [ ] **SHELTER** — 210 PDF chapters
- [ ] **Slow Life In Another World (I Wish!)** — 8 PDF chapters
- [ ] **The Reincarnation Magician of the Inferior Eyes** — 16 PDF chapters
- [ ] **Zom 100 Bucket List of the Dead** — 18 PDF chapters

### A.2 PC folder exists but uses a different chapter-numbering source

Tablet has mangafire-style scan numbering (running chapter numbers, often
sub-chapters like `Ch_439.1`); the existing PC folder uses published-chapter
numbering (`Ch.001 - <title>.cbz`). Not a 1:1 push — download fresh.

- [ ] **JoJo's_Bizarre_Adventure_Part_4_Diamond_is_Unbreakable** — tablet has 546 PDF "chapters" (mangafire-scan, up to Ch 439.1). PC's `JoJo no Kimyou na Bouken Part 4 - Diamond wa Kudakenai` has 174 published chapters.
- [ ] **JoJo's Bizarre Adventure Part 6 Stone Ocean** — tablet has 494 PDF "chapters" (mangafire-scan, up to Ch 752.1). PC's `JoJo's Bizarre Adventure Part 6 Stone Ocean (hid=t4U07)` has 158 published chapters.

---

## B. Push from PC (51 series — already CBZ + cover.jpg)

Delete the current tablet folder, push the PC folder. The "Δ" column is
`PC chapters − tablet chapters`; negative means the PC copy is behind and may
want an AIO refresh first.

### B.1 From PDF-only bucket (44 series)

| | Series (tablet name) | Tablet ch | PC ch | Δ | PC folder |
|--|--|--:|--:|--:|--|
| [ ] | 'Tis Time for Torture, Princess                              | 294 | 285 |  -9 | 'Tis Time for Torture, Princess |
| [ ] | A Certain Scientific Railgun                                 | 236 | 189 | -47 | Toaru Majutsu no Index Gaiden Toaru Kagaku no Railgun |
| [ ] | A Couple of Cuckoos                                          | 291 | 297 |  +6 | A Couple of Cuckoos |
| [ ] | Angel Beats! Heaven's Door                                   |  89 |  85 |  -4 | Angel Beats! - Heaven's Door |
| [ ] | Attack_on_Titan                                              | 142 | 147 |  +5 | Attack on Titan |
| [ ] | Berserk                                                      | 400 | 389 | -11 | Berserk |
| [ ] | Bleach                                                       | 742 | 694 | -48 | Bleach |
| [ ] | Bungo Stray Dogs                                             | 167 | 137 | -30 | Bungo Stray Dogs (hid=PW1SJ) |
| [ ] | Chainsaw Man                                                 | 215 | 293 | +78 | Chainsaw Man |
| [ ] | Claymore                                                     | 159 | 154 |  -5 | Claymore |
| [ ] | CØDEBREAKER                                                  | 236 | 233 |  -3 | Code Breaker |
| [ ] | Demon_Slayer_Kimetsu_no_Yaiba                                | 244 | 237 |  -7 | Demon Slayer Kimetsu no Yaiba |
| [ ] | Dragon Ball                                                  | 545 | *in flux* | *re-downloading on PC; assume caught up by push time* | Dragon Ball |
| [ ] | EDENS ZERO                                                   | 293 | 293 |   = | EDENS ZERO |
| [ ] | Horimiya                                                     | 254 | 142 | **-112** | Horimiya |
| [ ] | I Was Supposed to Never Fall in Love with You                |  45 |  45 |   = | I Was Supposed to Never Fall in Love with You |
| [ ] | Is_the_order_a_rabbit                                        | 184 |  97 | **-87** | Gochuumon wa Usagi desu ka |
| [ ] | JoJo's Bizarre Adventure Part 5 Golden Wind                  | 324 | 155 | **-169** | JoJo no Kimyou na Bouken Part 5 - Ougon no Kaze |
| [ ] | JoJo's_Bizarre_Adventure_Part_1_Phantom_Blood                |  44 |  49 |  +5 | JoJo's Bizarre Adventure Part 1 Phantom Blood |
| [ ] | JoJo's_Bizarre_Adventure_Part_2_Battle_Tendency              | 113 | 117 |  +4 | JoJo's Bizarre Adventure Part 2 Battle Tendency |
| [ ] | JoJo's_Bizarre_Adventure_Part_3_Stardust_Crusaders           | 445 | 403 | -42 | JoJo's Bizarre Adventure Part 3 Stardust Crusaders |
| [ ] | Komi_Can't_Communicate                                       | 526 | 505 | -21 | Komi Can't Communicate |
| [ ] | Konosuba God's Blessing on This Wonderful World!             | 136 | 133 |  -3 | Konosuba God's Blessing on This Wonderful World! (hid=gvHMj) |
| [ ] | Link Click                                                   |  41 |  41 |   = | Link Click |
| [ ] | Lycoris_Recoil                                               |  21 |  21 |   = | Lycoris Recoil |
| [ ] | Makeine Make Hiroin ga Ōsugiru!                              |   4 |  25 | +21 | Too Many Losing Heroines! |
| [ ] | My youth romantic comedy is wrong as I expected              |  97 |  89 |  -8 | My Youth Romantic Comedy Is Wrong, As I Expected |
| [ ] | No Longer Allowed In Another World                           |  11 |  62 | +51 | Isekai Shikkaku |
| [ ] | One-Punch_Man_(Official)                                     | 299 | 245 | -54 | One-Punch Man |
| [ ] | Pandora Hearts                                               | 277 | 277 |   = | Pandora Hearts *(PC re-downloaded since first snapshot — now matches tablet)* |
| [ ] | Pandora Seven                                                |  19 |  54 | +35 | Pandora Seven |
| [ ] | Record of Ragnarok                                           | 119 | 132 | +13 | Shuumatsu no Valkyrie |
| [ ] | Rinjin-chan ga Shinpai                                       |   5 | 152 | +147 | Rinjin-chan ga Shinpai |
| [ ] | Sakamoto Days                                                |  23 | 258 | +235 | Sakamoto Days |
| [ ] | Sentenced to Be a Hero The Prison Records of Penal Hero Unit 9004 | 15 | 10 |  -5 | Sentenced to Be a Hero The Prison Records of Penal Hero Unit 9004 |
| [ ] | Sleepy Princess in the Demon Castle                          | 455 | 453 |  -2 | Sleepy Princess in the Demon Castle |
| [ ] | SPY_x_FAMILY                                                 | 204 | 150 | -54 | SPY×FAMILY |
| [ ] | That Time I Got Reincarnated as a Slime                      | 183 | 167 | -16 | That Time I Got Reincarnated as a Slime |
| [ ] | The Legend of the Northern Blade                             | 207 | 206 |  -1 | The Legend of the Northern Blade |
| [ ] | Tower of God                                                 | 652 | 653 |  +1 | Tower of God |
| [ ] | Undead Unluck                                                | 259 | 240 | -19 | Undead Unluck |
| [ ] | Vivy_-Fluorite_Eye's_Song-                                   |   7 |   7 |   = | Vivy -Fluorite Eye's Song- |
| [ ] | You and I are Polar Opposites                                |  80 |  67 | -13 | You and I Are Polar Opposites |
| [ ] | You are Ms. Servant                                          |  92 |  87 |  -5 | You Are Ms. Servant |

### B.2 From mixed CBZ+PDF bucket (1 series)

| | Series | Tablet ch | PC ch | Δ | PC folder |
|--|--|--:|--:|--:|--|
| [ ] | Fly Me to the Moon (456 pdf + 4 cbz on tablet) | 460 | 370 | **-90** | Fly Me to the Moon |

### B.3 From CBZ-only/missing-cover bucket (6 series)

These already have CBZ on the tablet; pushing from PC brings the matching
`cover.jpg` along.

| | Series | Tablet ch | PC ch | Δ | PC folder |
|--|--|--:|--:|--:|--|
| [ ] | Kagurabachi                                         | 124 | 126 |  +2 | Kagurabachi |
| [ ] | Shiunji-ke no Kodomotachi                           |  71 |  72 |  +1 | Shiunji-ke no Kodomotachi |
| [ ] | Solo Leveling                                       | 245 | 201 | -44 | Solo Leveling |
| [ ] | Talentless Nana                                     | 119 | 119 |   = | Talentless Nana |
| [ ] | The Angel Next Door Spoils Me Rotten                |  29 |  32 |  +3 | The Angel Next Door Spoils Me Rotten |
| [ ] | The Angel Next Door Spoils Me Rotten After the Rain |  39 |  40 |  +1 | The Angel Next Door Spoils Me Rotten After the Rain |

---

## C. Excluded — already Komikku-compatible

- [x] **Eleceed** — CBZ, 385 chapters + `cover.jpg` at series root (PC also 385, Δ = 0 — in sync, no action needed)

---

## Series with significant PC-vs-tablet shortfall (Δ ≤ -50)

Re-running the AIO downloader on these first will catch the PC library up to
where the tablet's PDF count is, before the push step replaces the tablet copy
with the CBZ versions. (JoJo Parts 4 & 6 moved to section A; Pandora Hearts
now in sync; Dragon Ball is mid-re-download and assumed to land at the tablet
count.)

| Series | Tablet | PC | Δ |
|--|--:|--:|--:|
| JoJo's Bizarre Adventure Part 5 (Golden Wind)            | 324 | 155 | -169 |
| Horimiya                                                 | 254 | 142 | -112 |
| Fly Me to the Moon                                       | 460 | 370 |  -90 |
| Is the Order a Rabbit (Gochuumon wa Usagi desu ka)       | 184 |  97 |  -87 |
| One-Punch Man                                            | 299 | 245 |  -54 |
| SPY×FAMILY                                               | 204 | 150 |  -54 |

---

## Methodology

Tablet snapshot via:
```
adb -s 3CEF42502E91537 shell \
  "find /storage/self/primary/Documents -mindepth 1 -type f -printf '%p\n'"
```
Classified by `_classify_tablet.py` → `tablet_classify.json`.

PC library scanned in-place at `C:\Users\legoc\OneDrive\Belgeler\AIO-Webtoon-Downloader\mangas`
by `_compare_tablet_vs_pc.py` → `tablet_vs_pc.json`. Tablet → PC matching first
uses normalized name (NFKC casefold, `_` → space, apostrophes deleted,
punctuation → space, `(hid=X)` suffix stripped); for series whose PC folder is
under a Japanese or alternate English title, a hand-curated alias table inside
the script provides the link. Aliases used:

- `A Certain Scientific Railgun` → `Toaru Majutsu no Index Gaiden Toaru Kagaku no Railgun`
- `CØDEBREAKER` → `Code Breaker`
- `Is_the_order_a_rabbit` → `Gochuumon wa Usagi desu ka`
- `JoJo's Bizarre Adventure Part 5 Golden Wind` → `JoJo no Kimyou na Bouken Part 5 - Ougon no Kaze` (kept — same JP/EN mismatch as Parts 4 & 6, but the PC folder is treated as a valid source for this one per user direction)
- `Makeine Make Hiroin ga Ōsugiru!` → `Too Many Losing Heroines!`
- `No Longer Allowed In Another World` → `Isekai Shikkaku`
- `One-Punch_Man_(Official)` → `One-Punch Man`
- `Record of Ragnarok` → `Shuumatsu no Valkyrie`
- `SPY_x_FAMILY` → `SPY×FAMILY` (the `×` is U+00D7 MULTIPLICATION SIGN)

PC chapter counts include every `.cbz` directly under the series folder; the
PC library has **0 PDFs** total — every chapter is already CBZ + cover.jpg, so
the only friction in the push step is the chapter-count delta noted above.

PC folder `Eleceed` matches the tablet copy exactly (385 chapters on both
sides) and is fully spec-compliant on the tablet — hence inclusion in section
C rather than B.

### Manual revisions after the initial scan (2026-05-23)

- **JoJo Part 4** and **JoJo Part 6** moved from B.1 (push) to A.2 (fresh
  download): the PC folders for these parts (`JoJo no Kimyou na Bouken Part
  4 - Diamond wa Kudakenai` and `JoJo's Bizarre Adventure Part 6 Stone Ocean
  (hid=t4U07)`) use published-chapter numbering, while the tablet has
  mangafire-style scan numbering with sub-chapters. Not 1:1 — a fresh AIO
  download under the tablet-style name is needed.
- **Pandora Hearts**: PC re-downloaded after the initial scan; now 277 cbz
  (matches tablet exactly). Originally showed Δ = -170.
- **Dragon Ball**: PC re-download in progress at time of update; the count
  column shows `*in flux*`. Assumed to reach the tablet count (545) before
  the push step runs.

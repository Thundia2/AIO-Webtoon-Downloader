"""
_classify_tablet.py — One-off categorization of tablet manga folders for
Komikku-compatibility re-download planning.

Reads the path dump produced by:
  adb shell find /storage/self/primary/Documents -mindepth 1 -type f -printf '%p\n'

Per Komikku LocalSource spec (komikkuspec.md):
  - Supported chapter archive extensions: .zip / .cbz / .rar / .cbr / .epub.
    PDF is NOT supported.
  - Cover file: exact name "cover.jpg" at the SERIES folder root.

For each immediate sub-directory of Documents/ we collect:
  - per-extension chapter counts (pdf, cbz)
  - whether cover.jpg exists at series root
  - the action needed (re-download, mixed cleanup, add cover, or none)

Output is a single JSON blob on stdout consumed by the .md writer.
"""
from __future__ import annotations

import json
import sys
from collections import defaultdict

ROOT = "/storage/self/primary/Documents/"
CHAPTER_EXTS = {"pdf", "cbz", "zip", "cbr", "rar", "epub"}
IGNORE_FILES = {".aio_series.json", ".mangafire_hid", "details.json", ".nomedia"}


def main(path: str) -> int:
    with open(path, encoding="utf-8") as f:
        lines = [ln.strip() for ln in f if ln.strip()]

    # series -> {ext: count}
    series_ext_counts: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    # series -> set of root-level filenames (case-preserved)
    series_root_files: dict[str, set[str]] = defaultdict(set)

    for line in lines:
        if not line.startswith(ROOT):
            continue
        rel = line[len(ROOT):]
        parts = rel.split("/")
        if len(parts) < 2:
            continue
        series = parts[0]
        base = parts[-1]
        series_root_files[series].add(base)
        if base in IGNORE_FILES or base.startswith("."):
            continue
        lower = base.lower()
        _, dot, ext = lower.rpartition(".")
        if not dot:
            continue
        if ext in CHAPTER_EXTS:
            series_ext_counts[series][ext] += 1

    all_series = sorted(set(series_root_files) | set(series_ext_counts), key=str.casefold)

    out = []
    for s in all_series:
        counts = dict(series_ext_counts.get(s, {}))
        has_pdf = counts.get("pdf", 0) > 0
        has_cbz = counts.get("cbz", 0) > 0
        has_cover = "cover.jpg" in series_root_files.get(s, set())

        # Action priority:
        #   pdf-only       -> "redownload"      (need fresh CBZ rip)
        #   mixed pdf+cbz  -> "redownload_pdfs" (only re-do the PDF chapters)
        #   cbz-only no cover -> "add_cover"
        #   cbz-only + cover  -> "ok"
        if has_pdf and has_cbz:
            action = "redownload_pdfs"
        elif has_pdf:
            action = "redownload"
        elif has_cbz and not has_cover:
            action = "add_cover"
        elif has_cbz and has_cover:
            action = "ok"
        else:
            action = "empty"

        out.append({
            "series": s,
            "counts": counts,
            "total_chapters": sum(counts.values()),
            "has_cover_jpg": has_cover,
            "action": action,
        })

    json.dump(out, sys.stdout, ensure_ascii=False, indent=2)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1] if len(sys.argv) > 1 else "/tmp/tablet_files.txt"))

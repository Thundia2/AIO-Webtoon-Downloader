"""
_compare_tablet_vs_pc.py — Cross-reference the tablet re-download list against
the local PC library.

Reads:
  - tablet_classify.json (output of _classify_tablet.py)
  - C:/Users/legoc/OneDrive/Belgeler/AIO-Webtoon-Downloader/mangas/  (scanned live)

For each tablet series that needs re-download, looks up the matching PC folder
by normalized name and reports:
  - PC folder name (post-hid-strip), or "<NOT ON PC>"
  - PC chapter count by extension (pdf / cbz)
  - PC has cover.jpg at folder root
  - Recommendation:
      "push"      = PC has the series in CBZ + cover.jpg, ready to push
      "push-no-cover" = PC has CBZ but no cover.jpg, fix cover then push
      "push-pdfs"     = PC also has PDFs (rare); same downgrade as tablet
      "download"  = no PC match, must re-download from source

Name normalization follows compare_manga.normalize_series_name: strips a
trailing "(hid=X)", NFKC + casefold, '_' -> ' ', deletes apostrophes (so
"komi's" -> "komis"), maps other punctuation to ' ', collapses whitespace.
"""
from __future__ import annotations

import json
import os
import re
import sys
import unicodedata
from collections import defaultdict
from pathlib import Path

PC_ROOT = Path(r"C:\Users\legoc\OneDrive\Belgeler\AIO-Webtoon-Downloader\mangas")
IGNORE_TOP = {".aio_coord", ".aio_folder_alloc.lock"}
IGNORE_FILES = {".aio_series.json", ".mangafire_hid", ".nomedia"}

# Hand-curated tablet→PC folder mappings for series whose PC folder is named
# under a different (e.g. Japanese) title that normalize_series_name can't
# bridge. The RHS is the PC folder name pre-normalization; we then look it up
# by its own normalized form. Keys are tablet series names (as they appear in
# tablet_classify.json).
TABLET_TO_PC_ALIAS = {
    "A Certain Scientific Railgun":
        "Toaru Majutsu no Index Gaiden Toaru Kagaku no Railgun",
    "CØDEBREAKER": "Code Breaker",
    "Is_the_order_a_rabbit": "Gochuumon wa Usagi desu ka",
    "JoJo's Bizarre Adventure Part 5 Golden Wind":
        "JoJo no Kimyou na Bouken Part 5 - Ougon no Kaze",
    # JoJo Parts 4 and 6 deliberately NOT aliased: the PC folders for those
    # parts use published-chapter numbering while the tablet uses mangafire
    # scan-numbering with sub-chapters (e.g. Ch_439.1). Pushing wouldn't be
    # 1:1, so they're handled as fresh-download in REDOWNLOAD_FOR_KOMIKKU.md
    # section A.2 instead.
    "Makeine Make Hiroin ga Ōsugiru!": "Too Many Losing Heroines!",
    "No Longer Allowed In Another World": "Isekai Shikkaku",
    "One-Punch_Man_(Official)": "One-Punch Man",
    "Record of Ragnarok": "Shuumatsu no Valkyrie",
    "SPY_x_FAMILY": "SPY×FAMILY",
}

RE_HID = re.compile(r"^(.+?)\s*\(hid=(.*?)\)\s*$")
_APOS = str.maketrans({c: "" for c in "'’‘"})
_PUNCT = str.maketrans({c: " " for c in '"“”,.!?:;()[]-–—/'})


def normalize(name: str) -> str:
    m = RE_HID.match(name)
    if m:
        name = m.group(1)
    s = unicodedata.normalize("NFKC", name).casefold()
    s = s.replace("_", " ")
    s = s.translate(_APOS)
    s = s.translate(_PUNCT)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def scan_pc() -> dict[str, list[dict]]:
    """norm_name -> list of {folder, exts: {ext: count}, has_cover_jpg}."""
    out: dict[str, list[dict]] = defaultdict(list)
    for entry in os.scandir(PC_ROOT):
        if entry.name.startswith(".") or entry.name in IGNORE_TOP:
            continue
        if not entry.is_dir():
            continue
        folder = entry.name
        norm = normalize(folder)
        exts: dict[str, int] = defaultdict(int)
        has_cover = False
        for sub in os.scandir(entry.path):
            if not sub.is_file():
                continue
            base = sub.name
            if base == "cover.jpg":
                has_cover = True
            if base.startswith(".") or base in IGNORE_FILES:
                continue
            lower = base.lower()
            _, dot, ext = lower.rpartition(".")
            if dot and ext in ("pdf", "cbz", "zip", "cbr", "rar", "epub"):
                exts[ext] += 1
        out[norm].append({
            "folder": folder,
            "exts": dict(exts),
            "has_cover_jpg": has_cover,
            "total_chapters": sum(exts.values()),
        })
    return out


def main() -> int:
    classify_path = "tablet_classify.json"
    with open(classify_path, encoding="utf-8") as f:
        tablet = json.load(f)

    pc_index = scan_pc()

    rows = []
    for t in tablet:
        if t["action"] == "ok":
            continue  # Eleceed — already compliant, skip
        # Apply hand alias first; falls back to normalized-name lookup.
        alias = TABLET_TO_PC_ALIAS.get(t["series"])
        if alias is not None:
            matches = pc_index.get(normalize(alias), [])
        else:
            matches = pc_index.get(normalize(t["series"]), [])

        # Drop empty PC variants (folder exists but no chapter files) — they're
        # placeholder folders, not a real download. e.g. the empty EN-named
        # JoJo Part 4 / Part 6 Stone Ocean folders.
        matches = [m for m in matches if m["total_chapters"] > 0]

        if not matches:
            rec = "download"
            pc_summary = None
        else:
            # Aggregate across remaining (populated) PC variants.
            agg_exts: dict[str, int] = defaultdict(int)
            covers = 0
            folder_list = []
            for m in matches:
                for k, v in m["exts"].items():
                    agg_exts[k] += v
                if m["has_cover_jpg"]:
                    covers += 1
                folder_list.append(m["folder"])
            has_pdf_on_pc = agg_exts.get("pdf", 0) > 0
            has_cbz_on_pc = agg_exts.get("cbz", 0) > 0
            if has_pdf_on_pc and not has_cbz_on_pc:
                rec = "push-pdfs"
            elif has_pdf_on_pc and has_cbz_on_pc:
                rec = "push-mixed"
            elif has_cbz_on_pc and covers == len(matches):
                rec = "push"
            elif has_cbz_on_pc:
                rec = "push-no-cover"
            else:
                rec = "push-empty"
            pc_summary = {
                "folders": folder_list,
                "exts": dict(agg_exts),
                "covers": covers,
                "variant_count": len(matches),
            }

        rows.append({
            "tablet_series": t["series"],
            "tablet_action": t["action"],
            "tablet_counts": t["counts"],
            "tablet_total": t["total_chapters"],
            "pc": pc_summary,
            "recommendation": rec,
        })

    # Sort by recommendation then series name
    rec_order = {"download": 0, "push-pdfs": 1, "push-mixed": 2,
                 "push-no-cover": 3, "push": 4, "push-empty": 5}
    rows.sort(key=lambda r: (rec_order.get(r["recommendation"], 99),
                              r["tablet_series"].casefold()))

    json.dump(rows, sys.stdout, ensure_ascii=False, indent=2)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

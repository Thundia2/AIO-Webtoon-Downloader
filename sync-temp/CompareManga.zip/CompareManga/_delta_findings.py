"""
_delta_findings.py — For each push-from-PC series with a non-zero chapter
delta, diff the tablet and PC chapter-label sets and characterize the cause.

Input:
  - /tmp/tablet_files.txt (output of `adb shell find ... -printf '%p\n'`)
  - PC library at C:\\Users\\legoc\\OneDrive\\Belgeler\\AIO-Webtoon-Downloader\\mangas
  - PUSH_MAP below (tablet series name → PC folder name; derived from the
    REDOWNLOAD_FOR_KOMIKKU.md push tables, with the post-revision Parts 4 & 6
    exclusion applied).

Output:
  - JSON dump on stdout: per-series chapter-set diff and categorized cause.

Chapter-label parsing:
  - Tablet "Ch <N>" pattern         : "Bleach Ch 168~1.pdf"  -> "168.1"
  - Tablet "_<site>_Ch_<N>" pattern : "JoJo..._mangafire_Ch_5.5.pdf" -> "5.5"
  - PC "Ch.NNN[.M] - title" pattern : "Ch.686.5 - ...cbz"    -> "686.5"
  - Falls back to a generic "Ch[.\\s]<num>" capture; anything still unmatched
    is reported under `unparsed_*` for manual review.
"""
from __future__ import annotations

import json
import os
import re
import sys
from collections import defaultdict
from pathlib import Path

PC_ROOT = Path(r"C:\Users\legoc\OneDrive\Belgeler\AIO-Webtoon-Downloader\mangas")
TABLET_DUMP = "tablet_files.txt"
TABLET_ROOT = "/storage/self/primary/Documents/"

# Skip junk filenames so they don't pollute the diff or the unparsed list.
SKIP_BASENAMES = {".aio_series.json", ".mangafire_hid", ".nomedia",
                  "details.json", "cover.jpg"}

# Tablet series name -> PC folder name. Matches the push tables in
# REDOWNLOAD_FOR_KOMIKKU.md (sections B.1, B.2, B.3 after the manual revision
# that moved JoJo Parts 4 & 6 to fresh-download).
PUSH_MAP = {
    "'Tis Time for Torture, Princess": "'Tis Time for Torture, Princess",
    "A Certain Scientific Railgun":
        "Toaru Majutsu no Index Gaiden Toaru Kagaku no Railgun",
    "A Couple of Cuckoos": "A Couple of Cuckoos",
    "Angel Beats! Heaven's Door": "Angel Beats! - Heaven's Door",
    "Attack_on_Titan": "Attack on Titan",
    "Berserk": "Berserk",
    "Bleach": "Bleach",
    "Bungo Stray Dogs": "Bungo Stray Dogs (hid=PW1SJ)",
    "Chainsaw Man": "Chainsaw Man",
    "Claymore": "Claymore",
    "CØDEBREAKER": "Code Breaker",
    "Demon_Slayer_Kimetsu_no_Yaiba": "Demon Slayer Kimetsu no Yaiba",
    "EDENS ZERO": "EDENS ZERO",
    "Fly Me to the Moon": "Fly Me to the Moon",
    "Horimiya": "Horimiya",
    "I Was Supposed to Never Fall in Love with You":
        "I Was Supposed to Never Fall in Love with You",
    "Is_the_order_a_rabbit": "Gochuumon wa Usagi desu ka",
    "JoJo's Bizarre Adventure Part 5 Golden Wind":
        "JoJo no Kimyou na Bouken Part 5 - Ougon no Kaze",
    "JoJo's_Bizarre_Adventure_Part_1_Phantom_Blood":
        "JoJo's Bizarre Adventure Part 1 Phantom Blood",
    "JoJo's_Bizarre_Adventure_Part_2_Battle_Tendency":
        "JoJo's Bizarre Adventure Part 2 Battle Tendency",
    "JoJo's_Bizarre_Adventure_Part_3_Stardust_Crusaders":
        "JoJo's Bizarre Adventure Part 3 Stardust Crusaders",
    "Kagurabachi": "Kagurabachi",
    "Komi_Can't_Communicate": "Komi Can't Communicate",
    "Konosuba God's Blessing on This Wonderful World!":
        "Konosuba God's Blessing on This Wonderful World! (hid=gvHMj)",
    "Link Click": "Link Click",
    "Lycoris_Recoil": "Lycoris Recoil",
    "Makeine Make Hiroin ga Ōsugiru!": "Too Many Losing Heroines!",
    "My youth romantic comedy is wrong as I expected":
        "My Youth Romantic Comedy Is Wrong, As I Expected",
    "No Longer Allowed In Another World": "Isekai Shikkaku",
    "One-Punch_Man_(Official)": "One-Punch Man",
    "Pandora Hearts": "Pandora Hearts",
    "Pandora Seven": "Pandora Seven",
    "Record of Ragnarok": "Shuumatsu no Valkyrie",
    "Rinjin-chan ga Shinpai": "Rinjin-chan ga Shinpai",
    "Sakamoto Days": "Sakamoto Days",
    "Sentenced to Be a Hero The Prison Records of Penal Hero Unit 9004":
        "Sentenced to Be a Hero The Prison Records of Penal Hero Unit 9004",
    "Shiunji-ke no Kodomotachi": "Shiunji-ke no Kodomotachi",
    "Sleepy Princess in the Demon Castle": "Sleepy Princess in the Demon Castle",
    "Solo Leveling": "Solo Leveling",
    "SPY_x_FAMILY": "SPY×FAMILY",
    "Talentless Nana": "Talentless Nana",
    "That Time I Got Reincarnated as a Slime":
        "That Time I Got Reincarnated as a Slime",
    "The Angel Next Door Spoils Me Rotten":
        "The Angel Next Door Spoils Me Rotten",
    "The Angel Next Door Spoils Me Rotten After the Rain":
        "The Angel Next Door Spoils Me Rotten After the Rain",
    "The Legend of the Northern Blade": "The Legend of the Northern Blade",
    "Tower of God": "Tower of God",
    "Undead Unluck": "Undead Unluck",
    "Vivy_-Fluorite_Eye's_Song-": "Vivy -Fluorite Eye's Song-",
    "You and I are Polar Opposites": "You and I Are Polar Opposites",
    "You are Ms. Servant": "You Are Ms. Servant",
    # Dragon Ball deliberately omitted — PC is mid-redownload and counts are
    # in flux. Including it would emit a misleading diff.
}

# Chapter-label regex tries; first match wins. The capture group is the bare
# number (integer or decimal). The `~` decimal separator (tablet) is mapped to
# `.` before canonicalization; leading zeros are stripped.
_RE_TABLET_SPACES = re.compile(
    r" Ch\s+(\d+(?:[.~]\d+)?)\s*\.(?:pdf|cbz)$", re.IGNORECASE)
_RE_TABLET_UNDERSCORED = re.compile(
    r"_(?:mangafire|comix|comickfun|mangadex|asura|asurascans)"
    r"_Ch_(\d+(?:[.~]\d+)?)\s*\.(?:pdf|cbz)$", re.IGNORECASE)
_RE_PC_DOTTED = re.compile(
    r"^Ch\.0*(\d+(?:\.\d+)?)\s*(?:-.*)?\.(?:pdf|cbz)$", re.IGNORECASE)
_RE_GENERIC_CHAP = re.compile(
    r"^Chap(?:ter)?\s+(\d+(?:\.\d+)?)\b", re.IGNORECASE)
_RE_HASH = re.compile(r"^#(\d+(?:\.\d+)?)\s*-", re.IGNORECASE)
_RE_VOL = re.compile(r"^Vol\s+(\d+(?:\.\d+)?)\s*\.(?:pdf|cbz)$", re.IGNORECASE)


def parse_label(filename: str) -> str | None:
    for pat in (_RE_TABLET_UNDERSCORED, _RE_TABLET_SPACES, _RE_PC_DOTTED,
                _RE_GENERIC_CHAP, _RE_HASH, _RE_VOL):
        m = pat.search(filename) if pat is _RE_TABLET_UNDERSCORED or pat is _RE_TABLET_SPACES else pat.match(filename)
        if m:
            return m.group(1).replace("~", ".")
    return None


def _is_chapter_file(base: str) -> bool:
    if base in SKIP_BASENAMES or base.startswith("."):
        return False
    lower = base.lower()
    return lower.endswith(".pdf") or lower.endswith(".cbz")


def scan_tablet() -> tuple[dict[str, list[str]], dict[str, list[str]]]:
    """series -> (labels, unparsed_basenames)"""
    labels: dict[str, list[str]] = defaultdict(list)
    unparsed: dict[str, list[str]] = defaultdict(list)
    with open(TABLET_DUMP, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line.startswith(TABLET_ROOT):
                continue
            rel = line[len(TABLET_ROOT):]
            if "/" not in rel:
                continue
            series, base = rel.split("/", 1)
            if "/" in base:
                continue  # nested files (none expected)
            if not _is_chapter_file(base):
                continue
            lab = parse_label(base)
            if lab is None:
                unparsed[series].append(base)
            else:
                labels[series].append(lab)
    return labels, unparsed


def scan_pc(folder: str) -> tuple[list[str], list[str]]:
    labels: list[str] = []
    unparsed: list[str] = []
    p = PC_ROOT / folder
    if not p.is_dir():
        return labels, unparsed
    for entry in os.scandir(p):
        if not entry.is_file():
            continue
        base = entry.name
        if not _is_chapter_file(base):
            continue
        lab = parse_label(base)
        if lab is None:
            unparsed.append(base)
        else:
            labels.append(lab)
    return labels, unparsed


def _to_float(label: str) -> float:
    try:
        return float(label)
    except ValueError:
        return -1.0


def categorize(t_only: list[str], p_only: list[str],
               t_labels: list[str], p_labels: list[str]) -> list[str]:
    """Return a list of human-readable tags describing the diff."""
    tags: list[str] = []
    if not t_only and not p_only:
        return ["exact_match"]
    t_set = set(t_labels)
    p_set = set(p_labels)
    # Floats for range checks
    t_max = max((_to_float(l) for l in t_labels), default=0.0)
    p_max = max((_to_float(l) for l in p_labels), default=0.0)
    t_min = min((_to_float(l) for l in t_labels), default=0.0)
    p_min = min((_to_float(l) for l in p_labels), default=0.0)

    # PC has chapters above tablet's max?
    if p_only and all(_to_float(l) > t_max for l in p_only):
        tags.append(f"pc_ahead_only: PC has chapters > {t_max} that tablet lacks")

    # Tablet has chapters above PC's max?
    if t_only and all(_to_float(l) > p_max for l in t_only):
        tags.append(f"tablet_ahead_only: tablet has chapters > {p_max} that PC lacks")

    # Partial / sub-chapter buckets
    t_only_partials = [l for l in t_only if "." in l]
    t_only_integers = [l for l in t_only if "." not in l]
    p_only_partials = [l for l in p_only if "." in l]
    p_only_integers = [l for l in p_only if "." not in l]

    if t_only_partials and not t_only_integers:
        tags.append(f"tablet_has_extra_sub_chapters_only: {len(t_only_partials)}")
    elif t_only_partials and t_only_integers:
        tags.append(
            f"tablet_only_mixed: {len(t_only_integers)} integer + "
            f"{len(t_only_partials)} sub-chapter")
    elif t_only_integers and not t_only_partials:
        # All tablet-only are integers — could be in-range gaps or trailing
        in_range = [l for l in t_only_integers if _to_float(l) <= p_max]
        if in_range:
            tags.append(
                f"tablet_has_integer_chapters_in_pc_range: {len(in_range)} "
                f"(possible missing-on-PC)")

    if p_only_partials and not p_only_integers:
        tags.append(f"pc_has_extra_sub_chapters_only: {len(p_only_partials)}")
    elif p_only_integers and not p_only_partials:
        in_range = [l for l in p_only_integers if _to_float(l) <= t_max]
        if in_range:
            tags.append(
                f"pc_has_integer_chapters_in_tablet_range: {len(in_range)} "
                f"(possible mid-range gaps on tablet)")
    elif p_only_partials and p_only_integers:
        tags.append(
            f"pc_only_mixed: {len(p_only_integers)} integer + "
            f"{len(p_only_partials)} sub-chapter")

    # Special: zero-chapter / prologue
    if "0" in t_set and "0" not in p_set:
        tags.append("tablet_has_ch0_pc_does_not")
    if "0" in p_set and "0" not in t_set:
        tags.append("pc_has_ch0_tablet_does_not")

    # Differences in starting chapter
    if t_min != p_min:
        tags.append(f"different_starting_chapter: tablet starts at {t_min}, PC at {p_min}")

    return tags or ["unclassified"]


def main() -> int:
    tablet_labels, tablet_unparsed = scan_tablet()
    findings = []
    for tablet_series, pc_folder in PUSH_MAP.items():
        t_labels = tablet_labels.get(tablet_series, [])
        p_labels, p_unparsed = scan_pc(pc_folder)
        t_unparsed = tablet_unparsed.get(tablet_series, [])
        t_set = set(t_labels)
        p_set = set(p_labels)
        t_only = sorted(t_set - p_set, key=_to_float)
        p_only = sorted(p_set - t_set, key=_to_float)
        delta = len(p_labels) - len(t_labels)
        if delta == 0 and not t_only and not p_only:
            continue
        findings.append({
            "series": tablet_series,
            "pc_folder": pc_folder,
            "tablet_total": len(t_labels),
            "pc_total": len(p_labels),
            "delta": delta,
            "shared": len(t_set & p_set),
            "tablet_only_count": len(t_only),
            "pc_only_count": len(p_only),
            "tablet_only": t_only,
            "pc_only": p_only,
            "tags": categorize(t_only, p_only, t_labels, p_labels),
            "tablet_unparsed": t_unparsed,
            "pc_unparsed": p_unparsed,
        })

    # Sort: largest |delta| first
    findings.sort(key=lambda r: (-abs(r["delta"]), r["series"].casefold()))
    json.dump(findings, sys.stdout, ensure_ascii=False, indent=2)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

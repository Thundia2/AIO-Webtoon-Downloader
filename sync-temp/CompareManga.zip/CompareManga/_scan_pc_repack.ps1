# One-off diagnostic: measure repack scope of D:\AIO\manga.
# For each series folder, report cbz count/bytes, newest cbz mtime, and
# cover.jpg / details.json presence+mtime. Emits JSON to stdout.
# Used to decide full-remirror vs metadata-only sync. Safe: read-only.
$ErrorActionPreference = 'Stop'
$root = 'D:\AIO\manga'
$out = @()
foreach ($d in Get-ChildItem -LiteralPath $root -Directory | Sort-Object Name) {
    $cbz = Get-ChildItem -LiteralPath $d.FullName -Filter *.cbz -File -ErrorAction SilentlyContinue
    $cover = Join-Path $d.FullName 'cover.jpg'
    $details = Join-Path $d.FullName 'details.json'
    $shid = Join-Path $d.FullName '.series_hid'
    $cbzBytes = ($cbz | Measure-Object Length -Sum).Sum
    if ($null -eq $cbzBytes) { $cbzBytes = 0 }
    $maxCbz = $null
    if ($cbz.Count -gt 0) { $maxCbz = ($cbz | Measure-Object LastWriteTime -Maximum).Maximum }
    $minCbz = $null
    if ($cbz.Count -gt 0) { $minCbz = ($cbz | Measure-Object LastWriteTime -Minimum).Minimum }
    $out += [pscustomobject]@{
        name          = $d.Name
        cbz_count     = $cbz.Count
        cbz_bytes     = [int64]$cbzBytes
        cbz_mtime_max = if ($maxCbz) { $maxCbz.ToString('o') } else { $null }
        cbz_mtime_min = if ($minCbz) { $minCbz.ToString('o') } else { $null }
        has_cover     = Test-Path -LiteralPath $cover
        cover_mtime   = if (Test-Path -LiteralPath $cover) { (Get-Item -LiteralPath $cover).LastWriteTime.ToString('o') } else { $null }
        has_details   = Test-Path -LiteralPath $details
        details_mtime = if (Test-Path -LiteralPath $details) { (Get-Item -LiteralPath $details).LastWriteTime.ToString('o') } else { $null }
        has_series_hid = Test-Path -LiteralPath $shid
    }
}
$out | ConvertTo-Json -Depth 4 | Out-File -FilePath 'C:\Users\legoc\OneDrive\Belgeler\Scripts\CompareManga\_pc_repack.json' -Encoding utf8
# Summary to stdout
$total = $out.Count
$totBytes = ($out | Measure-Object cbz_bytes -Sum).Sum
$noCover = ($out | Where-Object { -not $_.has_cover }).Count
$noDetails = ($out | Where-Object { -not $_.has_details }).Count
Write-Output "series=$total  total_cbz_bytes=$totBytes  GB=$([math]::Round($totBytes/1GB,2))"
Write-Output "missing_cover=$noCover  missing_details=$noDetails"
# Distribution of newest-cbz date (day granularity)
$out | Group-Object { ([datetime]$_.cbz_mtime_max).ToString('yyyy-MM-dd') } | Sort-Object Name | ForEach-Object { Write-Output ("cbz_newest_day {0} = {1}" -f $_.Name, $_.Count) }
Write-Output "--- cover.jpg newest-day distribution ---"
$out | Where-Object { $_.has_cover } | Group-Object { ([datetime]$_.cover_mtime).ToString('yyyy-MM-dd') } | Sort-Object Name | ForEach-Object { Write-Output ("cover_day {0} = {1}" -f $_.Name, $_.Count) }

$path = 'C:\Users\legoc\OneDrive\Belgeler\AIO-Webtoon-Downloader\mangas'
$rows = @()
Get-ChildItem -Path $path -Directory -Force | Where-Object { $_.Name -ne '.aio_coord' } | Sort-Object Name | ForEach-Object {
    $folder = $_
    $files = Get-ChildItem -Path $folder.FullName -File -Force -ErrorAction SilentlyContinue
    $cbz = ($files | Where-Object { $_.Extension -ieq '.cbz' }).Count
    $pdf = ($files | Where-Object { $_.Extension -ieq '.pdf' }).Count
    $size = ($files | Measure-Object -Property Length -Sum).Sum
    if ($null -eq $size) { $size = 0 }
    $hasCover = Test-Path -LiteralPath (Join-Path $folder.FullName 'cover.jpg')
    $hasJson  = Test-Path -LiteralPath (Join-Path $folder.FullName '.aio_series.json')
    $rows += [PSCustomObject]@{
        folder    = $folder.Name
        size_mb   = [math]::Round($size / 1MB, 1)
        cbz       = $cbz
        pdf       = $pdf
        cover     = [bool]$hasCover
        aio_json  = [bool]$hasJson
    }
}
$rows | ConvertTo-Json -Depth 4 | Out-File -FilePath 'C:\Users\legoc\OneDrive\Belgeler\Scripts\CompareManga\_pc_sizes.json' -Encoding utf8
Write-Host ('Wrote {0} entries to _pc_sizes.json' -f $rows.Count)
Write-Host ('Total: {0:N2} GB' -f (($rows | Measure-Object -Property size_mb -Sum).Sum/1024))

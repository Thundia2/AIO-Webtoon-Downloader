"""
One-off final verification: per-folder .cbz count, PC vs tablet, alias-aware.

Uses push_all_to_tablet.build_plan to map each PC series to its TARGET tablet
folder name (handles the 14 aliases + hid strips), then compares PC cbz count
to the tablet folder's cbz count. Confirms the mirror is chapter-exact and
isolates SHELTER (tablet-only) from the totals. Read-only.
"""
import subprocess
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import compare_manga as cm
import push_all_to_tablet as p

ADB = cm.resolve_adb(None)
DEV = cm.DEFAULT_DEVICE_SERIAL
T = cm.DEFAULT_TABLET_ROOT


def adb_lines(shell_cmd: str) -> list[str]:
    r = subprocess.run([ADB, "-s", DEV, "shell", shell_cmd],
                       capture_output=True, encoding="utf-8", errors="replace")
    return [l.strip() for l in r.stdout.splitlines() if l.strip()]


# PC cbz counts per folder
pc = cm.scan_pc_library(p.PC_ROOT)
pc_cbz = {s.folder_name: sum(1 for c in s.chapter_files if c.fmt == "cbz")
          for s in pc}

# Tablet folders + per-folder cbz counts
tablet_folders = adb_lines(
    f"find '{T}' -mindepth 1 -maxdepth 1 -type d -printf '%f\\n'")
# toybox find lacks -printf %h, so list full cbz paths and derive the depth-1
# series folder in Python (the path component right after the tablet root).
tab_cbz = Counter()
for line in adb_lines(f"find '{T}' -mindepth 2 -maxdepth 2 -name '*.cbz'"):
    folder = line[len(T):].lstrip('/').split('/', 1)[0]
    tab_cbz[folder] += 1

# Map each PC series to its target tablet folder name
entries, tablet_only, alias_errors = p.build_plan(pc, sorted(tablet_folders))
assert not alias_errors, alias_errors

mismatches = []
for e in entries:
    pcn = pc_cbz.get(e.pc_canonical_folder, 0)
    tabn = tab_cbz.get(e.target_tablet_name, 0)
    if pcn != tabn:
        mismatches.append((e.target_tablet_name, e.pc_canonical_folder, pcn, tabn))

print(f"PC series:                 {len(entries)}")
print(f"chapter-count mismatches:  {len(mismatches)}")
for tgt, src, a, b in mismatches:
    print(f"   MISMATCH {tgt!r} (PC {src!r}): PC={a} tablet={b}")

pc_total = sum(pc_cbz.values())
tab_mirrored = sum(tab_cbz.get(e.target_tablet_name, 0) for e in entries)
print()
print(f"PC total cbz:                       {pc_total}")
print(f"tablet cbz across 111 mirrored:     {tab_mirrored}")
print(f"tablet cbz in tablet-only folders:  {sum(tab_cbz[f] for f in tablet_only)}  ({tablet_only})")
print(f"tablet cbz ALL folders:             {sum(tab_cbz.values())}")
print()
print("RESULT:", "PASS - mirror is chapter-exact" if not mismatches else "FAIL - see mismatches")

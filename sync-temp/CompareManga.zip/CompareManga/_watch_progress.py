"""
_watch_progress.py — event-driven progress watcher for the full-mirror run.

Tails push_all_to_tablet.py's APPEND-ONLY stderr trace (never the atomically
rewritten JSON log — reading that mid-run can collide with the writer's
os.replace on Windows and crash the run) and exits as soon as one of:
  - a new failure appears (count of '!! ERROR:' lines exceeds --seen-fails),
  - --target series have completed,
  - the run prints its final 'Done.' line,
  - --max-seconds elapse (heartbeat so the caller never goes dark).
Exit re-invokes the parent agent, which reads the trace and reports a batch.

"Completed" is derived from the '[ i/N ]' headers: while series i is mid-push
the header for i is the latest, so completed = latest-1 until the next header
prints (or 'Done.' sets it to N). grep '\\[\\s*\\d+/' in the stderr log.
"""
import argparse
import re
import sys
import time

HEADER_RE = re.compile(r'^\[\s*(\d+)/(\d+)\]', re.M)
DONE_RE = re.compile(r'^Done\.', re.M)
ERR_RE = re.compile(r'!! ERROR:')


def parse(path: str):
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            txt = f.read()
    except OSError:
        return 0, 0, 111, False
    headers = HEADER_RE.findall(txt)
    total = int(headers[-1][1]) if headers else 111
    latest = max((int(i) for i, _ in headers), default=0)
    done = bool(DONE_RE.search(txt))
    n_fail = len(ERR_RE.findall(txt))
    completed = total if done else max(latest - 1, 0)
    return completed, n_fail, total, done


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--log', required=True)
    ap.add_argument('--target', type=int, required=True)
    ap.add_argument('--seen-fails', type=int, default=0)
    ap.add_argument('--max-seconds', type=int, default=1500)
    ap.add_argument('--poll', type=int, default=15)
    a = ap.parse_args()
    start = time.time()
    while True:
        completed, n_fail, total, done = parse(a.log)
        if n_fail > a.seen_fails:
            print(f'TRIGGER=fail completed={completed} n_fail={n_fail} total={total}')
            return 0
        if done:
            print(f'TRIGGER=done completed={completed} n_fail={n_fail} total={total}')
            return 0
        if completed >= a.target:
            print(f'TRIGGER=batch completed={completed} n_fail={n_fail} total={total}')
            return 0
        if time.time() - start > a.max_seconds:
            print(f'TRIGGER=heartbeat completed={completed} n_fail={n_fail} total={total}')
            return 0
        time.sleep(a.poll)


if __name__ == '__main__':
    sys.exit(main())

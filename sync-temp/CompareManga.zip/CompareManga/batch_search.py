"""
batch_search.py — Run cross-site search for every tablet series in one process.

Goal: produce the best seed URL per tablet folder by calling AIO-Webtoon-Downloader's
search_orchestrator.search_all in a tight loop, reusing the MangaFire Playwright
session and the probe-failure / image-quality caches across queries.

Owns the (tablet_folder -> normalized_query) mapping table for the 64 tablet
series, plus incremental result persistence so an interruption mid-batch
doesn't lose progress.

Reads (depends on):
  - C:\\Users\\legoc\\OneDrive\\Belgeler\\AIO-Webtoon-Downloader\\sites\\search_orchestrator.py
  - C:\\Users\\legoc\\OneDrive\\Belgeler\\AIO-Webtoon-Downloader\\aio_search_cli.py
    (uses _scraper_factory_for + _search_make_request_factory helpers)

Writes:
  - seed_links.json (full top-3 candidates per series, JSON shape from
    SeriesCandidate.to_json)
  - seed_links.txt (human-readable: tablet_folder | top URL | site | score)

Resume: rerunning the script skips entries already present in seed_links.json
with a non-error status — so a Ctrl-C and rerun continues where it left off.
"""

from __future__ import annotations

import json
import os
import sys
import time
from argparse import Namespace
from pathlib import Path

AIO_DIR = Path(r"C:\Users\legoc\OneDrive\Belgeler\AIO-Webtoon-Downloader")
SCRIPT_DIR = Path(__file__).resolve().parent
OUT_JSON = SCRIPT_DIR / "seed_links.json"
OUT_TXT = SCRIPT_DIR / "seed_links.txt"

# aio modules use relative imports (sites.*) — must chdir + sys.path-insert.
os.chdir(str(AIO_DIR))
sys.path.insert(0, str(AIO_DIR))

from sites.search_orchestrator import (  # noqa: E402
    DEFAULT_MIN_MATCH,
    DEFAULT_PER_SITE_TIMEOUT_S,
    ImageQualityCache,
    ProbeFailureCache,
    search_all,
)
from aio_search_cli import (  # noqa: E402
    _scraper_factory_for,
    _search_make_request_factory,
)

# Lower the image-quality probe phase deadline from the default 120s to 45s.
# The probe is a tiebreaker refinement; top picks are stable without the full
# deadline budget, and the 64-query batch is otherwise dominated by it (some
# queries hit the full 120s, blowing wall time to ~80 min). 45s lets MangaFire
# Patchright VRF captures complete for the common case (warmup ~5s + a handful
# of ~2-3s chapter-VRF captures); remaining probes get scored via cached/seed.
import sites.search_orchestrator as _so  # noqa: E402

_so.PROBE_PHASE_DEADLINE_S = 45.0

# (tablet_folder, normalized_query) — folder is the literal tablet directory name,
# query is what we feed to search_all. Normalization rules:
#   - underscores -> spaces
#   - drop "(Official)" suffix (format hint, not part of title)
#   - keep "(Colored)" suffix (disambiguates a colored re-release)
#   - Vivy's wrapping dashes are dropped (search expects "Vivy Fluorite Eye's Song")
#   - "Is_the_order_a_rabbit" — official title has the trailing "?"
#   - everything else: just underscore -> space; AIO's rapidfuzz is forgiving
SERIES: list[tuple[str, str]] = [
    ("'Tis Time for Torture, Princess",                                     "'Tis Time for Torture, Princess"),
    ("2.5_Dimensional_Seduction",                                           "2.5 Dimensional Seduction"),
    ("A Certain Scientific Railgun",                                        "A Certain Scientific Railgun"),
    ("A Couple of Cuckoos",                                                 "A Couple of Cuckoos"),
    ("Angel Beats! Heaven's Door",                                          "Angel Beats! Heaven's Door"),
    ("Attack_on_Titan",                                                     "Attack on Titan"),
    ("Berserk",                                                             "Berserk"),
    ("Bleach",                                                              "Bleach"),
    ("Blue Box",                                                            "Blue Box"),
    ("Bungo Stray Dogs",                                                    "Bungo Stray Dogs"),
    ("Chainsaw Man",                                                        "Chainsaw Man"),
    ("Claymore",                                                            "Claymore"),
    ("CØDEBREAKER",                                                         "CØDEBREAKER"),
    ("Demon_Slayer_Kimetsu_no_Yaiba",                                       "Demon Slayer Kimetsu no Yaiba"),
    ("Dragon Ball",                                                         "Dragon Ball"),
    ("EDENS ZERO",                                                          "EDENS ZERO"),
    ("Eleceed",                                                             "Eleceed"),
    ("Every Day Is a Holiday (Colored)",                                    "Every Day Is a Holiday (Colored)"),
    ("Fly Me to the Moon",                                                  "Fly Me to the Moon"),
    ("Frieren Beyond Journey’s End",                                        "Frieren Beyond Journey's End"),
    ("Fullmetal Alchemist",                                                 "Fullmetal Alchemist"),
    ("Horimiya",                                                            "Horimiya"),
    ("I Was Supposed to Never Fall in Love with You",                       "I Was Supposed to Never Fall in Love with You"),
    ("Is_the_order_a_rabbit",                                               "Is the order a rabbit?"),
    ("JoJo's Bizarre Adventure Part 5 Golden Wind",                         "JoJo's Bizarre Adventure Part 5 Golden Wind"),
    ("JoJo's Bizarre Adventure Part 6 Stone Ocean",                         "JoJo's Bizarre Adventure Part 6 Stone Ocean"),
    ("JoJo's_Bizarre_Adventure_Part_1_Phantom_Blood",                       "JoJo's Bizarre Adventure Part 1 Phantom Blood"),
    ("JoJo's_Bizarre_Adventure_Part_2_Battle_Tendency",                     "JoJo's Bizarre Adventure Part 2 Battle Tendency"),
    ("JoJo's_Bizarre_Adventure_Part_3_Stardust_Crusaders",                  "JoJo's Bizarre Adventure Part 3 Stardust Crusaders"),
    ("JoJo's_Bizarre_Adventure_Part_4_Diamond_is_Unbreakable",              "JoJo's Bizarre Adventure Part 4 Diamond is Unbreakable"),
    ("Kagurabachi",                                                         "Kagurabachi"),
    ("Komi_Can't_Communicate",                                              "Komi Can't Communicate"),
    ("Konosuba God's Blessing on This Wonderful World!",                    "Konosuba God's Blessing on This Wonderful World!"),
    ("Link Click",                                                          "Link Click"),
    ("Lycoris_Recoil",                                                      "Lycoris Recoil"),
    ("Made_in_Abyss",                                                       "Made in Abyss"),
    ("Makeine Make Hiroin ga Ōsugiru!",                                     "Makeine Make Hiroin ga Ōsugiru!"),
    ("My youth romantic comedy is wrong as I expected",                     "My youth romantic comedy is wrong as I expected"),
    ("No Longer Allowed In Another World",                                  "No Longer Allowed In Another World"),
    ("No More Love With the Girls",                                         "No More Love With the Girls"),
    ("One-Punch_Man_(Official)",                                            "One-Punch Man"),
    ("Pandora Hearts",                                                      "Pandora Hearts"),
    ("Pandora Seven",                                                       "Pandora Seven"),
    ("Pandora's Box",                                                       "Pandora's Box"),
    ("Record of Ragnarok",                                                  "Record of Ragnarok"),
    ("Rinjin-chan ga Shinpai",                                              "Rinjin-chan ga Shinpai"),
    ("SHELTER",                                                             "SHELTER"),
    ("SPY_x_FAMILY",                                                        "SPY x FAMILY"),
    ("Sakamoto Days",                                                       "Sakamoto Days"),
    ("Sentenced to Be a Hero The Prison Records of Penal Hero Unit 9004",   "Sentenced to Be a Hero The Prison Records of Penal Hero Unit 9004"),
    ("Shiunji-ke no Kodomotachi",                                           "Shiunji-ke no Kodomotachi"),
    ("Sleepy Princess in the Demon Castle",                                 "Sleepy Princess in the Demon Castle"),
    ("Solo Leveling",                                                       "Solo Leveling"),
    ("Talentless Nana",                                                     "Talentless Nana"),
    ("That Time I Got Reincarnated as a Slime",                             "That Time I Got Reincarnated as a Slime"),
    ("The Angel Next Door Spoils Me Rotten",                                "The Angel Next Door Spoils Me Rotten"),
    ("The Angel Next Door Spoils Me Rotten After the Rain",                 "The Angel Next Door Spoils Me Rotten After the Rain"),
    ("The Apothecary Diaries",                                              "The Apothecary Diaries"),
    ("The Legend of the Northern Blade",                                    "The Legend of the Northern Blade"),
    ("Tower of God",                                                        "Tower of God"),
    ("Undead Unluck",                                                       "Undead Unluck"),
    ("Vivy_-Fluorite_Eye's_Song-",                                          "Vivy Fluorite Eye's Song"),
    ("You and I are Polar Opposites",                                       "You and I are Polar Opposites"),
    ("You are Ms. Servant",                                                 "You are Ms. Servant"),
]

assert len(SERIES) == 64, f"expected 64 series, got {len(SERIES)}"


def make_args() -> Namespace:
    """Build the argparse.Namespace fields that _scraper_factory_for and
    _search_make_request_factory read. Mirrors aio-dl.py defaults for the
    search-relevant flags only — every handler.configure_session call
    tolerates missing attributes (it's a best-effort hook)."""
    return Namespace(
        cookies="",
        language="en",
        search_language="en",
        search_parallelism=6,
        search_timeout=DEFAULT_PER_SITE_TIMEOUT_S,
        search_min_match=DEFAULT_MIN_MATCH,
        auto_pick=False,
        search_json=True,
        seeded_only=True,
        multi_source=False,
        collapse_splits=True,
    )


def load_existing_results() -> dict:
    if not OUT_JSON.exists():
        return {}
    try:
        with open(OUT_JSON, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return {}


def save_results(results: dict) -> None:
    tmp = OUT_JSON.with_suffix(".json.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    os.replace(tmp, OUT_JSON)


def render_txt(results: dict) -> None:
    lines = [
        "# Best seed link per tablet series (--seeded-only search)",
        "# Format: tablet_folder | top_url | top_site | composite_score | candidate_title",
        "",
    ]
    for folder, _ in SERIES:
        rec = results.get(folder)
        if rec is None:
            lines.append(f"{folder} | (not yet searched)")
            continue
        if rec.get("error"):
            lines.append(f"{folder} | ERROR: {rec['error']}")
            continue
        cands = rec.get("candidates") or []
        if not cands or not cands[0].get("sources"):
            lines.append(f"{folder} | (no candidates) | query={rec.get('query')!r}")
            continue
        top = cands[0]
        s = top["sources"][0]
        lines.append(
            f"{folder} | {s['url']} | {s['site']} | "
            f"{s['composite_score']:.3f} | {top['canonical_title']!r}"
        )
    with open(OUT_TXT, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def main() -> int:
    args = make_args()
    factory = _scraper_factory_for(args)
    search_mr = _search_make_request_factory(timeout=args.search_timeout, attempts=2)
    probe_cache = ProbeFailureCache(record_cooldown=None)
    img_cache = ImageQualityCache()

    results = load_existing_results()
    if results:
        print(f"[*] resuming: {len(results)} existing entries", file=sys.stderr)

    t_total = time.time()
    for i, (folder, query) in enumerate(SERIES, 1):
        if folder in results and not results[folder].get("error"):
            print(f"[{i:2d}/64] skip (cached) {folder!r}", file=sys.stderr)
            continue
        print(f"[{i:2d}/64] searching '{query}'  (folder={folder!r})", file=sys.stderr)
        t0 = time.time()
        try:
            candidates = search_all(
                query,
                factory,
                search_mr,
                language="en",
                parallelism=6,
                per_site_timeout_s=DEFAULT_PER_SITE_TIMEOUT_S,
                min_match=DEFAULT_MIN_MATCH,
                probe_failure_cache=probe_cache,
                img_quality_cache=img_cache,
                on_status=lambda m: print(f"      {m}", file=sys.stderr),
                seeded_only=True,
            )
        except Exception as exc:  # noqa: BLE001 — broad on purpose, log and move on
            elapsed = time.time() - t0
            print(f"      !! {type(exc).__name__}: {exc} ({elapsed:.1f}s)", file=sys.stderr)
            results[folder] = {
                "query": query,
                "error": f"{type(exc).__name__}: {exc}",
                "elapsed_sec": elapsed,
                "candidates": [],
            }
            save_results(results)
            render_txt(results)
            continue
        elapsed = time.time() - t0
        top_url = None
        top_site = None
        if candidates and candidates[0].sources:
            top_url = candidates[0].sources[0].url
            top_site = candidates[0].sources[0].site
        print(
            f"      => {len(candidates)} candidates in {elapsed:.1f}s; "
            f"top={top_site} {top_url}",
            file=sys.stderr,
        )
        results[folder] = {
            "query": query,
            "elapsed_sec": round(elapsed, 2),
            "candidates": [c.to_json() for c in candidates[:5]],  # top-5 keeps file lean
        }
        save_results(results)
        render_txt(results)

    total_elapsed = time.time() - t_total
    n_ok = sum(1 for r in results.values() if r.get("candidates"))
    n_err = sum(1 for r in results.values() if r.get("error"))
    print(
        f"\n[*] done: {n_ok}/{len(SERIES)} ok, {n_err} errors, "
        f"{total_elapsed/60:.1f} min total. Wrote {OUT_JSON} and {OUT_TXT}.",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())

"""
compare_manga.py — Read-only comparator for the AIO-Webtoon-Downloader manga
library and a USB-attached Android tablet.

Owns the diff/report between a local PC manga folder tree and a tablet manga
tree (served to Perfect Viewer). Never writes to either library.

Reads:
  - PC root layout: <pc_root>/<series>/<Series> Ch <label>.{pdf,cbz}
                    <pc_root>/<series>/.aio_series.json  (status, format,
                    chapters_downloaded, ...). Some series have a "(hid=X)"
                    suffix in the folder name; multiples are common (One Piece,
                    Kingdom, Tokyo Ghoul, The Beginning After the End).
  - Tablet via adb: `adb shell find <tablet_root> -type f -printf '%s|%T@|%p\n'`.
                    Tablet has six chapter-filename patterns (see CHAPTER_PATTERNS).

Depends on:
  - adb on PATH, or at the KNOWN_ADB_PATH fallback.
  - The .aio_series.json schema produced by AIO-Webtoon-Downloader (aio-dl.py).
  - The chapter-label sort key from aio-dl.py:3061 (`_chapter_label_sort_key`)
    is ported verbatim below — chapters order the same way AIO does (full
    chapters sort before partials of the same main number: 8 < 8~5 < 8.5 < 9).

Known limitation: tablet paths containing literal '\n' or '|' would confuse the
bulk-find stdout parser. No real paths in the observed library hit this.

Python 3.10+.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import time
import unicodedata
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path


# ============================================================================
# Constants
# ============================================================================

# PC library moved off OneDrive to D:\AIO\manga on 2026-06-14 (the old
# AIO-Webtoon-Downloader\mangas path no longer exists). push_all_to_tablet.py
# has no --pc-root flag and reads this constant directly, so this is the single
# source of truth for the library root; grep DEFAULT_PC_ROOT for the ~2 readers.
DEFAULT_PC_ROOT = Path(r"D:\AIO\manga")
DEFAULT_TABLET_ROOT = "/storage/self/primary/Documents"
DEFAULT_DEVICE_SERIAL = "3CEF42502E91537"
KNOWN_ADB_PATH = Path(r"C:\Users\legoc\OneDrive\Belgeler\Scripts\ADB\platform-tools\adb.exe")
DEFAULT_CACHE_TTL_HOURS = 24.0
DEFAULT_SIZE_THRESHOLD_PCT = 30.0
SCRIPT_DIR = Path(__file__).resolve().parent

# Top-level entries in the PC manga root to ignore (AIO's coordinator state).
IGNORE_TOP_LEVEL = {".aio_coord", ".aio_folder_alloc.lock"}
# Per-series sidecars that aren't chapter files.
IGNORE_SERIES_FILES = {".aio_series.json", ".mangafire_hid"}

# Six chapter-filename patterns; first match wins. Try-list rather than one
# union regex because patterns shadow ambiguously (Pattern A's lazy prefix
# could absorb a "_Ch_" infix before Pattern B's anchor — sequencing avoids it).
RE_CH_SPACES = re.compile(
    r"^(?P<prefix>.+?)\s+Ch\s+(?P<label>\d+(?:[.~]\d+)?)\s*\.(?P<ext>pdf|cbz)$",
    re.IGNORECASE,
)
RE_CH_UNDERSCORED = re.compile(
    r"^(?P<prefix>.+?)_(?P<site>[a-z]+)_Ch_(?P<label>\d+(?:[.~]\d+)?)\s*\.(?P<ext>pdf|cbz)$",
    re.IGNORECASE,
)
RE_CH_CHAP_TITLE = re.compile(
    r"^Chap\s+(?P<label>\d+(?:[.~]\d+)?)\b.*\.(?P<ext>pdf|cbz)$",
    re.IGNORECASE,
)
RE_CH_CHAPTER = re.compile(
    r"^Chapter\s+(?P<label>\d+(?:[.~]\d+)?)\s*\.(?P<ext>pdf|cbz)$",
    re.IGNORECASE,
)
RE_CH_HASH = re.compile(
    r"^#(?P<label>\d+)\s*-.*\.(?P<ext>pdf|cbz)$",
    re.IGNORECASE,
)
RE_CH_VOL = re.compile(
    r"^Vol\s+(?P<label>\d+)\s*\.(?P<ext>pdf|cbz)$",
    re.IGNORECASE,
)

CHAPTER_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("A", RE_CH_SPACES),
    ("B", RE_CH_UNDERSCORED),
    ("C", RE_CH_CHAP_TITLE),
    ("D", RE_CH_CHAPTER),
    ("E", RE_CH_HASH),
    ("F", RE_CH_VOL),
]

# Matches " (hid=X)" suffix on PC series folder names. Inner group is .*? so
# the empty case "Tokyo Ghoul (hid=)" is captured too.
RE_HID_SUFFIX = re.compile(r"^(.+?)\s*\(hid=(.*?)\)\s*$")

# Punctuation handling for normalize_series_name. Apostrophes (straight + both
# curly) get DELETED so "Pandora's" -> "pandoras" without an awkward space.
# Other punctuation maps to space so "Tokyo Ghoul (hid=)" first becomes
# "Tokyo Ghoul" (after suffix strip), then "tokyo ghoul" after lowering.
_APOS_CHARS = "'’‘"
_PUNCT_TO_SPACE = "\"“”,.!?:;()[]-–—/"
_APOS_TABLE = str.maketrans({c: "" for c in _APOS_CHARS})
_PUNCT_TABLE = str.maketrans({c: " " for c in _PUNCT_TO_SPACE})

# ANSI escape codes; emitted only when stdout is a TTY and --no-color not set.
ANSI = {
    "reset": "\x1b[0m",
    "bold": "\x1b[1m",
    "dim": "\x1b[2m",
    "red": "\x1b[31m",
    "yellow": "\x1b[33m",
    "magenta": "\x1b[35m",
    "cyan": "\x1b[36m",
    "bold_cyan": "\x1b[1;36m",
    "bold_red": "\x1b[1;31m",
    "bold_yellow": "\x1b[1;33m",
}
_USE_COLOR = False


def _c(text: str, color: str) -> str:
    if not _USE_COLOR:
        return text
    code = ANSI.get(color)
    if not code:
        return text
    return f"{code}{text}{ANSI['reset']}"


CACHE_VERSION = 2
# v2 (2026-05): cache now stores top-level tablet directories too, so empty
# series folders register instead of disappearing from the diff.


# ============================================================================
# Dataclasses
# ============================================================================


@dataclass(frozen=True)
class ChapterFile:
    series_folder: str       # immediate parent folder name on disk
    filename: str            # bare filename, or relative path for nested tablet files
    label: str | None        # canonical label like "107.5"; None if unmatched
    label_sort_key: tuple
    size_bytes: int
    mtime_unix: float
    fmt: str                 # "pdf" / "cbz" / "" (lowercase, no leading dot)
    pattern_used: str        # "A".."F" or "unmatched"


@dataclass
class PCSeries:
    folder_name: str                     # raw, may include "(hid=X)" suffix
    base_name: str                       # folder_name with hid suffix stripped
    hid_suffix: str | None               # the captured hid, may be ""
    abs_path: Path
    json_path: Path | None
    title: str | None
    status: str                          # "Completed" / "Ongoing" / "Unknown"
    site: str | None
    fmt_canonical: str | None
    chapters_in_json: list[str] | None
    chapter_files: list[ChapterFile] = field(default_factory=list)
    json_malformed: bool = False


@dataclass
class TabletSeries:
    folder_name: str
    abs_path: str                        # adb-side absolute path
    chapter_files: list[ChapterFile] = field(default_factory=list)


@dataclass
class MatchedSeries:
    norm_key: str
    pc: list[PCSeries]                   # zero+ — hid variants collapse here
    tablet: TabletSeries | None


@dataclass(frozen=True)
class ChapterGap:
    label: str
    in_pc: bool
    in_tablet: bool
    pc_size: int | None
    tablet_size: int | None
    pc_format: str | None
    tablet_format: str | None
    size_delta_pct: float | None


@dataclass(frozen=True)
class Anomaly:
    kind: str           # see _ANOMALY_KIND_ORDER for the canonical list
    severity: str       # "info" / "warn" / "error"
    series: str | None
    detail: str
    payload: dict


_ANOMALY_KIND_ORDER = [
    "hid_variants",
    "format_mismatch",
    "size_mismatch",
    "single_bundled_file",
    "orphan",
    "empty_pc_folder",
    "malformed_json",
]


# ============================================================================
# Pure helpers
# ============================================================================


def chapter_label_sort_key(label: str | None) -> tuple:
    """Stable numeric-ish ordering for chapter labels.

    Port of `_chapter_label_sort_key` in aio-dl.py:3061. Full chapters sort
    before partials of the same number: 8 < 8~5 < 8.5 < 9.
    """
    if label is None:
        return (10**9, 1, 0, "")
    s = label.strip()
    if not s:
        return (10**9, 1, 0, "")
    s_norm = s.replace("~", ".")
    m = re.match(r"^(\d+)(?:\.(\d+))?", s_norm)
    if not m:
        return (10**9, 1, 0, s_norm.lower())
    main = int(m.group(1))
    sub = m.group(2)
    if sub is None:
        return (main, 0, 0, s_norm.lower())
    try:
        sub_i = int(sub)
    except ValueError:
        sub_i = 0
    return (main, 1, sub_i, s_norm.lower())


def _canonicalize_label(raw: str) -> str:
    """Stable string form of a raw chapter label.

    Tilde and dot are interchangeable per AIO (1~5 == 1.5). Leading zeros are
    stripped from a pure-integer label (01 -> 1) but preserved when there is a
    decimal portion (so 315.01 stays distinct from 315.1).
    """
    s = raw.strip().replace("~", ".")
    if "." in s:
        int_part, dec_part = s.split(".", 1)
        if dec_part == "0":
            try:
                return str(int(int_part))
            except ValueError:
                return s
        return s
    try:
        return str(int(s))
    except ValueError:
        return s


def parse_chapter_label(filename: str) -> tuple[str | None, str, str]:
    """Return (canonical_label, ext_lowercase, pattern_letter) for a filename."""
    for letter, pat in CHAPTER_PATTERNS:
        m = pat.match(filename)
        if m:
            raw_label = m.group("label")
            ext = m.group("ext").lower()
            return (_canonicalize_label(raw_label), ext, letter)
    _, dot, ext = filename.rpartition(".")
    return (None, ext.lower() if dot else "", "unmatched")


def normalize_series_name(name: str) -> str:
    """Canonicalize a series folder name for cross-side matching.

    Strips a trailing "(hid=X)" suffix, NFKC + casefolds, maps underscores to
    spaces, deletes apostrophes (so "Pandora's" -> "pandoras"), maps remaining
    punctuation to space, and collapses whitespace.
    """
    m = RE_HID_SUFFIX.match(name)
    if m:
        name = m.group(1)
    s = unicodedata.normalize("NFKC", name).casefold()
    s = s.replace("_", " ")
    s = s.translate(_APOS_TABLE)
    s = s.translate(_PUNCT_TABLE)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def format_size(n: int | float | None) -> str:
    """Human-readable byte count: '1.2 MB', '512 B'. None -> '-'."""
    if n is None:
        return "-"
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024.0:
            if unit == "B":
                return f"{int(n)} {unit}"
            return f"{n:.1f} {unit}"
        n /= 1024.0
    return f"{n:.1f} PB"


def _strip_hid(name: str) -> tuple[str, str | None]:
    m = RE_HID_SUFFIX.match(name)
    if m:
        return m.group(1).strip(), m.group(2)
    return name, None


# ============================================================================
# PC scan
# ============================================================================


def scan_pc_library(pc_root: Path) -> list[PCSeries]:
    if not pc_root.is_dir():
        raise FileNotFoundError(f"PC root not found: {pc_root}")
    series: list[PCSeries] = []
    with os.scandir(pc_root) as it:
        for entry in it:
            if entry.name.startswith(".") or entry.name in IGNORE_TOP_LEVEL:
                continue
            try:
                if not entry.is_dir():
                    continue
            except OSError:
                continue
            series.append(_scan_pc_series(Path(entry.path)))
    series.sort(key=lambda s: s.folder_name.casefold())
    return series


def _scan_pc_series(series_dir: Path) -> PCSeries:
    folder_name = series_dir.name
    base_name, hid_suffix = _strip_hid(folder_name)

    json_path: Path | None = series_dir / ".aio_series.json"
    title: str | None = None
    status = "Unknown"
    site: str | None = None
    fmt_canonical: str | None = None
    chapters_in_json: list[str] | None = None
    json_malformed = False

    if json_path.is_file():
        try:
            with open(json_path, "r", encoding="utf-8") as f:
                meta = json.load(f)
            if isinstance(meta, dict):
                title = (meta.get("title") or None)
                status = (meta.get("status") or "Unknown")
                site = (meta.get("site") or None)
                fmt_canonical = (meta.get("format") or None)
                cd = meta.get("chapters_downloaded")
                if isinstance(cd, list):
                    chapters_in_json = [str(c) for c in cd]
            else:
                json_malformed = True
        except (json.JSONDecodeError, OSError, UnicodeDecodeError):
            json_malformed = True
    else:
        json_path = None

    chapter_files: list[ChapterFile] = []
    try:
        with os.scandir(series_dir) as it:
            for entry in it:
                if entry.name.startswith("."):
                    continue
                if entry.name in IGNORE_SERIES_FILES:
                    continue
                try:
                    if not entry.is_file():
                        continue
                except OSError:
                    continue
                lower = entry.name.lower()
                if not (lower.endswith(".pdf") or lower.endswith(".cbz")):
                    continue
                label, ext, pat = parse_chapter_label(entry.name)
                try:
                    stat = entry.stat()
                    size = stat.st_size
                    mtime = stat.st_mtime
                except OSError:
                    size = 0
                    mtime = 0.0
                chapter_files.append(ChapterFile(
                    series_folder=folder_name,
                    filename=entry.name,
                    label=label,
                    label_sort_key=chapter_label_sort_key(label),
                    size_bytes=size,
                    mtime_unix=mtime,
                    fmt=ext,
                    pattern_used=pat,
                ))
    except OSError:
        pass

    chapter_files.sort(key=lambda c: c.label_sort_key)
    return PCSeries(
        folder_name=folder_name,
        base_name=base_name,
        hid_suffix=hid_suffix,
        abs_path=series_dir,
        json_path=json_path,
        title=title,
        status=status,
        site=site,
        fmt_canonical=fmt_canonical,
        chapters_in_json=chapters_in_json,
        chapter_files=chapter_files,
        json_malformed=json_malformed,
    )


# ============================================================================
# Tablet scan (adb)
# ============================================================================


def resolve_adb(override: str | None) -> str:
    if override:
        if not Path(override).is_file():
            raise FileNotFoundError(f"adb not found at: {override}")
        return override
    found = shutil.which("adb")
    if found:
        return found
    if KNOWN_ADB_PATH.is_file():
        return str(KNOWN_ADB_PATH)
    raise FileNotFoundError(
        "adb not found on PATH and not at the known fallback location "
        f"({KNOWN_ADB_PATH}). Pass --adb to specify a path."
    )


def resolve_device(adb_exe: str, override: str | None) -> str:
    proc = subprocess.run(
        [adb_exe, "devices"],
        capture_output=True,
        timeout=15,
    )
    out = proc.stdout.decode("utf-8", errors="replace")
    serials: list[str] = []
    for line in out.splitlines()[1:]:
        line = line.strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) >= 2 and parts[1] == "device":
            serials.append(parts[0])
    if override:
        if override in serials:
            return override
        raise RuntimeError(
            f"Device {override!r} not found. Connected: {serials}"
        )
    if not serials:
        raise RuntimeError("No devices connected. Run: adb devices")
    if len(serials) == 1:
        return serials[0]
    if DEFAULT_DEVICE_SERIAL in serials:
        return DEFAULT_DEVICE_SERIAL
    raise RuntimeError(
        f"Multiple devices connected: {serials}. Specify --device."
    )


_DIR_SENTINEL = "---COMPARE_MANGA_DIRS_END---"


def _parse_combined_stdout(raw: str) -> tuple[list[str], list[tuple[int, float, str]]]:
    """Split a combined dirs+files stream on the sentinel. Returns (dir_paths,
    file_entries). Each file entry is (size, mtime, path)."""
    dirs: list[str] = []
    files: list[tuple[int, float, str]] = []
    in_files = False
    for line in raw.splitlines():
        line = line.rstrip("\r")
        if not line:
            continue
        if line == _DIR_SENTINEL:
            in_files = True
            continue
        if not in_files:
            dirs.append(line)
            continue
        if "|" not in line:
            continue
        try:
            size_str, mtime_str, path = line.split("|", 2)
            files.append((int(size_str), float(mtime_str), path))
        except ValueError:
            continue
    return dirs, files


def _run_adb_find(adb_exe: str, device: str, tablet_root: str) -> tuple[list[tuple[int, float, str]], list[str], float, bool]:
    """One-roundtrip enumeration. Returns (file_entries, dir_paths, duration_sec, used_fallback).

    Bulk `find -printf` instead of per-file `stat` because adb shell roundtrip
    is the dominant cost; a single command is ~5s for 11.6k files where per-
    file stat would be hundreds of roundtrips. We also emit a depth-1 dir
    listing in the same call so empty series folders register in the diff
    instead of disappearing.
    """
    cmd = (
        f"find {shlex.quote(tablet_root)} -mindepth 1 -maxdepth 1 -type d 2>/dev/null; "
        f"echo {_DIR_SENTINEL}; "
        f"find {shlex.quote(tablet_root)} -type f -printf '%s|%T@|%p\\n' 2>/dev/null"
    )
    start = time.time()
    proc = subprocess.run(
        [adb_exe, "-s", device, "shell", cmd],
        capture_output=True,
        timeout=180,
    )
    duration = time.time() - start
    stderr = proc.stderr.decode("utf-8", errors="replace")
    if "-printf: not implemented" in stderr or "find: -printf" in stderr or "unknown option" in stderr.lower():
        entries, dirs, dur = _run_adb_find_stat_fallback(adb_exe, device, tablet_root)
        return entries, dirs, dur, True
    if proc.returncode != 0 and not proc.stdout:
        raise RuntimeError(
            f"adb shell find failed (exit {proc.returncode}): {stderr.strip()[:200]}"
        )
    dirs, entries = _parse_combined_stdout(proc.stdout.decode("utf-8", errors="replace"))
    return entries, dirs, duration, False


def _run_adb_find_stat_fallback(adb_exe: str, device: str, tablet_root: str) -> tuple[list[tuple[int, float, str]], list[str], float]:
    cmd = (
        f"find {shlex.quote(tablet_root)} -mindepth 1 -maxdepth 1 -type d 2>/dev/null; "
        f"echo {_DIR_SENTINEL}; "
        f"find {shlex.quote(tablet_root)} -type f -exec stat -c '%s|%Y|%n' {{}} + 2>/dev/null"
    )
    start = time.time()
    proc = subprocess.run(
        [adb_exe, "-s", device, "shell", cmd],
        capture_output=True,
        timeout=600,
    )
    duration = time.time() - start
    dirs, entries = _parse_combined_stdout(proc.stdout.decode("utf-8", errors="replace"))
    return entries, dirs, duration


def load_cache(
    cache_path: Path,
    device: str,
    tablet_root: str,
    ttl_hours: float,
) -> tuple[tuple[list[tuple[int, float, str]], list[str]] | None, str]:
    if not cache_path.is_file():
        return None, "miss_absent"
    try:
        with open(cache_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError, UnicodeDecodeError):
        return None, "miss_corrupt"
    if data.get("version") != CACHE_VERSION:
        return None, "miss_version"
    if data.get("device") != device or data.get("tablet_root") != tablet_root:
        return None, "miss_mismatch"
    scanned_at = float(data.get("scanned_at_unix") or 0)
    age_hours = (time.time() - scanned_at) / 3600.0
    if age_hours > ttl_hours:
        return None, "miss_stale"
    files = data.get("files") or []
    dirs = data.get("dirs") or []
    try:
        entries = [(int(f["s"]), float(f["m"]), f["p"]) for f in files]
        dir_list = [str(d) for d in dirs]
    except (KeyError, TypeError, ValueError):
        return None, "miss_corrupt"
    return (entries, dir_list), f"hit ({age_hours:.1f}h old, {len(entries)} files, {len(dir_list)} dirs)"


def save_cache(
    cache_path: Path,
    device: str,
    tablet_root: str,
    entries: list[tuple[int, float, str]],
    dirs: list[str],
    duration_sec: float,
) -> None:
    payload = {
        "version": CACHE_VERSION,
        "device": device,
        "tablet_root": tablet_root,
        "scanned_at_unix": time.time(),
        "scan_duration_sec": duration_sec,
        "file_count": len(entries),
        "dir_count": len(dirs),
        "files": [{"p": p, "s": s, "m": m} for s, m, p in entries],
        "dirs": dirs,
    }
    tmp = cache_path.with_suffix(cache_path.suffix + ".tmp")
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False)
    os.replace(tmp, cache_path)


def scan_tablet_library(
    adb_exe: str,
    device: str,
    tablet_root: str,
    cache_path: Path,
    refresh: bool,
    ttl_hours: float,
) -> tuple[list[TabletSeries], list[Anomaly], str, int]:
    """Returns (series_list, anomalies, cache_status_string, total_file_count)."""
    anomalies: list[Anomaly] = []
    cache_data: tuple[list[tuple[int, float, str]], list[str]] | None = None
    if refresh:
        cache_status = "miss_refresh"
    else:
        cache_data, cache_status = load_cache(cache_path, device, tablet_root, ttl_hours)
    if cache_data is None:
        live_entries, live_dirs, duration, used_fallback = _run_adb_find(adb_exe, device, tablet_root)
        save_cache(cache_path, device, tablet_root, live_entries, live_dirs, duration)
        entries = live_entries
        dirs = live_dirs
        if used_fallback:
            cache_status = f"miss; fresh scan via stat fallback ({duration:.1f}s, {len(entries)} files, {len(dirs)} dirs)"
            anomalies.append(Anomaly(
                kind="orphan",
                severity="info",
                series=None,
                detail="adb find lacks -printf; used stat fallback (slower).",
                payload={"reason": "printf_not_implemented"},
            ))
        else:
            cache_status = f"fresh scan ({duration:.1f}s, {len(entries)} files, {len(dirs)} dirs)"
    else:
        entries, dirs = cache_data

    root_norm = tablet_root.rstrip("/") + "/"
    grouped: dict[str, list[ChapterFile]] = {}
    abs_paths: dict[str, str] = {}
    loose_top: list[ChapterFile] = []

    for size, mtime, path in entries:
        if not path.startswith(root_norm):
            continue
        rel = path[len(root_norm):]
        if not rel:
            continue
        # Skip leading-dot basenames (sidecars like .mangafire_hid copied
        # from the PC, or system files like .thumbnails) and the PC's own
        # JSON metadata if it ever gets copied across.
        base = os.path.basename(rel)
        if base.startswith(".") or base in IGNORE_SERIES_FILES:
            continue
        if "/" not in rel:
            label, ext, pat = parse_chapter_label(rel)
            loose_top.append(ChapterFile(
                series_folder="<loose>",
                filename=rel,
                label=label,
                label_sort_key=chapter_label_sort_key(label),
                size_bytes=size,
                mtime_unix=mtime,
                fmt=ext,
                pattern_used=pat,
            ))
            continue
        series_folder, _, sub = rel.partition("/")
        if "/" in sub:
            label, ext, pat = parse_chapter_label(os.path.basename(sub))
            cf = ChapterFile(
                series_folder=series_folder,
                filename=sub,
                label=label,
                label_sort_key=chapter_label_sort_key(label),
                size_bytes=size,
                mtime_unix=mtime,
                fmt=ext,
                pattern_used=pat,
            )
        else:
            label, ext, pat = parse_chapter_label(sub)
            cf = ChapterFile(
                series_folder=series_folder,
                filename=sub,
                label=label,
                label_sort_key=chapter_label_sort_key(label),
                size_bytes=size,
                mtime_unix=mtime,
                fmt=ext,
                pattern_used=pat,
            )
        grouped.setdefault(series_folder, []).append(cf)
        abs_paths[series_folder] = root_norm + series_folder

    # Add empty TabletSeries for any depth-1 directory not represented in
    # `grouped` — these are folders the tablet has but with no files inside.
    # Without this an empty Frieren folder (only metadata, no chapters) would
    # disappear from the diff entirely and the corresponding PC series would
    # be misclassified as tablet-missing.
    for dpath in dirs:
        if not dpath.startswith(root_norm):
            continue
        folder = dpath[len(root_norm):].rstrip("/")
        if not folder or "/" in folder:
            continue
        if folder not in grouped:
            grouped[folder] = []
            abs_paths[folder] = root_norm + folder

    series_list: list[TabletSeries] = []
    for folder, cfs in grouped.items():
        cfs.sort(key=lambda c: c.label_sort_key)
        series_list.append(TabletSeries(
            folder_name=folder,
            abs_path=abs_paths.get(folder, root_norm + folder),
            chapter_files=cfs,
        ))
    series_list.sort(key=lambda s: s.folder_name.casefold())

    if loose_top:
        anomalies.append(Anomaly(
            kind="orphan",
            severity="warn",
            series=None,
            detail=f"{len(loose_top)} loose file(s) directly under {tablet_root} (no series folder).",
            payload={"count": len(loose_top), "files": [c.filename for c in loose_top]},
        ))

    return series_list, anomalies, cache_status, len(entries)


# ============================================================================
# Matching / diffing
# ============================================================================


def build_series_index(
    pc: list[PCSeries],
    tablet: list[TabletSeries],
) -> tuple[list[MatchedSeries], list[Anomaly]]:
    """Group PC + tablet folders by normalized name. PC hid variants collapse
    into a list under the same key. Returns (matched_list, anomalies)."""
    anomalies: list[Anomaly] = []
    pc_by_norm: dict[str, list[PCSeries]] = {}
    for s in pc:
        pc_by_norm.setdefault(normalize_series_name(s.folder_name), []).append(s)
    tab_by_norm: dict[str, TabletSeries] = {}
    tab_collisions: dict[str, list[str]] = {}
    for s in tablet:
        norm = normalize_series_name(s.folder_name)
        if norm in tab_by_norm:
            tab_collisions.setdefault(norm, [tab_by_norm[norm].folder_name]).append(s.folder_name)
            continue
        tab_by_norm[norm] = s
    for norm, folders in tab_collisions.items():
        anomalies.append(Anomaly(
            kind="orphan",
            severity="warn",
            series=norm,
            detail=f"Multiple tablet folders normalize to {norm!r}: {folders}. Using first; rest ignored.",
            payload={"norm_key": norm, "folders": folders},
        ))
    keys = sorted(set(pc_by_norm) | set(tab_by_norm))
    matched = [
        MatchedSeries(norm_key=k, pc=pc_by_norm.get(k, []), tablet=tab_by_norm.get(k))
        for k in keys
    ]
    return matched, anomalies


def _aggregate_pc_chapters(variants: list[PCSeries]) -> dict[str, ChapterFile]:
    """Union of chapter files across hid variants. First occurrence wins on
    duplicate labels; iteration order is the order variants were appended (PC
    scan order). Files with label=None are excluded (rare on PC)."""
    result: dict[str, ChapterFile] = {}
    for v in variants:
        for cf in v.chapter_files:
            if cf.label is None:
                continue
            if cf.label in result:
                continue
            result[cf.label] = cf
    return result


def _tablet_chapters(t: TabletSeries) -> dict[str, ChapterFile]:
    """Depth-1 only; nested files are excluded from gap comparison and surface
    as orphan-summary anomalies instead."""
    result: dict[str, ChapterFile] = {}
    for cf in t.chapter_files:
        if cf.label is None:
            continue
        if "/" in cf.filename:
            continue
        if cf.label in result:
            continue
        result[cf.label] = cf
    return result


def compute_chapter_gaps(ms: MatchedSeries) -> list[ChapterGap]:
    pc_map = _aggregate_pc_chapters(ms.pc) if ms.pc else {}
    tab_map = _tablet_chapters(ms.tablet) if ms.tablet else {}
    all_labels = set(pc_map) | set(tab_map)
    gaps: list[ChapterGap] = []
    for label in sorted(all_labels, key=chapter_label_sort_key):
        pc_cf = pc_map.get(label)
        tab_cf = tab_map.get(label)
        size_delta: float | None = None
        if pc_cf and tab_cf and pc_cf.size_bytes > 0:
            size_delta = abs(pc_cf.size_bytes - tab_cf.size_bytes) / pc_cf.size_bytes * 100.0
        gaps.append(ChapterGap(
            label=label,
            in_pc=pc_cf is not None,
            in_tablet=tab_cf is not None,
            pc_size=pc_cf.size_bytes if pc_cf else None,
            tablet_size=tab_cf.size_bytes if tab_cf else None,
            pc_format=pc_cf.fmt if pc_cf else None,
            tablet_format=tab_cf.fmt if tab_cf else None,
            size_delta_pct=size_delta,
        ))
    return gaps


def rank_hid_variants(variants: list[PCSeries]) -> list[PCSeries]:
    """Sort by chapter count desc, then prefer folders with valid JSON, then
    folder name. Canonical variant is the first element."""
    def _key(v: PCSeries) -> tuple:
        has_valid_json = 1 if (v.json_path is not None and not v.json_malformed) else 0
        return (-len(v.chapter_files), -has_valid_json, v.folder_name.casefold())
    return sorted(variants, key=_key)


def detect_anomalies(
    matched: list[MatchedSeries],
    pc: list[PCSeries],
    size_threshold_pct: float,
) -> list[Anomaly]:
    anomalies: list[Anomaly] = []

    for ms in matched:
        if len(ms.pc) > 1:
            ranked = rank_hid_variants(ms.pc)
            variants_payload = []
            parts: list[str] = []
            for i, v in enumerate(ranked):
                empty = (len(v.chapter_files) == 0)
                tag = ""
                if i == 0 and not empty:
                    tag = " [canonical]"
                elif empty:
                    tag = " [EMPTY]"
                parts.append(f"{v.folder_name} ({len(v.chapter_files)} ch){tag}")
                variants_payload.append({
                    "folder": v.folder_name,
                    "chapter_count": len(v.chapter_files),
                    "is_empty": empty,
                    "has_json": v.json_path is not None and not v.json_malformed,
                    "hid": v.hid_suffix,
                })
            anomalies.append(Anomaly(
                kind="hid_variants",
                severity="info",
                series=ms.norm_key,
                detail=f"{len(ms.pc)} PC folders for {ms.norm_key!r}: " + "; ".join(parts),
                payload={"norm_key": ms.norm_key, "variants": variants_payload},
            ))

    for s in pc:
        if s.json_malformed:
            anomalies.append(Anomaly(
                kind="malformed_json",
                severity="warn",
                series=s.folder_name,
                detail=f"{s.folder_name}: .aio_series.json could not be parsed.",
                payload={"folder": s.folder_name, "path": str(s.json_path) if s.json_path else None},
            ))
        if not s.chapter_files:
            anomalies.append(Anomaly(
                kind="empty_pc_folder",
                severity="warn",
                series=s.folder_name,
                detail=f"{s.folder_name}: no chapter files on PC.",
                payload={"folder": s.folder_name, "has_json": s.json_path is not None},
            ))

    for ms in matched:
        if not ms.pc or ms.tablet is None:
            continue
        pc_chapters = _aggregate_pc_chapters(ms.pc)
        tab_chapters = _tablet_chapters(ms.tablet)
        pc_formats = {cf.fmt for cf in pc_chapters.values() if cf.fmt}
        tab_formats = {cf.fmt for cf in tab_chapters.values() if cf.fmt}
        format_pair_skipped = False
        if pc_formats and tab_formats and pc_formats != tab_formats:
            anomalies.append(Anomaly(
                kind="format_mismatch",
                severity="info",
                series=ms.norm_key,
                detail=(
                    f"{ms.norm_key}: PC={','.join(sorted(pc_formats))}, "
                    f"tablet={','.join(sorted(tab_formats))}. "
                    "Per-chapter size comparisons skipped (re-encoded)."
                ),
                payload={
                    "pc_formats": sorted(pc_formats),
                    "tablet_formats": sorted(tab_formats),
                    "shared_label_count": len(set(pc_chapters) & set(tab_chapters)),
                },
            ))
            format_pair_skipped = True
        if not format_pair_skipped:
            # Collect per-chapter findings, then emit errors individually and
            # consolidate warns into a single per-series summary. Real
            # corruption (truncated stubs / >2x threshold delta) still gets
            # its own entry; bulk re-encodes that produce many similar warns
            # would otherwise drown the report.
            # Direction-aware: tablet much SMALLER than PC suggests truncation
            # (escalate to error). Tablet much LARGER means re-encoded at higher
            # quality or different source; only warn (and consolidate). Errors
            # always emit individually so corruption stays prominent.
            warns: list[tuple[str, int, int, float]] = []
            for label in sorted(set(pc_chapters) & set(tab_chapters), key=chapter_label_sort_key):
                pc_cf = pc_chapters[label]
                tab_cf = tab_chapters[label]
                if pc_cf.fmt != tab_cf.fmt:
                    continue
                if pc_cf.size_bytes <= 0:
                    continue
                shrink_pct = (pc_cf.size_bytes - tab_cf.size_bytes) / pc_cf.size_bytes * 100.0
                delta = abs(shrink_pct)
                truncated_stub = (tab_cf.size_bytes < 1024 and pc_cf.size_bytes > 100_000)
                if not (delta > size_threshold_pct or truncated_stub):
                    continue
                tablet_much_smaller = (shrink_pct > 2 * size_threshold_pct)
                if truncated_stub or tablet_much_smaller:
                    anomalies.append(Anomaly(
                        kind="size_mismatch",
                        severity="error",
                        series=ms.norm_key,
                        detail=(
                            f"{ms.norm_key} Ch {label}: PC {format_size(pc_cf.size_bytes)} -> "
                            f"tablet {format_size(tab_cf.size_bytes)} (delta {delta:.1f}%)"
                            + (", likely corrupt" if truncated_stub else "")
                        ),
                        payload={
                            "series": ms.norm_key,
                            "label": label,
                            "pc_bytes": pc_cf.size_bytes,
                            "tablet_bytes": tab_cf.size_bytes,
                            "delta_pct": delta,
                            "truncated_stub": truncated_stub,
                        },
                    ))
                else:
                    warns.append((label, pc_cf.size_bytes, tab_cf.size_bytes, delta))
            if len(warns) >= 3:
                deltas = [d for _, _, _, d in warns]
                avg_d = sum(deltas) / len(deltas)
                min_d, max_d = min(deltas), max(deltas)
                anomalies.append(Anomaly(
                    kind="size_mismatch",
                    severity="warn",
                    series=ms.norm_key,
                    detail=(
                        f"{ms.norm_key}: {len(warns)} chapter(s) differ "
                        f"by {min_d:.0f}-{max_d:.0f}% (avg {avg_d:.0f}%). "
                        "Likely re-encoded, not corrupt."
                    ),
                    payload={
                        "series": ms.norm_key,
                        "count": len(warns),
                        "min_delta_pct": min_d,
                        "max_delta_pct": max_d,
                        "avg_delta_pct": avg_d,
                        "samples": [
                            {"label": l, "pc_bytes": p, "tablet_bytes": t, "delta_pct": d}
                            for l, p, t, d in warns[:10]
                        ],
                    },
                ))
            else:
                for label, pc_sz, tab_sz, delta in warns:
                    anomalies.append(Anomaly(
                        kind="size_mismatch",
                        severity="warn",
                        series=ms.norm_key,
                        detail=(
                            f"{ms.norm_key} Ch {label}: PC {format_size(pc_sz)} -> "
                            f"tablet {format_size(tab_sz)} (delta {delta:.1f}%)"
                        ),
                        payload={
                            "series": ms.norm_key,
                            "label": label,
                            "pc_bytes": pc_sz,
                            "tablet_bytes": tab_sz,
                            "delta_pct": delta,
                            "truncated_stub": False,
                        },
                    ))
        nested = [c for c in ms.tablet.chapter_files if "/" in c.filename]
        if nested:
            anomalies.append(Anomaly(
                kind="orphan",
                severity="info",
                series=ms.norm_key,
                detail=f"{ms.tablet.folder_name}: {len(nested)} nested file(s) (anthology/subfolder), not gap-compared.",
                payload={"series": ms.norm_key, "count": len(nested), "samples": [c.filename for c in nested[:5]]},
            ))
        bad_ext = [c for c in ms.tablet.chapter_files if c.fmt not in ("pdf", "cbz")]
        if bad_ext:
            anomalies.append(Anomaly(
                kind="orphan",
                severity="warn",
                series=ms.norm_key,
                detail=f"{ms.tablet.folder_name}: {len(bad_ext)} file(s) with unrecognized extension.",
                payload={"series": ms.norm_key, "count": len(bad_ext), "samples": [c.filename for c in bad_ext[:5]]},
            ))

    for ms in matched:
        if ms.pc or ms.tablet is None:
            continue
        t = ms.tablet
        if len(t.chapter_files) == 1:
            f = t.chapter_files[0]
            stem = f.filename.rsplit(".", 1)[0]
            if "/" not in f.filename and stem.casefold() == t.folder_name.casefold():
                anomalies.append(Anomaly(
                    kind="single_bundled_file",
                    severity="info",
                    series=ms.norm_key,
                    detail=f"{t.folder_name}: single bundled file, no chapter numbering.",
                    payload={"folder": t.folder_name, "file": f.filename, "size": f.size_bytes},
                ))
        nested = [c for c in t.chapter_files if "/" in c.filename]
        if nested:
            anomalies.append(Anomaly(
                kind="orphan",
                severity="info",
                series=ms.norm_key,
                detail=f"{t.folder_name}: {len(nested)} nested file(s) (anthology layout).",
                payload={"series": ms.norm_key, "count": len(nested), "samples": [c.filename for c in nested[:5]]},
            ))
        bad_ext = [c for c in t.chapter_files if c.fmt not in ("pdf", "cbz")]
        if bad_ext and len(bad_ext) == len(t.chapter_files):
            anomalies.append(Anomaly(
                kind="orphan",
                severity="warn",
                series=ms.norm_key,
                detail=f"{t.folder_name}: {len(bad_ext)} file(s), all with unrecognized extension(s).",
                payload={"series": ms.norm_key, "count": len(bad_ext), "samples": [c.filename for c in bad_ext[:5]]},
            ))

    return anomalies


# ============================================================================
# Rendering
# ============================================================================


def _strip_ansi(s: str) -> str:
    return re.sub(r"\x1b\[[0-9;]*m", "", s)


def _status_tag(status: str) -> str:
    s = (status or "Unknown").strip()
    # Replace underscores in AIO statuses like "On_hiatus" for display.
    display = s.replace("_", " ")
    s_lower = s.casefold()
    if s_lower == "ongoing":
        color = "yellow"
    elif s_lower == "completed":
        color = "dim"
    elif "hiatus" in s_lower:
        color = "magenta"
    elif s_lower in ("cancelled", "canceled", "dropped", "discontinued"):
        color = "red"
    else:
        color = "dim"
    return _c(f"[{display}]".ljust(15), color)


def _format_label_list(labels: list[str], cap: int = 30) -> str:
    if not labels:
        return ""
    if len(labels) <= cap:
        return ", ".join(labels)
    return ", ".join(labels[:cap]) + f", ... and {len(labels) - cap} more (see report file)"


def render_console(
    pc_root: Path,
    tablet_root: str,
    device: str,
    cache_status: str,
    tablet_file_count: int,
    pc: list[PCSeries],
    tablet: list[TabletSeries],
    matched: list[MatchedSeries],
    anomalies: list[Anomaly],
    report_file: Path,
    json_file: Path,
    quiet: bool,
    verbose: bool,
) -> str:
    out: list[str] = []
    now = datetime.now()
    out.append(_c(f"COMPARE MANGA — {now.strftime('%Y-%m-%d %H:%M:%S')}", "bold_cyan"))
    out.append(f"PC root:     {pc_root}")
    out.append(f"Tablet root: {tablet_root} (device {device})")
    out.append(f"Cache:       {cache_status}")
    out.append("")

    pc_logical_keys = {normalize_series_name(s.folder_name) for s in pc}
    pc_chapter_total = sum(len(s.chapter_files) for s in pc)
    pc_byte_total = sum(c.size_bytes for s in pc for c in s.chapter_files)
    tab_chapter_total = sum(len(s.chapter_files) for s in tablet)
    tab_byte_total = sum(c.size_bytes for s in tablet for c in s.chapter_files)
    n_matched = sum(1 for ms in matched if ms.pc and ms.tablet is not None)
    n_pc_only = sum(1 for ms in matched if ms.pc and ms.tablet is None)
    n_tablet_only = sum(1 for ms in matched if not ms.pc and ms.tablet is not None)

    out.append(_c("SUMMARY", "bold"))
    out.append(f"  PC folders:           {len(pc)} ({len(pc_logical_keys)} logical series after collapsing hid groups)")
    out.append(f"  Tablet folders:       {len(tablet)}")
    out.append(f"  Matched:              {n_matched}")
    out.append(f"  PC-only (tablet missing):     {n_pc_only}")
    out.append(f"  Tablet-only (PC missing):     {n_tablet_only}")
    out.append(f"  PC chapter files:     {pc_chapter_total} ({format_size(pc_byte_total)})")
    out.append(f"  Tablet chapter files: {tab_chapter_total} ({format_size(tab_byte_total)})")
    out.append(f"  Anomalies:            {len(anomalies)}")
    out.append("")

    if not quiet:
        # Exclude empty PC folders (already surfaced as empty_pc_folder
        # anomalies) — listing them as "tablet missing 0 chapters" is misleading.
        tablet_missing = [
            ms for ms in matched
            if ms.pc and ms.tablet is None
            and sum(len(v.chapter_files) for v in ms.pc) > 0
        ]
        out.append(_c(f"TABLET MISSING THESE PC SERIES ({len(tablet_missing)})", "bold"))
        if not tablet_missing:
            out.append(_c("  (none)", "dim"))
        else:
            for ms in tablet_missing:
                canon = rank_hid_variants(ms.pc)[0]
                chapter_count = sum(len(v.chapter_files) for v in ms.pc)
                suffix = ""
                if len(ms.pc) > 1:
                    suffix = f"  (across {len(ms.pc)} PC folder variants)"
                out.append(f"  {_status_tag(canon.status)} {canon.folder_name:<55} {chapter_count:>5} chapters{suffix}")
        out.append("")

        pc_missing = [
            ms for ms in matched
            if not ms.pc and ms.tablet is not None
            and len(ms.tablet.chapter_files) > 0
        ]
        out.append(_c(f"PC MISSING THESE TABLET SERIES ({len(pc_missing)})", "bold"))
        if not pc_missing:
            out.append(_c("  (none)", "dim"))
        else:
            for ms in pc_missing:
                t = ms.tablet
                out.append(f"  {t.folder_name:<67} {len(t.chapter_files):>5} files")
        out.append("")

        shared = [ms for ms in matched if ms.pc and ms.tablet is not None]
        gap_section: list[str] = []
        any_gap = False
        for ms in shared:
            gaps = compute_chapter_gaps(ms)
            missing_tab = [g.label for g in gaps if g.in_pc and not g.in_tablet]
            extra_tab = [g.label for g in gaps if g.in_tablet and not g.in_pc]
            if not missing_tab and not extra_tab and not verbose:
                continue
            any_gap = True
            canon = rank_hid_variants(ms.pc)[0]
            gap_section.append(f"  {_status_tag(canon.status)} {canon.folder_name}")
            mtxt = _format_label_list(missing_tab)
            etxt = _format_label_list(extra_tab)
            m_color = "bold_red" if missing_tab else "dim"
            e_color = "magenta" if extra_tab else "dim"
            m_label = _c(f"missing on tablet ({len(missing_tab)}):", m_color)
            e_label = _c(f"extra on tablet ({len(extra_tab)}):", e_color)
            gap_section.append(f"       {m_label} {mtxt}")
            if extra_tab or verbose:
                gap_section.append(f"       {e_label} {etxt}")
        out.append(_c("CHAPTER GAPS IN SHARED SERIES", "bold"))
        if not any_gap:
            out.append(_c("  (all shared series perfectly synced)", "dim"))
        else:
            out.extend(gap_section)
        out.append("")

        out.append(_c(f"ANOMALIES ({len(anomalies)})", "bold"))
        if not anomalies:
            out.append(_c("  (none)", "dim"))
        else:
            by_kind: dict[str, list[Anomaly]] = {}
            for a in anomalies:
                by_kind.setdefault(a.kind, []).append(a)
            for kind in _ANOMALY_KIND_ORDER:
                items = by_kind.get(kind, [])
                if not items:
                    continue
                title = kind.upper().replace("_", " ")
                out.append(f"  {_c(title, 'bold')} ({len(items)})")
                for a in items:
                    sev_color = {"info": "dim", "warn": "yellow", "error": "bold_red"}.get(a.severity, "")
                    sev_tag = _c(f"[{a.severity}]", sev_color) if sev_color else f"[{a.severity}]"
                    out.append(f"    {sev_tag} {a.detail}")

    out.append("")
    out.append(f"Saved text report: {report_file}")
    out.append(f"Saved JSON report: {json_file}")
    return "\n".join(out)


def render_text_report(console_text: str) -> str:
    return "# Compare Manga Report v1\n" + _strip_ansi(console_text) + "\n"


def render_json(
    pc_root: Path,
    tablet_root: str,
    device: str,
    cache_status: str,
    tablet_file_count: int,
    pc: list[PCSeries],
    tablet: list[TabletSeries],
    matched: list[MatchedSeries],
    anomalies: list[Anomaly],
) -> dict:
    pc_logical_keys = {normalize_series_name(s.folder_name) for s in pc}
    pc_chapter_total = sum(len(s.chapter_files) for s in pc)
    pc_byte_total = sum(c.size_bytes for s in pc for c in s.chapter_files)
    tab_chapter_total = sum(len(s.chapter_files) for s in tablet)
    tab_byte_total = sum(c.size_bytes for s in tablet for c in s.chapter_files)
    n_matched = sum(1 for ms in matched if ms.pc and ms.tablet is not None)
    n_pc_only = sum(1 for ms in matched if ms.pc and ms.tablet is None)
    n_tablet_only = sum(1 for ms in matched if not ms.pc and ms.tablet is not None)

    tablet_missing_out: list[dict] = []
    pc_missing_out: list[dict] = []
    shared_out: list[dict] = []
    for ms in matched:
        if ms.pc and ms.tablet is None:
            pc_total = sum(len(v.chapter_files) for v in ms.pc)
            if pc_total == 0:
                continue
            canon = rank_hid_variants(ms.pc)[0]
            tablet_missing_out.append({
                "norm_key": ms.norm_key,
                "pc_folders": [v.folder_name for v in ms.pc],
                "canonical_folder": canon.folder_name,
                "status": canon.status,
                "pc_chapter_count": pc_total,
            })
        elif not ms.pc and ms.tablet is not None:
            t = ms.tablet
            if len(t.chapter_files) == 0:
                continue
            pc_missing_out.append({
                "norm_key": ms.norm_key,
                "tablet_folder": t.folder_name,
                "tablet_chapter_count": len(t.chapter_files),
            })
        else:
            gaps = compute_chapter_gaps(ms)
            missing_tab = [g.label for g in gaps if g.in_pc and not g.in_tablet]
            extra_tab = [g.label for g in gaps if g.in_tablet and not g.in_pc]
            canon = rank_hid_variants(ms.pc)[0]
            shared_out.append({
                "norm_key": ms.norm_key,
                "pc_folders": [v.folder_name for v in ms.pc],
                "canonical_folder": canon.folder_name,
                "tablet_folder": ms.tablet.folder_name,
                "status": canon.status,
                "pc_chapter_count": sum(len(v.chapter_files) for v in ms.pc),
                "tablet_chapter_count": len(ms.tablet.chapter_files),
                "missing_on_tablet": missing_tab,
                "extra_on_tablet": extra_tab,
            })

    return {
        "report_version": 1,
        "generated_at_iso": datetime.now().astimezone().isoformat(),
        "pc_root": str(pc_root),
        "tablet_root": tablet_root,
        "device": device,
        "cache_status": cache_status,
        "tablet_file_count_total": tablet_file_count,
        "totals": {
            "pc_folders": len(pc),
            "pc_logical_series": len(pc_logical_keys),
            "tablet_folders": len(tablet),
            "matched": n_matched,
            "pc_only": n_pc_only,
            "tablet_only": n_tablet_only,
            "pc_chapter_files": pc_chapter_total,
            "pc_total_bytes": pc_byte_total,
            "tablet_chapter_files": tab_chapter_total,
            "tablet_total_bytes": tab_byte_total,
            "anomalies": len(anomalies),
        },
        "tablet_missing_series": tablet_missing_out,
        "pc_missing_series": pc_missing_out,
        "shared_series": shared_out,
        "anomalies": [
            {
                "kind": a.kind,
                "severity": a.severity,
                "series": a.series,
                "detail": a.detail,
                "payload": a.payload,
            }
            for a in anomalies
        ],
    }


# ============================================================================
# Self-test
# ============================================================================


def run_self_test() -> int:
    fails = 0

    def expect(label: str, got, want):
        nonlocal fails
        ok = got == want
        marker = "PASS" if ok else "FAIL"
        print(f"  [{marker}] {label}\n         got={got!r}\n        want={want!r}")
        if not ok:
            fails += 1

    print("normalize_series_name:")
    norm_cases = [
        ("Bleach", "bleach"),
        ("Demon_Slayer_Kimetsu_no_Yaiba", "demon slayer kimetsu no yaiba"),
        ("JoJo's_Bizarre_Adventure_Part_1_Phantom_Blood",
         "jojos bizarre adventure part 1 phantom blood"),
        ("Frieren Beyond Journey's End", "frieren beyond journeys end"),
        ("Frieren Beyond Journey’s End", "frieren beyond journeys end"),
        ("One Piece (hid=20)", "one piece"),
        ("Tokyo Ghoul (hid=)", "tokyo ghoul"),
        ("The Beginning After the End (hid=6v55p)", "the beginning after the end"),
        ("'Tis Time for Torture, Princess", "tis time for torture princess"),
        ("Vivy_-Fluorite_Eye's_Song-", "vivy fluorite eyes song"),
        ("CØDEBREAKER", "cødebreaker"),
    ]
    for inp, want in norm_cases:
        expect(f"normalize({inp!r})", normalize_series_name(inp), want)

    print("\nparse_chapter_label:")
    chap_cases = [
        ("Bleach Ch 1.pdf", ("1", "pdf", "A")),
        ("Bleach Ch 107~5.pdf", ("107.5", "pdf", "A")),
        ("Bleach Ch 315~01.pdf", ("315.01", "pdf", "A")),
        ("Solo Leveling Ch 0.1.cbz", ("0.1", "cbz", "A")),
        ("One Piece Ch 1000~5.pdf", ("1000.5", "pdf", "A")),
        ("Demon_Slayer_Kimetsu_no_Yaiba_mangafire_Ch_0.4.pdf", ("0.4", "pdf", "B")),
        ("Attack_on_Titan_mangafire_Ch_104.pdf", ("104", "pdf", "B")),
        ("Vivy_-Fluorite_Eye's_Song-_comix_Ch_1.pdf", ("1", "pdf", "B")),
        ("zBungo_Stray_Dogs_mangafire_Ch_120.5.pdf", ("120.5", "pdf", "B")),
        ("Chap 100 How to Walk Shoeless.pdf", ("100", "pdf", "C")),
        ("Chapter 8.pdf", ("8", "pdf", "D")),
        ("#100 - Disconnection [2].pdf", ("100", "pdf", "E")),
        ("Vol 1.pdf", ("1", "pdf", "F")),
        ("A Certain Scientific Railgun.pdf", (None, "pdf", "unmatched")),
    ]
    for inp, want in chap_cases:
        expect(f"parse({inp!r})", parse_chapter_label(inp), want)

    print("\nchapter_label_sort_key ordering:")
    ordered = ["0", "1", "1.5", "2", "100", "107", "107.1", "107.5", "108"]
    keys = [chapter_label_sort_key(l) for l in ordered]
    monotonic = all(keys[i] < keys[i+1] for i in range(len(keys) - 1))
    expect("strictly increasing", monotonic, True)

    print(f"\n{fails} failure(s).")
    return 0 if fails == 0 else 1


# ============================================================================
# Main
# ============================================================================


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="compare_manga",
        description="Read-only comparison of PC manga library vs USB-attached tablet (via adb).",
    )
    p.add_argument("--pc-root", type=Path, default=DEFAULT_PC_ROOT)
    p.add_argument("--tablet-root", default=DEFAULT_TABLET_ROOT)
    p.add_argument("--device", default=None,
                   help=f"adb device serial; defaults to the only connected device, else {DEFAULT_DEVICE_SERIAL!r}.")
    p.add_argument("--adb", default=None,
                   help=f"Path to adb binary; default: PATH lookup, then {KNOWN_ADB_PATH}.")
    p.add_argument("--refresh-cache", action="store_true")
    p.add_argument("--cache-file", type=Path,
                   default=SCRIPT_DIR / ".tablet_cache.json")
    p.add_argument("--cache-ttl-hours", type=float, default=DEFAULT_CACHE_TTL_HOURS)
    p.add_argument("--report-file", type=Path, default=None,
                   help="Default: <script_dir>/report-<YYYYMMDD-HHMMSS>.txt")
    p.add_argument("--json-out", type=Path, default=None,
                   help="Default: <script_dir>/report-<YYYYMMDD-HHMMSS>.json")
    p.add_argument("--size-threshold", type=float, default=DEFAULT_SIZE_THRESHOLD_PCT,
                   help="Percent delta above which to flag chapter size mismatches "
                        "(default 30). Cross-format pairs (cbz vs pdf) skipped per-chapter.")
    p.add_argument("--no-color", action="store_true")
    p.add_argument("-q", "--quiet", action="store_true")
    p.add_argument("-v", "--verbose", action="store_true")
    p.add_argument("--self-test", action="store_true")
    return p


def main(argv: list[str]) -> int:
    parser = build_arg_parser()
    args = parser.parse_args(argv)

    if args.self_test:
        return run_self_test()

    global _USE_COLOR
    _USE_COLOR = (not args.no_color) and sys.stdout.isatty()
    if _USE_COLOR and os.name == "nt":
        # Cheap trick to enable ANSI in legacy Windows consoles. Modern
        # Windows Terminal handles ANSI natively; this is a no-op for it.
        os.system("")

    try:
        adb_exe = resolve_adb(args.adb)
    except FileNotFoundError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2
    try:
        device = resolve_device(adb_exe, args.device)
    except (RuntimeError, subprocess.TimeoutExpired) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2

    if not args.pc_root.is_dir():
        print(f"ERROR: PC root not found: {args.pc_root}", file=sys.stderr)
        return 2

    try:
        pc = scan_pc_library(args.pc_root)
    except FileNotFoundError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2

    try:
        tablet, scan_anomalies, cache_status, tablet_file_count = scan_tablet_library(
            adb_exe, device, args.tablet_root,
            args.cache_file, args.refresh_cache, args.cache_ttl_hours,
        )
    except (RuntimeError, subprocess.TimeoutExpired) as e:
        print(f"ERROR: tablet scan failed: {e}", file=sys.stderr)
        return 2

    matched, match_anomalies = build_series_index(pc, tablet)
    anomalies = scan_anomalies + match_anomalies + detect_anomalies(matched, pc, args.size_threshold)

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    report_path = args.report_file or (SCRIPT_DIR / f"report-{timestamp}.txt")
    json_path = args.json_out or (SCRIPT_DIR / f"report-{timestamp}.json")

    console = render_console(
        args.pc_root, args.tablet_root, device, cache_status, tablet_file_count,
        pc, tablet, matched, anomalies, report_path, json_path,
        args.quiet, args.verbose,
    )
    print(console)

    report_path.parent.mkdir(parents=True, exist_ok=True)
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(render_text_report(console))
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(
            render_json(
                args.pc_root, args.tablet_root, device, cache_status,
                tablet_file_count, pc, tablet, matched, anomalies,
            ),
            f,
            ensure_ascii=False,
            indent=2,
        )

    return 1 if anomalies else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

"""
fixup_seed_links.py — Manual overrides for seed_links.json entries the
auto-search either failed or mis-ranked.

Edits:
  1. SHELTER  — auto-search returned 0 candidates for the all-caps query and
     only false positives ('Shelter' 2000 on comix) for the lowercased
     variants. Manual web search confirms it's the Webtoon Canvas by
     'wufargia', title_no=194264.

  2. That Time I Got Reincarnated as a Slime — comparator placed mangakatana's
     "tensura-short-stories" spinoff URL first because its img_quality_score
     beat mangafire on the tiebreaker, even though mangafire's composite_score
     was 0.1 higher. The main-series mangafire URL (tensei-shitara-slime-
     datta-kenn.5kq, 141 chapters) is the intended pick. We promote it to
     position 0.

Re-run render_seed_links.py after this script to regenerate the markdown.
"""

from __future__ import annotations

import json
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
SEED_JSON = SCRIPT_DIR / "seed_links.json"


def main() -> int:
    with open(SEED_JSON, "r", encoding="utf-8") as f:
        d = json.load(f)

    # 1. SHELTER — replace the empty/error entry with a hand-curated source.
    d["SHELTER"] = {
        "query": "SHELTER",
        "elapsed_sec": 0.0,
        "manual_override": True,
        "override_reason": (
            "AIO search returned no usable candidates; web search identified the "
            "series as the Webtoon Canvas 'SHELTER' by wufargia (title_no=194264). "
            "Chapter naming pattern '#NN - Arc Name [N].pdf' matches the Canvas "
            "episode list (Extra Hand, Red Zone, The Ortolan, etc.)."
        ),
        "candidates": [{
            "canonical_title": "SHELTER",
            "canonical_year": None,
            "sources": [{
                "site": "linewebtoon",
                "url": "https://www.webtoons.com/en/canvas/shelter/list?title_no=194264",
                "title": "SHELTER",
                "cover": None,
                "title_match": 1.0,
                "seed_quality": 1.0,
                "img_quality_score": None,
                "img_quality_metadata": None,
                "composite_score": 1.0,
                "chapter_count_hint": None,
                "actual_chapter_count": None,
                "dmca_likely": False,
            }],
        }],
    }

    # 2. Tensura — swap source[0] (mangakatana spinoff) with source[1] (mangafire
    # main series). Preserve the rest of the sources list as fallback.
    tensura = d.get("That Time I Got Reincarnated as a Slime")
    if tensura and tensura.get("candidates"):
        top = tensura["candidates"][0]
        srcs = top["sources"]
        # Find the mangafire main-series source by URL slug.
        idx = next(
            (i for i, s in enumerate(srcs)
             if "tensei-shitara-slime-datta-kenn" in s["url"]),
            None,
        )
        if idx is not None and idx != 0:
            srcs.insert(0, srcs.pop(idx))
            tensura["manual_override"] = True
            tensura["override_reason"] = (
                "Auto-pick placed mangakatana's 'tensura-short-stories' spinoff "
                "first (img_quality tiebreaker beat title_match diff < 0.10). "
                "Promoted the mangafire main-series URL (141 ch) to position 0."
            )

    # 3. Eleceed — Toonily is an unofficial mirror; the linewebtoon source is
    # the licensed original. seed=0.55 for Toonily vs seed=0.92 for linewebtoon
    # but both tied at title_match=1.0 and composite=1.0 so the comparator
    # placed them next to each other; user wants official.
    eleceed = d.get("Eleceed")
    if eleceed and eleceed.get("candidates"):
        top = eleceed["candidates"][0]
        srcs = top["sources"]
        idx = next(
            (i for i, s in enumerate(srcs)
             if s["site"] == "linewebtoon" and "webtoons.com" in s["url"]),
            None,
        )
        if idx is not None and idx != 0:
            srcs.insert(0, srcs.pop(idx))
            eleceed["manual_override"] = True
            eleceed["override_reason"] = (
                "Toonily is an unofficial mirror; promoted the licensed LINE "
                "Webtoon source (webtoons.com/en/action/eleceed) to position 0. "
                "Solo Leveling was NOT switched because it has no LINE Webtoon "
                "official — only a Canvas fan re-upload; its official English "
                "lives on Tappytoon, which AIO doesn't support."
            )

    with open(SEED_JSON, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
    print(f"updated {SEED_JSON}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""
manga_manager.py — Flask web UI for the CompareManga manager.

Owns the HTTP surface, the comparison view-model memo, and the broker
between the UI and transfer_runner.

Reads compare_manga.py as a library (its public surface is treated as
stable; never modified). Reads manga_ops + transfer_runner for the
actual adb work.

Routes (all on 127.0.0.1):
  GET  /                            full dashboard
  GET  /api/series/<norm_key>       per-series detail partial (HTMX)
  POST /api/preview                 confirm-modal partial
  POST /api/transfer                start a batch; returns progress-modal partial
  GET  /api/transfer/<id>/stream    SSE event stream
  POST /api/transfer/<id>/cancel    cooperative cancel
  POST /api/refresh                 force fresh tablet scan, returns dashboard partial
  GET  /api/cover/<norm_key>        cover image proxy + on-disk cache

Run:  python manga_manager.py
"""

from __future__ import annotations

import argparse
import dataclasses
import hashlib
import json
import os
import socket
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from flask import (
    Flask, Response, abort, jsonify, redirect, render_template, request,
    send_from_directory,
)
from waitress import serve

import compare_manga as cm
import transfer_runner
from transfer_runner import TransferOp


# ============================================================================
# Constants
# ============================================================================

HOST_DEFAULT = "127.0.0.1"
PORT_DEFAULT = 5000

# Cached comparison TTL — short enough that PC additions show up quickly,
# long enough that rapid page reloads don't re-scan disk every time.
COMPARISON_TTL_SEC = 120.0

# How long to wait between cover URL fetch attempts.
COVER_FETCH_TIMEOUT = 5.0
COVER_USER_AGENT = "CompareManga/1.0"

# Anomaly kind order — mirrors compare_manga._ANOMALY_KIND_ORDER (which is
# private). Duplicate locally rather than reach across the underscore.
ANOMALY_KIND_ORDER = (
    "hid_variants",
    "format_mismatch",
    "size_mismatch",
    "single_bundled_file",
    "orphan",
    "empty_pc_folder",
    "malformed_json",
)

COVERS_DIR = cm.SCRIPT_DIR / "static" / "covers"


# ============================================================================
# View-model dataclasses
# ============================================================================


@dataclass
class SeriesRow:
    """Flat row in the dashboard list. One per matched series."""
    norm_key: str
    display_title: str
    status: str
    pc_chapters: int
    tablet_chapters: int
    missing_on_tablet: list[str]
    extra_on_tablet: list[str]
    pc_bytes_total: int
    tablet_bytes_total: int
    side: str                # "tablet_missing" | "pc_missing" | "shared"
    is_synced: bool
    pc_folder: str           # canonical pc folder name for display
    tablet_folder: str | None
    has_cover: bool

    @property
    def url_key(self) -> str:
        return urllib.parse.quote(self.norm_key, safe="")


@dataclass
class ComparisonView:
    pc_root: Path
    tablet_root: str
    device: str
    cache_status: str
    tablet_file_count: int
    totals: dict
    tablet_missing: list[SeriesRow]
    pc_missing: list[SeriesRow]
    shared: list[SeriesRow]
    anomalies_by_kind: dict[str, list[cm.Anomaly]]
    generated_at: datetime


# ============================================================================
# Comparison memo
# ============================================================================


class _State:
    """Process-wide state. Holds the adb path + device once resolved, and
    the memoized comparison view + lock."""
    def __init__(self) -> None:
        self.adb_exe: str = ""
        self.device: str = ""
        self.pc_root: Path = cm.DEFAULT_PC_ROOT
        self.tablet_root: str = cm.DEFAULT_TABLET_ROOT
        self.size_threshold: float = 30.0
        self.cache_file: Path = cm.SCRIPT_DIR / ".tablet_cache.json"
        self.cache_ttl_hours: float = cm.DEFAULT_CACHE_TTL_HOURS

        self._lock = threading.RLock()
        self._view: ComparisonView | None = None
        self._view_built_at: float = 0.0
        # MatchedSeries cache keyed by norm_key — used by detail/ops routes
        # so they don't have to re-derive from the raw lists.
        self._matched_by_key: dict[str, cm.MatchedSeries] = {}


_STATE = _State()


def _get_comparison(force: bool = False) -> ComparisonView:
    """Return a memoized ComparisonView; rebuild when stale, force=True,
    or the tablet cache file mtime changed since the last build."""
    with _STATE._lock:
        now = time.time()
        cache_file = _STATE.cache_file
        cache_mtime = cache_file.stat().st_mtime if cache_file.exists() else 0.0
        stale = (
            _STATE._view is None
            or (now - _STATE._view_built_at) > COMPARISON_TTL_SEC
            or cache_mtime > _STATE._view_built_at
        )
        if force or stale:
            _STATE._view = _build_comparison(force=force)
            _STATE._view_built_at = time.time()
        return _STATE._view


def _build_comparison(*, force: bool) -> ComparisonView:
    """Run scan_pc + scan_tablet + build_series_index + detect_anomalies,
    then flatten into the view-model."""
    pc = cm.scan_pc_library(_STATE.pc_root)
    tablet, scan_anomalies, cache_status, file_count = cm.scan_tablet_library(
        _STATE.adb_exe, _STATE.device, _STATE.tablet_root,
        _STATE.cache_file, force, _STATE.cache_ttl_hours,
    )
    matched, match_anomalies = cm.build_series_index(pc, tablet)
    anomalies = scan_anomalies + match_anomalies + cm.detect_anomalies(
        matched, pc, _STATE.size_threshold,
    )

    # Side-classify and build rows.
    tablet_missing: list[SeriesRow] = []
    pc_missing: list[SeriesRow] = []
    shared: list[SeriesRow] = []
    matched_by_key: dict[str, cm.MatchedSeries] = {}

    for ms in matched:
        matched_by_key[ms.norm_key] = ms
        row = _build_series_row(ms)
        if row.side == "tablet_missing":
            tablet_missing.append(row)
        elif row.side == "pc_missing":
            pc_missing.append(row)
        else:
            shared.append(row)

    # Order: by chapter count desc within each section so the biggest items
    # are at the top — those are the most useful for action.
    tablet_missing.sort(key=lambda r: (-r.pc_chapters, r.display_title.casefold()))
    pc_missing.sort(key=lambda r: (-r.tablet_chapters, r.display_title.casefold()))
    shared.sort(key=lambda r: (
        # series with missing chapters first, then synced last
        0 if r.missing_on_tablet else (1 if r.extra_on_tablet else 2),
        -len(r.missing_on_tablet),
        r.display_title.casefold(),
    ))

    by_kind: dict[str, list[cm.Anomaly]] = {k: [] for k in ANOMALY_KIND_ORDER}
    for a in anomalies:
        by_kind.setdefault(a.kind, []).append(a)

    # Counts
    pc_total_chapters = sum(len(s.chapter_files) for s in pc)
    pc_total_bytes = sum(c.size_bytes for s in pc for c in s.chapter_files)
    tab_total_chapters = sum(len(s.chapter_files) for s in tablet)
    tab_total_bytes = sum(c.size_bytes for s in tablet for c in s.chapter_files)
    pc_logical_keys = {cm.normalize_series_name(s.folder_name) for s in pc}

    totals = {
        "pc_folders": len(pc),
        "pc_logical_series": len(pc_logical_keys),
        "tablet_folders": len(tablet),
        "matched": sum(1 for ms in matched if ms.pc and ms.tablet is not None),
        "pc_only": sum(1 for ms in matched if ms.pc and ms.tablet is None),
        "tablet_only": sum(1 for ms in matched if not ms.pc and ms.tablet is not None),
        "pc_chapter_files": pc_total_chapters,
        "pc_total_bytes": pc_total_bytes,
        "pc_total_human": cm.format_size(pc_total_bytes),
        "tablet_chapter_files": tab_total_chapters,
        "tablet_total_bytes": tab_total_bytes,
        "tablet_total_human": cm.format_size(tab_total_bytes),
        "anomalies": len(anomalies),
    }

    _STATE._matched_by_key = matched_by_key

    return ComparisonView(
        pc_root=_STATE.pc_root,
        tablet_root=_STATE.tablet_root,
        device=_STATE.device,
        cache_status=cache_status,
        tablet_file_count=file_count,
        totals=totals,
        tablet_missing=tablet_missing,
        pc_missing=pc_missing,
        shared=shared,
        anomalies_by_kind=by_kind,
        generated_at=datetime.now(),
    )


def _build_series_row(ms: cm.MatchedSeries) -> SeriesRow:
    pc_total_chapters = sum(len(v.chapter_files) for v in ms.pc)
    pc_total_bytes = sum(c.size_bytes for v in ms.pc for c in v.chapter_files)

    if ms.pc and ms.tablet is None:
        canon = cm.rank_hid_variants(ms.pc)[0]
        # Exclude PC-empty placeholders from the "tablet missing" list —
        # they're surfaced as empty_pc_folder anomalies instead.
        side = "tablet_missing" if pc_total_chapters > 0 else "pc_missing"
        # ^ if pc has 0 chapters, the series effectively doesn't exist;
        # treat it as if the PC doesn't have it.
        display_title = canon.title or canon.folder_name
        return SeriesRow(
            norm_key=ms.norm_key,
            display_title=display_title,
            status=canon.status,
            pc_chapters=pc_total_chapters,
            tablet_chapters=0,
            missing_on_tablet=[],
            extra_on_tablet=[],
            pc_bytes_total=pc_total_bytes,
            tablet_bytes_total=0,
            side=side,
            is_synced=False,
            pc_folder=canon.folder_name,
            tablet_folder=None,
            has_cover=canon.json_path is not None and not canon.json_malformed,
        )

    if not ms.pc and ms.tablet is not None:
        t = ms.tablet
        if len(t.chapter_files) == 0:
            # Empty tablet folder — pretend it doesn't exist for the
            # missing list. Anomaly subsystem can still surface it.
            return SeriesRow(
                norm_key=ms.norm_key,
                display_title=t.folder_name,
                status="Unknown",
                pc_chapters=0, tablet_chapters=0,
                missing_on_tablet=[], extra_on_tablet=[],
                pc_bytes_total=0, tablet_bytes_total=0,
                side="shared", is_synced=True,
                pc_folder="", tablet_folder=t.folder_name, has_cover=False,
            )
        tablet_bytes = sum(c.size_bytes for c in t.chapter_files)
        return SeriesRow(
            norm_key=ms.norm_key,
            display_title=t.folder_name,
            status="Unknown",
            pc_chapters=0,
            tablet_chapters=len(t.chapter_files),
            missing_on_tablet=[],
            extra_on_tablet=[],
            pc_bytes_total=0,
            tablet_bytes_total=tablet_bytes,
            side="pc_missing",
            is_synced=False,
            pc_folder="",
            tablet_folder=t.folder_name,
            has_cover=False,
        )

    # Both sides
    canon = cm.rank_hid_variants(ms.pc)[0]
    t = ms.tablet
    gaps = cm.compute_chapter_gaps(ms)
    missing = [g.label for g in gaps if g.in_pc and not g.in_tablet]
    extra = [g.label for g in gaps if g.in_tablet and not g.in_pc]
    tablet_bytes = sum(c.size_bytes for c in t.chapter_files)
    return SeriesRow(
        norm_key=ms.norm_key,
        display_title=canon.title or canon.folder_name,
        status=canon.status,
        pc_chapters=pc_total_chapters,
        tablet_chapters=len(t.chapter_files),
        missing_on_tablet=missing,
        extra_on_tablet=extra,
        pc_bytes_total=pc_total_bytes,
        tablet_bytes_total=tablet_bytes,
        side="shared",
        is_synced=(not missing and not extra),
        pc_folder=canon.folder_name,
        tablet_folder=t.folder_name,
        has_cover=canon.json_path is not None and not canon.json_malformed,
    )


def _detail_payload(ms: cm.MatchedSeries) -> dict:
    """Per-series detail for the right-hand panel. Per-chapter rows with
    op-keys ready to drop into the selection set."""
    canon = cm.rank_hid_variants(ms.pc)[0] if ms.pc else None
    display_title = (
        (canon.title or canon.folder_name) if canon
        else (ms.tablet.folder_name if ms.tablet else ms.norm_key)
    )

    pc_chapters = _aggregate_pc_chapter_map(ms.pc) if ms.pc else {}
    tab_chapters = _tablet_chapter_map(ms.tablet) if ms.tablet else {}
    all_labels = sorted(set(pc_chapters) | set(tab_chapters), key=cm.chapter_label_sort_key)

    rows = []
    for label in all_labels:
        pc_cf = pc_chapters.get(label)
        tab_cf = tab_chapters.get(label)
        suggested = None
        if pc_cf and not tab_cf:
            suggested = "push"
        elif tab_cf and not pc_cf:
            suggested = "delete"
        rows.append({
            "label": label,
            "pc_size_human": cm.format_size(pc_cf.size_bytes) if pc_cf else None,
            "pc_size_bytes": pc_cf.size_bytes if pc_cf else None,
            "tablet_size_human": cm.format_size(tab_cf.size_bytes) if tab_cf else None,
            "tablet_size_bytes": tab_cf.size_bytes if tab_cf else None,
            "pc_fmt": pc_cf.fmt if pc_cf else None,
            "tablet_fmt": tab_cf.fmt if tab_cf else None,
            "suggested_op": suggested,
            "push_op_key": f"push|{ms.norm_key}|{label}" if suggested == "push" else None,
            "delete_op_key": f"delete|{ms.norm_key}|{label}" if suggested == "delete" else None,
        })

    side = (
        "tablet_missing" if (ms.pc and ms.tablet is None) else
        "pc_missing" if (not ms.pc and ms.tablet is not None) else
        "shared"
    )
    status = canon.status if canon else "Unknown"
    last_updated = None
    if canon and canon.json_path:
        try:
            ts = canon.json_path.stat().st_mtime
            last_updated = datetime.fromtimestamp(ts).strftime("%Y-%m-%d")
        except OSError:
            pass

    return {
        "norm_key": ms.norm_key,
        "url_key": urllib.parse.quote(ms.norm_key, safe=""),
        "display_title": display_title,
        "status": status,
        "side": side,
        "pc_folder": canon.folder_name if canon else None,
        "tablet_folder": ms.tablet.folder_name if ms.tablet else None,
        "pc_chapters": sum(len(v.chapter_files) for v in ms.pc) if ms.pc else 0,
        "tablet_chapters": len(ms.tablet.chapter_files) if ms.tablet else 0,
        "pc_size_human": cm.format_size(sum(c.size_bytes for v in ms.pc for c in v.chapter_files)) if ms.pc else "-",
        "tablet_size_human": cm.format_size(sum(c.size_bytes for c in ms.tablet.chapter_files)) if ms.tablet else "-",
        "rows": rows,
        "last_updated": last_updated,
        "missing_count": sum(1 for r in rows if r["suggested_op"] == "push"),
        "extra_count": sum(1 for r in rows if r["suggested_op"] == "delete"),
    }


def _aggregate_pc_chapter_map(variants: list[cm.PCSeries]) -> dict[str, cm.ChapterFile]:
    """Union of label -> ChapterFile across hid variants. Keeps the variant
    with the largest file size when labels collide (a slightly different
    rule than compare_manga's _aggregate_pc_chapters which keeps the first
    occurrence — here we'd rather push the more complete copy)."""
    out: dict[str, cm.ChapterFile] = {}
    for v in variants:
        for cf in v.chapter_files:
            if cf.label is None:
                continue
            prior = out.get(cf.label)
            if prior is None or cf.size_bytes > prior.size_bytes:
                out[cf.label] = cf
    return out


def _tablet_chapter_map(t: cm.TabletSeries) -> dict[str, cm.ChapterFile]:
    out: dict[str, cm.ChapterFile] = {}
    for cf in t.chapter_files:
        if cf.label is None:
            continue
        if "/" in cf.filename:
            continue
        if cf.label not in out:
            out[cf.label] = cf
    return out


# ============================================================================
# Op resolution
# ============================================================================


def _ops_from_request_json(payload: dict, view: ComparisonView) -> tuple[list[TransferOp], list[dict]]:
    """Resolve a frontend selection payload into TransferOps.

    Input: {"ops": [{"op": "push"|"delete", "series_key": "...", "label": "..."}]}
    Special: label == "*" means whole series — expands to one op per chapter.

    Returns (resolved_ops, unresolvable_entries). Unresolvable entries are
    returned for UI to display as skipped; resolved_ops are ready to feed
    into transfer_runner.start_transfer.
    """
    raw_ops = payload.get("ops") or []
    if not isinstance(raw_ops, list):
        raise ValueError("payload.ops must be a list")

    resolved: list[TransferOp] = []
    skipped: list[dict] = []
    seen_keys: set[str] = set()

    for entry in raw_ops:
        if not isinstance(entry, dict):
            skipped.append({"entry": entry, "reason": "not an object"})
            continue
        op = entry.get("op")
        series_key = entry.get("series_key")
        label = entry.get("label")
        if op not in ("push", "delete") or not isinstance(series_key, str) or not isinstance(label, str):
            skipped.append({"entry": entry, "reason": "missing op/series_key/label"})
            continue
        ms = _STATE._matched_by_key.get(series_key)
        if ms is None:
            skipped.append({"entry": entry, "reason": f"unknown series {series_key!r}"})
            continue

        if label == "*":
            expanded = _expand_whole_series(ms, op)
            for sub in expanded:
                k = f"{sub.op}|{sub.series_key}|{sub.label}"
                if k in seen_keys:
                    continue
                seen_keys.add(k)
                resolved.append(sub)
            if not expanded:
                skipped.append({"entry": entry, "reason": "no chapters available for this op"})
            continue

        single = _resolve_single(ms, op, label)
        if single is None:
            skipped.append({"entry": entry, "reason": f"no {op} candidate for {label}"})
            continue
        k = f"{op}|{series_key}|{label}"
        if k in seen_keys:
            continue
        seen_keys.add(k)
        resolved.append(single)

    return resolved, skipped


def _resolve_single(ms: cm.MatchedSeries, op: str, label: str) -> TransferOp | None:
    if op == "push":
        pc_chapters = _aggregate_pc_chapter_map(ms.pc) if ms.pc else {}
        pc_cf = pc_chapters.get(label)
        if pc_cf is None:
            return None
        tab_chapters = _tablet_chapter_map(ms.tablet) if ms.tablet else {}
        if label in tab_chapters:
            # Already on tablet — skip silently rather than overwrite.
            return None
        return _make_push_op(ms, pc_cf)
    if op == "delete":
        if ms.tablet is None:
            return None
        # Match by label first (normal labeled chapter), then by filename
        # (orphan files like webp_test/_pdftoppm_out-01.ppm whose label
        # is None — _make_delete_op uses the filename as the op label so
        # the round-trip works).
        for cf in ms.tablet.chapter_files:
            if "/" in cf.filename:
                continue
            if cf.label == label or cf.filename == label:
                return _make_delete_op(ms, cf)
        return None
    return None


def _expand_whole_series(ms: cm.MatchedSeries, op: str) -> list[TransferOp]:
    pc_chapters = _aggregate_pc_chapter_map(ms.pc) if ms.pc else {}
    out: list[TransferOp] = []
    if op == "push":
        tab_chapters = _tablet_chapter_map(ms.tablet) if ms.tablet else {}
        for label in sorted(pc_chapters, key=cm.chapter_label_sort_key):
            if label in tab_chapters:
                continue
            out.append(_make_push_op(ms, pc_chapters[label]))
    elif op == "delete":
        if ms.tablet is None:
            return []
        # Use ALL tablet files including unmatched orphans (e.g. webp_test/
        # 0.webp). Skip nested paths so an anthology deep-delete can't fire
        # accidentally — the path-safety layer also blocks rm -rf so this is
        # belt-and-braces.
        for cf in ms.tablet.chapter_files:
            if "/" in cf.filename:
                continue
            out.append(_make_delete_op(ms, cf))
        out.sort(key=lambda o: cm.chapter_label_sort_key(o.label))
    return out


def _make_push_op(ms: cm.MatchedSeries, pc_cf: cm.ChapterFile) -> TransferOp:
    canon = cm.rank_hid_variants(ms.pc)[0]
    pc_path = canon.abs_path / pc_cf.filename
    if ms.tablet is not None:
        tablet_dest = ms.tablet.abs_path
    else:
        # No tablet folder yet — create one named after the canonical PC
        # folder (sanitized). This intentionally uses the PC's folder name,
        # not the title, so the tablet's directory listing stays consistent
        # with what the user sees on disk.
        from manga_ops import sanitize_tablet_segment
        seg = sanitize_tablet_segment(canon.folder_name)
        tablet_dest = _STATE.tablet_root.rstrip("/") + "/" + seg
    display = (canon.title or canon.folder_name) + " Ch " + pc_cf.label
    return TransferOp(
        op="push",
        series_key=ms.norm_key,
        label=pc_cf.label or "?",
        pc_path=pc_path,
        tablet_path=tablet_dest,
        bytes=pc_cf.size_bytes,
        display=display,
    )


def _make_delete_op(ms: cm.MatchedSeries, tab_cf: cm.ChapterFile) -> TransferOp:
    assert ms.tablet is not None
    tablet_path = ms.tablet.abs_path.rstrip("/") + "/" + tab_cf.filename
    title = ms.tablet.folder_name
    if ms.pc:
        canon = cm.rank_hid_variants(ms.pc)[0]
        title = canon.title or canon.folder_name
    # For unmatched files (no parsed label), fall back to the filename as
    # the op key — keeps the operation referenceable through preview/apply
    # round-tripping.
    label = tab_cf.label or tab_cf.filename
    display = title + (" Ch " + tab_cf.label if tab_cf.label else " · " + tab_cf.filename)
    return TransferOp(
        op="delete",
        series_key=ms.norm_key,
        label=label,
        pc_path=None,
        tablet_path=tablet_path,
        bytes=tab_cf.size_bytes,
        display=display,
    )


# ============================================================================
# Cover proxy
# ============================================================================


def _cover_cache_path(norm_key: str) -> Path:
    digest = hashlib.sha1(norm_key.encode("utf-8")).hexdigest()[:12]
    return COVERS_DIR / f"{digest}.jpg"


def _read_pc_cover_url(canon: cm.PCSeries) -> str | None:
    if canon.json_path is None or canon.json_malformed:
        return None
    try:
        with open(canon.json_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        return None
    url = data.get("cover")
    if isinstance(url, str) and url.startswith(("http://", "https://")):
        return url
    return None


def _fetch_cover(url: str, dest: Path) -> bool:
    """Download `url` to `dest` atomically. Returns True on success."""
    req = urllib.request.Request(url, headers={"User-Agent": COVER_USER_AGENT})
    tmp = dest.with_suffix(dest.suffix + ".tmp")
    try:
        with urllib.request.urlopen(req, timeout=COVER_FETCH_TIMEOUT) as resp:
            ctype = resp.headers.get("Content-Type", "")
            if not ctype.startswith("image/"):
                return False
            data = resp.read()
        dest.parent.mkdir(parents=True, exist_ok=True)
        with open(tmp, "wb") as f:
            f.write(data)
        os.replace(tmp, dest)
        return True
    except (urllib.error.URLError, urllib.error.HTTPError, socket.timeout, OSError) as e:
        sys.stderr.write(f"cover fetch failed for {url!r}: {e}\n")
        try:
            tmp.unlink()
        except FileNotFoundError:
            pass
        return False


def _svg_placeholder(title: str) -> str:
    safe = (title or "?").replace("<", "&lt;").replace(">", "&gt;").replace("&", "&amp;")
    if len(safe) > 60:
        safe = safe[:57] + "..."
    return (
        "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 280 420' "
        "preserveAspectRatio='xMidYMid meet'>"
        "<rect width='280' height='420' fill='#ebe1cf' stroke='#2a2520' "
        "stroke-width='1.5'/>"
        f"<text x='140' y='216' text-anchor='middle' "
        f"font-family='Cormorant SC, Cormorant Garamond, Garamond, serif' "
        f"font-size='22' fill='#1a1614' font-weight='600' "
        f"letter-spacing='2'>{safe}</text>"
        "</svg>"
    )


# ============================================================================
# Flask app factory
# ============================================================================


def create_app() -> Flask:
    app = Flask(
        __name__,
        template_folder=str(cm.SCRIPT_DIR / "templates"),
        static_folder=str(cm.SCRIPT_DIR / "static"),
    )
    app.jinja_env.trim_blocks = True
    app.jinja_env.lstrip_blocks = True
    # Filters used by templates.
    app.jinja_env.filters["format_size"] = cm.format_size
    app.jinja_env.filters["url_encode_key"] = lambda k: urllib.parse.quote(k, safe="")

    @app.context_processor
    def inject_globals():
        return {
            "app_device": _STATE.device,
            "app_pc_root": str(_STATE.pc_root),
            "app_tablet_root": _STATE.tablet_root,
            "app_generated_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        }

    @app.route("/")
    def dashboard():
        view = _get_comparison()
        return render_template(
            "dashboard.html",
            view=view,
            anomaly_kind_order=ANOMALY_KIND_ORDER,
        )

    @app.route("/api/series/<path:norm_key>")
    def series_detail(norm_key):
        norm_key = urllib.parse.unquote(norm_key)
        _get_comparison()  # ensure matched_by_key is populated
        ms = _STATE._matched_by_key.get(norm_key)
        if ms is None:
            abort(404)
        detail = _detail_payload(ms)
        return render_template("partials/series_detail.html", detail=detail)

    @app.route("/api/preview", methods=["POST"])
    def preview():
        view = _get_comparison()
        payload = request.get_json(silent=True) or {}
        try:
            ops, skipped = _ops_from_request_json(payload, view)
        except ValueError as e:
            return jsonify({"error": str(e)}), 400
        # Group by series for the modal.
        groups: dict[str, dict] = {}
        for op in ops:
            g = groups.setdefault(op.series_key, {
                "series_key": op.series_key,
                "display_title": _display_title_for(op.series_key),
                "push": [], "delete": [],
                "push_bytes": 0, "delete_bytes": 0,
            })
            if op.op == "push":
                g["push"].append({"label": op.label, "bytes": op.bytes, "human": cm.format_size(op.bytes)})
                g["push_bytes"] += op.bytes
            else:
                g["delete"].append({"label": op.label, "bytes": op.bytes, "human": cm.format_size(op.bytes)})
                g["delete_bytes"] += op.bytes
        totals = {
            "files": len(ops),
            "pushes": sum(1 for o in ops if o.op == "push"),
            "deletes": sum(1 for o in ops if o.op == "delete"),
            "bytes": sum(o.bytes for o in ops),
            "bytes_human": cm.format_size(sum(o.bytes for o in ops)),
            "push_bytes": sum(o.bytes for o in ops if o.op == "push"),
            "delete_bytes": sum(o.bytes for o in ops if o.op == "delete"),
            "push_bytes_human": cm.format_size(sum(o.bytes for o in ops if o.op == "push")),
            "delete_bytes_human": cm.format_size(sum(o.bytes for o in ops if o.op == "delete")),
        }
        # Serialize the resolved ops so the modal's Apply button can re-send
        # exactly this batch without round-tripping selection state.
        ops_serialized = [
            {"op": o.op, "series_key": o.series_key, "label": o.label}
            for o in ops
        ]
        return render_template(
            "partials/confirm_modal.html",
            groups=sorted(groups.values(), key=lambda g: g["display_title"].casefold()),
            totals=totals,
            skipped=skipped,
            ops_json=json.dumps({"ops": ops_serialized}),
        )

    @app.route("/api/transfer", methods=["POST"])
    def transfer():
        _get_comparison()
        payload = request.get_json(silent=True) or {}
        try:
            ops, skipped = _ops_from_request_json(payload, _STATE._view)
        except ValueError as e:
            return jsonify({"error": str(e)}), 400
        if not ops:
            return jsonify({"error": "no resolvable ops", "skipped": skipped}), 400
        try:
            state = transfer_runner.start_transfer(
                ops,
                adb_exe=_STATE.adb_exe,
                device=_STATE.device,
                tablet_root=_STATE.tablet_root,
            )
        except RuntimeError as e:
            if str(e) == "busy":
                # Find the active transfer for friendlier UI message.
                active_id = None
                for st in list(getattr(transfer_runner, "_TRANSFERS", {}).values()):
                    if st.status == "running":
                        active_id = st.id
                        break
                return jsonify({"error": "busy", "active_transfer_id": active_id}), 409
            raise
        return render_template(
            "partials/progress_modal.html",
            transfer_id=state.id,
            total_files=len(ops),
            total_bytes=sum(o.bytes for o in ops),
            total_bytes_human=cm.format_size(sum(o.bytes for o in ops)),
        )

    @app.route("/api/transfer/<id>/stream")
    def transfer_stream(id):
        # Encode events as SSE frames. Heartbeats arrive as comment lines so
        # the JS consumer doesn't have to filter them.
        def generate():
            for evt in transfer_runner.iter_events(id, heartbeat_sec=15.0):
                if evt.get("type") == "heartbeat":
                    yield ": heartbeat\n\n"
                else:
                    yield f"data: {json.dumps(evt, ensure_ascii=False, default=str)}\n\n"
        resp = Response(generate(), mimetype="text/event-stream")
        resp.headers["Cache-Control"] = "no-cache"
        resp.headers["X-Accel-Buffering"] = "no"
        return resp

    @app.route("/api/transfer/<id>/cancel", methods=["POST"])
    def transfer_cancel(id):
        ok = transfer_runner.cancel_transfer(id)
        return ("", 204) if ok else (jsonify({"error": "not running"}), 404)

    @app.route("/api/refresh", methods=["POST"])
    def refresh():
        view = _get_comparison(force=True)
        return render_template(
            "partials/dashboard_root.html",
            view=view,
            anomaly_kind_order=ANOMALY_KIND_ORDER,
        )

    @app.route("/api/cover/<path:norm_key>")
    def cover(norm_key):
        norm_key = urllib.parse.unquote(norm_key)
        view = _get_comparison()
        ms = _STATE._matched_by_key.get(norm_key)
        title = norm_key
        canon = None
        if ms is not None and ms.pc:
            canon = cm.rank_hid_variants(ms.pc)[0]
            title = canon.title or canon.folder_name

        dest = _cover_cache_path(norm_key)
        if dest.is_file() and dest.stat().st_size > 0:
            return send_from_directory(
                str(dest.parent), dest.name,
                max_age=86400, mimetype="image/jpeg",
            )

        url = _read_pc_cover_url(canon) if canon else None
        # First try server-side fetch (caches to disk, fast on subsequent loads).
        if url and _fetch_cover(url, dest):
            return send_from_directory(
                str(dest.parent), dest.name,
                max_age=86400, mimetype="image/jpeg",
            )

        # CDN refused the server-side request (typically Cloudflare hotlink
        # protection or TLS fingerprinting). Hand the URL to the browser —
        # its real TLS handshake plus normal Referer succeed where Python's
        # urllib does not. Browser also caches the result naturally.
        if url:
            return redirect(url, code=302)

        return Response(_svg_placeholder(title), mimetype="image/svg+xml")

    return app


def _display_title_for(norm_key: str) -> str:
    ms = _STATE._matched_by_key.get(norm_key)
    if ms is None:
        return norm_key
    if ms.pc:
        canon = cm.rank_hid_variants(ms.pc)[0]
        return canon.title or canon.folder_name
    if ms.tablet:
        return ms.tablet.folder_name
    return norm_key


# ============================================================================
# Entrypoint
# ============================================================================


def _open_browser_later(url: str, delay_sec: float = 0.5) -> None:
    def go():
        try:
            webbrowser.open(url)
        except Exception as e:
            sys.stderr.write(f"browser open failed: {e}\n")
    t = threading.Timer(delay_sec, go)
    t.daemon = True
    t.start()


def main(argv: list[str]) -> int:
    p = argparse.ArgumentParser(
        prog="manga_manager",
        description="Editorial manga sync UI over compare_manga + adb.",
    )
    p.add_argument("--host", default=HOST_DEFAULT,
                   help="bind address (default 127.0.0.1; do not expose publicly)")
    p.add_argument("--port", type=int, default=PORT_DEFAULT)
    p.add_argument("--no-browser", action="store_true")
    p.add_argument("--pc-root", type=Path, default=cm.DEFAULT_PC_ROOT)
    p.add_argument("--tablet-root", default=cm.DEFAULT_TABLET_ROOT)
    p.add_argument("--device", default=None)
    p.add_argument("--adb", default=None)
    p.add_argument("--cache-file", type=Path, default=cm.SCRIPT_DIR / ".tablet_cache.json")
    p.add_argument("--cache-ttl-hours", type=float, default=cm.DEFAULT_CACHE_TTL_HOURS)
    p.add_argument("--size-threshold", type=float, default=30.0)
    args = p.parse_args(argv)

    try:
        adb_exe = cm.resolve_adb(args.adb)
    except FileNotFoundError as e:
        sys.stderr.write(f"ERROR: {e}\n")
        return 2
    try:
        device = cm.resolve_device(adb_exe, args.device)
    except Exception as e:
        sys.stderr.write(f"ERROR: {e}\n")
        return 2
    if not args.pc_root.is_dir():
        sys.stderr.write(f"ERROR: PC root not found: {args.pc_root}\n")
        return 2

    _STATE.adb_exe = adb_exe
    _STATE.device = device
    _STATE.pc_root = args.pc_root
    _STATE.tablet_root = args.tablet_root
    _STATE.size_threshold = args.size_threshold
    _STATE.cache_file = args.cache_file
    _STATE.cache_ttl_hours = args.cache_ttl_hours

    COVERS_DIR.mkdir(parents=True, exist_ok=True)

    app = create_app()
    url = f"http://{args.host}:{args.port}/"
    print(f"Serving manga manager on {url}  (device {device})")
    if not args.no_browser:
        _open_browser_later(url)
    try:
        serve(app, host=args.host, port=args.port, ident="manga-manager")
    except KeyboardInterrupt:
        print("shutting down")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

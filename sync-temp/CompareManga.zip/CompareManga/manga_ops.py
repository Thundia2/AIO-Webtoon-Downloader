"""
manga_ops.py — adb push / delete primitives and tablet path safety.

Owns the subprocess invocations against adb. Stateless and Flask-free;
callers pass adb path, device serial, and tablet_root.

Public surface:
  - TransferError                       exception with stderr_tail
  - sanitize_tablet_segment(name)       safe filename component
  - mkdir_p_on_tablet(...)              `adb shell mkdir -p` wrapper
  - push_chapter(...)                   `adb push --progress` with cancel + progress callback
  - delete_tablet_file(...)             `adb shell rm -f` wrapper (NEVER -rf)
  - delete_tablet_dir(...)              v1.1 stub; raises NotImplementedError

Path safety: every adb call passes through _validate_tablet_path before any
shell expansion. Anything that starts outside the configured tablet root,
contains '..' segments, has line breaks/NUL, or exceeds 4096 chars is
refused at this layer — defense in depth on top of UI filtering.

Self-test: `python manga_ops.py` runs assertions for _validate_tablet_path
and sanitize_tablet_segment.
"""

from __future__ import annotations

import re
import shlex
import subprocess
import threading
import unicodedata
from pathlib import Path
from typing import Callable


# adb push --progress emits lines containing "NN%". Recent platform-tools
# (35+) print "[ NN%] path"; older builds use "path: NN%" or bare "NN%".
# Match any "NN%" with word-boundary; finditer + last match handles cases
# where multiple percents appear in one line (rare).
_PERCENT_RE = re.compile(r"(\d{1,3})%")

# Characters forbidden inside one path segment (folder name or file name).
# '/' and '\' are segment separators on either host; ':*?"<>|' are
# Windows-illegal; control chars trip many readers.
_FORBIDDEN_SEGMENT_CHARS = re.compile(r"[/\\:*?\"<>|\x00-\x1f]")

_BAD_PATH_CHARS = ("\n", "\r", "\x00")
_MAX_PATH_LEN = 4096


class TransferError(Exception):
    """Operational failure during an adb subprocess call.

    stderr_tail carries up to ~4 KB of the failing command's combined output;
    callers surface it in UI logs. returncode is the subprocess exit code if
    the failure came from a completed subprocess.
    """

    def __init__(
        self,
        message: str,
        *,
        stderr_tail: str = "",
        returncode: int | None = None,
    ) -> None:
        super().__init__(message)
        self.stderr_tail = stderr_tail
        self.returncode = returncode


def sanitize_tablet_segment(name: str) -> str:
    """Return a tablet-safe folder/filename component.

    Strips control chars and the Windows-illegal set (Perfect Viewer and
    the user's MTP exporter are happier without these). NFKC-normalizes;
    trims trailing dots and surrounding whitespace. Empty / '.' / '..'
    raise TransferError so callers don't accidentally write to the parent.
    """
    s = unicodedata.normalize("NFKC", name or "")
    s = _FORBIDDEN_SEGMENT_CHARS.sub("", s)
    s = s.rstrip(" .").strip()
    if s in ("", ".", ".."):
        raise TransferError(f"unsafe tablet segment: {name!r}")
    return s


def _validate_tablet_path(path: str, root: str) -> None:
    """Raise TransferError if `path` is unsafe.

    Performed on the LOGICAL path string (pre-shell-quoting). Every adb
    call in this module funnels through this check. Anything passing here
    is still shlex.quote'd before crossing the subprocess boundary.
    """
    if not isinstance(path, str) or not path:
        raise TransferError("empty tablet path")
    if len(path) > _MAX_PATH_LEN:
        raise TransferError(f"tablet path too long ({len(path)} bytes)")
    for ch in _BAD_PATH_CHARS:
        if ch in path:
            raise TransferError(f"tablet path contains forbidden char {ch!r}")
    norm_root = root.rstrip("/")
    if path == norm_root or path == norm_root + "/":
        raise TransferError(f"refusing to operate on tablet root itself: {path!r}")
    if not path.startswith(norm_root + "/"):
        raise TransferError(f"tablet path escapes root {norm_root!r}: {path!r}")
    for segment in path.split("/"):
        if segment == "..":
            raise TransferError(f"tablet path contains '..': {path!r}")


def mkdir_p_on_tablet(
    adb_exe: str,
    device: str,
    dirpath: str,
    *,
    root: str,
) -> None:
    """`adb shell mkdir -p <dirpath>`. Idempotent."""
    _validate_tablet_path(dirpath, root)
    cmd = [adb_exe, "-s", device, "shell", f"mkdir -p {shlex.quote(dirpath)}"]
    proc = subprocess.run(cmd, capture_output=True, timeout=30)
    if proc.returncode != 0:
        tail = (proc.stderr or proc.stdout or b"").decode("utf-8", errors="replace")[-4096:]
        raise TransferError(
            f"adb mkdir -p failed (exit {proc.returncode}) for {dirpath!r}",
            stderr_tail=tail,
            returncode=proc.returncode,
        )


def push_chapter(
    adb_exe: str,
    device: str,
    pc_path: Path,
    tablet_dest_dir: str,
    *,
    root: str,
    on_progress: Callable[[int, int], None] | None = None,
    cancel_event: threading.Event | None = None,
) -> None:
    """Push one local file into `tablet_dest_dir` on the tablet.

    Spawns `adb -s <device> push --progress <pc_path> <dest>/`. Streams the
    merged subprocess output, parses percent values, calls on_progress
    with (pct_int, bytes_done_estimate) for each new percent. Between
    progress events, checks cancel_event; on cancel, terminates the
    subprocess and raises TransferError('cancelled').

    bytes_done_estimate = pct * pc_size // 100 — adb prints percent but not
    byte counts. After successful exit, emits on_progress(100, pc_size) if
    adb didn't already report 100 (some builds skip the final 100%).
    """
    _validate_tablet_path(tablet_dest_dir, root)
    if not pc_path.is_file():
        raise TransferError(f"PC source not found: {pc_path}")
    pc_size = pc_path.stat().st_size

    # Trailing slash on dest tells adb to use the source filename verbatim
    # as the target name instead of treating dest as a target filename.
    # No --progress flag: adb 36+ emits "[ NN%] path" progress lines on
    # stdout by default (suppressible with -q, which we never want here).
    # Older versions ignored an unknown flag; 36.0.2 rejects --progress
    # with "unrecognized option" — so we leave it off entirely.
    dest = tablet_dest_dir.rstrip("/") + "/"
    cmd = [
        adb_exe, "-s", device,
        "push",
        str(pc_path),
        dest,
    ]

    # Merged stdout+stderr — Windows-safe (select on pipes is Unix-only).
    # text=False (binary) + manual decoding because adb-on-Windows sometimes
    # emits raw \r for progress overwrites; we need to split on \r AND \n.
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        bufsize=0,
    )

    last_pct = -1
    tail_buf: list[str] = []
    leftover = b""
    try:
        assert proc.stdout is not None
        while True:
            chunk = proc.stdout.read(256)
            if not chunk:
                if proc.poll() is not None:
                    break
                # No data yet, process still running — keep looping; this
                # branch is rare in practice because read() blocks until
                # bytes arrive or EOF.
                continue

            if cancel_event is not None and cancel_event.is_set():
                _kill(proc)
                raise TransferError("cancelled", returncode=proc.returncode)

            leftover += chunk
            # Split on any of \r\n, \n, \r — adb on Windows uses \r for
            # progress redraws.
            parts = re.split(rb"\r\n|\r|\n", leftover)
            # Last element is the incomplete tail to keep for the next read.
            leftover = parts.pop()
            for raw in parts:
                if not raw:
                    continue
                line = raw.decode("utf-8", errors="replace")
                tail_buf.append(line)
                if len(tail_buf) > 128:
                    del tail_buf[:64]
                matches = list(_PERCENT_RE.finditer(line))
                if matches and on_progress is not None:
                    pct = int(matches[-1].group(1))
                    if 0 <= pct <= 100 and pct != last_pct:
                        last_pct = pct
                        bytes_done = (pct * pc_size) // 100
                        try:
                            on_progress(pct, bytes_done)
                        except Exception:
                            # Never let a callback kill the worker thread.
                            pass

            if cancel_event is not None and cancel_event.is_set():
                _kill(proc)
                raise TransferError("cancelled", returncode=proc.returncode)

        # Flush the final leftover, if any.
        if leftover:
            line = leftover.decode("utf-8", errors="replace")
            tail_buf.append(line)
    finally:
        if proc.poll() is None:
            _kill(proc)

    if proc.returncode != 0:
        raise TransferError(
            f"adb push failed (exit {proc.returncode}) for {pc_path.name}",
            stderr_tail="\n".join(tail_buf[-64:]),
            returncode=proc.returncode,
        )

    # Final 100% — some adb builds skip the last percent line.
    if on_progress is not None and last_pct != 100:
        try:
            on_progress(100, pc_size)
        except Exception:
            pass


def _kill(proc: subprocess.Popen) -> None:
    """Terminate a subprocess; escalate to kill if it doesn't exit in 5s."""
    try:
        proc.terminate()
    except OSError:
        return
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        try:
            proc.kill()
        except OSError:
            pass


def delete_tablet_file(
    adb_exe: str,
    device: str,
    tablet_path: str,
    *,
    root: str,
) -> None:
    """`adb shell rm -f <path>` — single file delete only. NEVER -rf here."""
    _validate_tablet_path(tablet_path, root)
    cmd = [
        adb_exe, "-s", device, "shell",
        f"rm -f {shlex.quote(tablet_path)}",
    ]
    proc = subprocess.run(cmd, capture_output=True, timeout=30)
    if proc.returncode != 0:
        tail = (proc.stderr or proc.stdout or b"").decode("utf-8", errors="replace")[-4096:]
        raise TransferError(
            f"adb rm -f failed (exit {proc.returncode}) for {tablet_path!r}",
            stderr_tail=tail,
            returncode=proc.returncode,
        )


def delete_tablet_dir(
    adb_exe: str,
    device: str,
    tablet_path: str,
    *,
    root: str,
) -> None:
    """Stub for v1.1 — whole-folder delete. Path safety is committed so
    enabling this becomes a single rm -rf wrapper change."""
    _validate_tablet_path(tablet_path, root)
    raise NotImplementedError(
        "delete_tablet_dir is deferred; use delete_tablet_file per chapter"
    )


# --- self-test ----------------------------------------------------------------


def _run_self_test() -> int:
    fails = 0
    root = "/storage/self/primary/Documents"

    def expect_raises(label: str, fn):
        nonlocal fails
        try:
            fn()
            print(f"  [FAIL] {label}: expected TransferError, got success")
            fails += 1
        except TransferError as e:
            print(f"  [PASS] {label}: {e}")
        except Exception as e:
            print(f"  [FAIL] {label}: expected TransferError, got {type(e).__name__}: {e}")
            fails += 1

    def expect_ok(label: str, fn):
        nonlocal fails
        try:
            fn()
            print(f"  [PASS] {label}")
        except Exception as e:
            print(f"  [FAIL] {label}: {type(e).__name__}: {e}")
            fails += 1

    print("_validate_tablet_path:")
    expect_raises("empty path",                  lambda: _validate_tablet_path("", root))
    expect_raises("not under root",              lambda: _validate_tablet_path("/etc/passwd", root))
    expect_raises("equals root",                 lambda: _validate_tablet_path(root, root))
    expect_raises("equals root with slash",      lambda: _validate_tablet_path(root + "/", root))
    expect_raises("contains ..",                 lambda: _validate_tablet_path(f"{root}/Bleach/../etc", root))
    expect_raises("contains newline",            lambda: _validate_tablet_path(f"{root}/Bleach\nfoo.pdf", root))
    expect_raises("contains NUL",                lambda: _validate_tablet_path(f"{root}/Bleach\x00.pdf", root))
    expect_raises("too long",                    lambda: _validate_tablet_path(f"{root}/" + "x" * 5000, root))
    expect_raises("traversal from prefix match", lambda: _validate_tablet_path("/storage/self/primary/DocumentsX/Bleach.pdf", root))
    expect_ok("nested valid path",               lambda: _validate_tablet_path(f"{root}/Bleach/Bleach Ch 1.pdf", root))
    expect_ok("apostrophe ok",                   lambda: _validate_tablet_path(f"{root}/JoJo's/JoJo's Ch 1.pdf", root))
    expect_ok("unicode ok",                      lambda: _validate_tablet_path(f"{root}/CØDEBREAKER/Ch 1.pdf", root))

    print("\nsanitize_tablet_segment:")
    expect_ok("Bleach",          lambda: _check_sanitize("Bleach", "Bleach"))
    expect_ok("trailing dots",   lambda: _check_sanitize("Foo...", "Foo"))
    expect_ok("forbidden chars", lambda: _check_sanitize("Fo:o*?<>|", "Foo"))
    expect_ok("apostrophe kept", lambda: _check_sanitize("JoJo's", "JoJo's"))
    expect_ok("NFKC ok",         lambda: _check_sanitize("Café", "Café"))
    expect_raises("empty result",lambda: sanitize_tablet_segment("///"))
    expect_raises("just dots",   lambda: sanitize_tablet_segment(".."))

    print(f"\n{fails} failure(s).")
    return 0 if fails == 0 else 1


def _check_sanitize(inp: str, want: str) -> None:
    got = sanitize_tablet_segment(inp)
    if got != want:
        raise AssertionError(f"sanitize({inp!r}): got {got!r}, want {want!r}")


if __name__ == "__main__":
    import sys
    sys.exit(_run_self_test())

"""
push_all_to_tablet.py — Mirror the PC manga library to the tablet.

For every PC series folder (hid variants collapsed into one logical series):
  1. Compute target tablet folder name = sanitize(PC base name, hid stripped).
  2. Find matching tablet folder(s) via normalize_series_name + explicit aliases.
  3. `adb shell rm -rf` each matched tablet folder.
  4. `adb push` the canonical PC folder.
  5. If the pushed folder name differs from the target (PC had a hid suffix),
     `adb shell mv` to rename on the tablet.
  6. `adb shell rm -f` the .aio_series.json / .mangafire_hid sidecars on tablet.

Tablet folders with NO PC match are left untouched. Verified by alias check:
every tablet folder either normalizes to a PC series's norm key, has an
explicit alias to a PC folder, or is listed in TABLET_PRESERVE.

Reads:
  - PC root: cm.DEFAULT_PC_ROOT
  - Tablet root: cm.DEFAULT_TABLET_ROOT  (default /storage/self/primary/Documents)
  - adb at cm.KNOWN_ADB_PATH fallback (PATH lookup first)

Writes:
  - transfer-log-<YYYYMMDD-HHMMSS>.json — per-op result
  - stdout — plan, progress, summary

Modes:
  --plan                Print plan and exit (default).
  --apply               Execute the plan after a confirmation prompt.
  --apply --yes         Execute without the confirmation prompt.
  --only NAME           Push only PC series whose canonical folder == NAME.
                        Repeatable.
  --skip NAME           Skip PC series whose canonical folder == NAME.
                        Repeatable.

Depends on compare_manga (scan_pc_library, normalize_series_name,
rank_hid_variants) and manga_ops (sanitize_tablet_segment).

Self-test: `python push_all_to_tablet.py --self-test` validates the alias
table against the actual PC folder set and the normalize() matching.
"""

from __future__ import annotations

import argparse
import json
import os
import shlex
import shutil
import subprocess
import sys
import time
import unicodedata
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path

# compare_manga lives in the same directory; ensure importable.
sys.path.insert(0, str(Path(__file__).resolve().parent))
import compare_manga as cm  # noqa: E402
from manga_ops import sanitize_tablet_segment  # noqa: E402


# ============================================================================
# Aliases & constants
# ============================================================================

# Tablet folder name -> PC folder name. For series where
# compare_manga.normalize_series_name() can't bridge the two sides (different
# language, Unicode multiplication sign, "(Official)" suffix, etc.).
#
# Each entry: tablet folder *as it appears on the tablet* -> the canonical PC
# folder it corresponds to. The PC folder must exist in the PC library; the
# self-test asserts this.
ALIASES_TABLET_TO_PC: dict[str, str] = {
    "A Certain Scientific Railgun":
        "Toaru Majutsu no Index Gaiden Toaru Kagaku no Railgun",
    "CØDEBREAKER": "Code Breaker",
    "Every Day Is a Holiday (Colored)": "Kinenbi Manga",
    "Fullmetal Alchemist": "FULL METAL ALCHEMIST",
    "Ghost Sore wa rei no Shiwaza desu": "Sore wa rei no Shiwaza desu",
    "Is_the_order_a_rabbit": "Gochuumon wa Usagi desu ka",
    "JoJo's Bizarre Adventure Part 5 Golden Wind":
        "JoJo no Kimyou na Bouken Part 5 - Ougon no Kaze",
    "JoJo's_Bizarre_Adventure_Part_4_Diamond_is_Unbreakable":
        "JoJo no Kimyou na Bouken Part 4 - Diamond wa Kudakenai",
    "Makeine Make Hiroin ga Ōsugiru!": "Too Many Losing Heroines!",
    "No Longer Allowed In Another World": "Isekai Shikkaku",
    "One-Punch_Man_(Official)": "One-Punch Man",
    "Record of Ragnarok": "Shuumatsu no Valkyrie",
    "SPY_x_FAMILY": "SPY×FAMILY",
    "Slow Life In Another World (I Wish!)": "Isekai de Slow Life o (Ganbou)",
}

# Naming policy: for ALIASED tablet/PC pairs, the user prefers to keep the
# tablet's existing folder name (more readable / annotated), so the pushed
# content lands under that name. For non-aliased norm matches, the PC's
# folder name (hid stripped, sanitized) wins because tablet names with
# underscores (Attack_on_Titan, Demon_Slayer_...) are uglier than PC's clean
# variants. See AskUserQuestion answer 2026-05-24.
KEEP_TABLET_NAME_FOR_ALIASES = True

# Tablet sidecars/dotfiles that may have ended up next to chapters during the
# push (we copy the whole PC folder); these are removed after the push.
# .series_hid was added by AIO after 2026-05; it's a 3-5 byte hid stub like
# .mangafire_hid. cover.jpg + details.json are intentionally KEPT (Komikku reads
# them). grep adb_remove_sidecars for the single consumer of this tuple.
SIDECARS_ON_TABLET = (".aio_series.json", ".mangafire_hid", ".series_hid")

PC_ROOT: Path = cm.DEFAULT_PC_ROOT
TABLET_ROOT: str = cm.DEFAULT_TABLET_ROOT
SCRIPT_DIR: Path = Path(__file__).resolve().parent


# ============================================================================
# Dataclasses
# ============================================================================


@dataclass
class PlanEntry:
    """One PC -> tablet push operation."""
    norm_key: str
    pc_canonical_folder: str
    pc_canonical_path: Path
    pc_variant_folders: list[str]          # all PC folders for this norm key
    pc_chapter_count: int                  # cbz/pdf only, canonical variant
    pc_size_bytes: int                     # canonical variant size
    matched_tablet_folders: list[str]      # tablet folders to delete first
    matched_tablet_chapters: dict[str, int]   # tablet folder -> chapter count
    target_tablet_name: str                # sanitized PC base name (hid stripped)
    target_tablet_path: str                # full tablet path under TABLET_ROOT
    push_source_basename: str              # canonical folder basename (raw)
    needs_rename: bool                     # True if push_source_basename != target_tablet_name
    via_alias: bool                        # True if at least one matched-tablet uses alias

    @property
    def chapter_delta(self) -> int:
        """Net chapter count change on tablet (sum across matched tablet folders)."""
        tab_total = sum(self.matched_tablet_chapters.values())
        return self.pc_chapter_count - tab_total


@dataclass
class OpResult:
    series: str
    target: str
    deleted: list[str] = field(default_factory=list)
    pushed_bytes: int = 0
    pushed_files: int = 0
    duration_sec: float = 0.0
    ok: bool = False
    error: str | None = None


# ============================================================================
# adb helpers
# ============================================================================


def adb_exe() -> str:
    return cm.resolve_adb(None)


def adb_device(adb_path: str, override: str | None = None) -> str:
    return cm.resolve_device(adb_path, override)


def _adb_run(adb: str, device: str, args: list[str], *, timeout: float,
             stream_output: bool = False) -> tuple[int, str, str]:
    """Run adb -s <device> <args...>. Returns (rc, stdout, stderr).

    Streams stdout to terminal when stream_output is True (used for `push`
    to surface progress). All operations have a finite timeout to prevent
    a hung adb invocation from blocking the batch indefinitely.
    """
    cmd = [adb, "-s", device] + args
    if not stream_output:
        p = subprocess.run(cmd, capture_output=True, timeout=timeout)
        return (
            p.returncode,
            p.stdout.decode("utf-8", errors="replace"),
            p.stderr.decode("utf-8", errors="replace"),
        )
    # Stream mode: merge stderr into stdout, decode incrementally, echo lines
    # to our stderr (so caller's stdout stays clean for JSON-friendly use).
    p = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        bufsize=0,
    )
    tail: list[str] = []
    start = time.time()
    assert p.stdout is not None
    leftover = b""
    try:
        while True:
            if time.time() - start > timeout:
                p.kill()
                return (-1, "".join(tail), f"timeout after {timeout}s")
            chunk = p.stdout.read(1024)
            if not chunk:
                if p.poll() is not None:
                    break
                continue
            leftover += chunk
            parts = leftover.replace(b"\r", b"\n").split(b"\n")
            leftover = parts.pop()
            for raw in parts:
                if not raw:
                    continue
                line = raw.decode("utf-8", errors="replace")
                tail.append(line + "\n")
                if len(tail) > 500:
                    del tail[:250]
                sys.stderr.write(f"  {line}\n")
                sys.stderr.flush()
    finally:
        if p.poll() is None:
            try:
                p.terminate()
                p.wait(timeout=5)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass
    if leftover:
        line = leftover.decode("utf-8", errors="replace")
        tail.append(line + "\n")
    return (p.returncode, "".join(tail), "")


def adb_shell(adb: str, device: str, cmd_str: str, *, timeout: float = 60) -> tuple[int, str, str]:
    return _adb_run(adb, device, ["shell", cmd_str], timeout=timeout)


def _validate_tablet_path(path: str) -> None:
    """Reject paths that escape TABLET_ROOT or contain dangerous characters.

    Belt-and-braces over adb shell quoting: even if shlex.quote slipped, the
    path string itself can't talk us into operating outside the manga library.
    """
    if not path:
        raise ValueError("empty tablet path")
    if any(c in path for c in ("\n", "\r", "\x00")):
        raise ValueError(f"bad characters in tablet path: {path!r}")
    root = TABLET_ROOT.rstrip("/")
    if path == root or path == root + "/":
        raise ValueError(f"refusing to operate on tablet root itself: {path!r}")
    if not path.startswith(root + "/"):
        raise ValueError(f"path escapes tablet root: {path!r}")
    for seg in path.split("/"):
        if seg == "..":
            raise ValueError(f"path contains '..': {path!r}")


def tablet_path(name: str) -> str:
    return f"{TABLET_ROOT.rstrip('/')}/{name}"


def list_tablet_folders(adb: str, device: str) -> list[str]:
    """Top-level immediate subdirectories of TABLET_ROOT."""
    rc, out, err = adb_shell(
        adb, device,
        f"find {shlex.quote(TABLET_ROOT)} -mindepth 1 -maxdepth 1 -type d -printf '%f\\n'",
        timeout=30,
    )
    if rc != 0:
        raise RuntimeError(f"list_tablet_folders failed: {err.strip()}")
    return sorted([s.strip() for s in out.splitlines() if s.strip()], key=str.casefold)


def adb_rm_rf(adb: str, device: str, path: str) -> None:
    _validate_tablet_path(path)
    rc, out, err = adb_shell(
        adb, device,
        f"rm -rf {shlex.quote(path)}",
        timeout=300,
    )
    if rc != 0:
        raise RuntimeError(f"rm -rf failed for {path!r}: rc={rc} stderr={err.strip()[:200]}")


def adb_mkdir_p(adb: str, device: str, path: str) -> None:
    _validate_tablet_path(path)
    rc, out, err = adb_shell(
        adb, device,
        f"mkdir -p {shlex.quote(path)}",
        timeout=30,
    )
    if rc != 0:
        raise RuntimeError(f"mkdir -p failed for {path!r}: rc={rc} stderr={err.strip()[:200]}")


def adb_mv(adb: str, device: str, src: str, dst: str) -> None:
    _validate_tablet_path(src)
    _validate_tablet_path(dst)
    rc, out, err = adb_shell(
        adb, device,
        f"mv {shlex.quote(src)} {shlex.quote(dst)}",
        timeout=60,
    )
    if rc != 0:
        raise RuntimeError(f"mv failed: {src!r} -> {dst!r}: {err.strip()[:200]}")


def adb_path_exists(adb: str, device: str, path: str) -> bool:
    """True if `path` exists on the tablet (file or dir)."""
    _validate_tablet_path(path)
    rc, out, err = adb_shell(
        adb, device,
        f"[ -e {shlex.quote(path)} ] && echo Y || echo N",
        timeout=30,
    )
    return rc == 0 and out.strip().endswith("Y")


def adb_landed_basename(name: str) -> str | None:
    """The folder basename `adb push <dir>` actually creates for source `name`.

    adb 36.x on Windows truncates a non-ASCII source basename: it keeps only the
    first (character-count) BYTES of the UTF-8 encoding, dropping (bytes - chars)
    trailing bytes. Verified live 2026-06-14: 'SPY×FAMILY' (11B/10ch) lands as
    'SPY×FAMIL'; "Hell's Paradise" (’ = +2B) lands as 'Hell's Paradi'. ASCII
    names are unaffected. See [[bug-adb-push-utf8-truncation]] in memory and the
    push step in apply_plan() (the lone caller, with a listing fallback).

    Returns the landed basename, or None if the byte cut split a multibyte char
    (not seen in this library, but then the caller discovers it by listing).
    """
    encoded = name.encode("utf-8")
    if len(encoded) == len(name):          # pure ASCII: 1 byte per char, no cut
        return name
    cut = encoded[: len(name)]             # keep first char-count bytes
    try:
        return cut.decode("utf-8")
    except UnicodeDecodeError:
        return None


def _find_landed_by_listing(adb: str, device: str, push_basename: str) -> str | None:
    """Discover the just-pushed folder by listing TABLET_ROOT.

    Fallback for adb_landed_basename(): the landed name is either an exact match
    or a UTF-8 byte-prefix of `push_basename` whose byte length equals the source
    character count (the truncation rule). Pinning the length prevents matching
    an unrelated shorter series that merely shares a prefix (e.g. 'The Angel Next
    Door Spoils Me Rotten' vs its '... After the Rain' sequel).
    """
    folders = list_tablet_folders(adb, device)
    if push_basename in folders:
        return push_basename
    pb = push_basename.encode("utf-8")
    want_len = len(push_basename)           # expected landed byte length
    for f in folders:
        fb = f.encode("utf-8")
        if len(fb) == want_len and pb.startswith(fb):
            return f
    return None


def adb_remove_sidecars(adb: str, device: str, folder_path: str) -> None:
    """rm -f the sidecar files inside `folder_path` on the tablet."""
    _validate_tablet_path(folder_path)
    parts = [
        shlex.quote(folder_path.rstrip("/") + "/" + name)
        for name in SIDECARS_ON_TABLET
    ]
    cmd = "rm -f " + " ".join(parts)
    # Best-effort; sidecars may not exist on a fresh push.
    adb_shell(adb, device, cmd, timeout=30)


def adb_push_folder(adb: str, device: str, pc_folder: Path, tablet_dest_dir: str) -> tuple[int, str]:
    """Push the entire PC folder (recursive) into TABLET_ROOT.

    adb push behavior: `adb push <src_dir> <dst_dir_with_trailing_slash>` copies
    src_dir AS a child of dst_dir, creating <dst_dir>/<basename(src_dir)>/...
    So we point at TABLET_ROOT/ and adb places the folder under it using the
    PC folder basename. We rename on the tablet afterward if the basename
    needs to change (hid stripping, alias).

    Returns (returncode, stdout_tail).
    """
    if not pc_folder.is_dir():
        raise FileNotFoundError(f"PC folder missing: {pc_folder}")
    _validate_tablet_path(tablet_dest_dir.rstrip("/") + "/__push_probe__")
    dest = tablet_dest_dir.rstrip("/") + "/"
    rc, out, err = _adb_run(
        adb, device,
        ["push", str(pc_folder), dest],
        timeout=14400,  # 4 hour ceiling per single folder (One Piece is 11 GB)
        stream_output=True,
    )
    return rc, out


# ============================================================================
# PC scanning + plan
# ============================================================================


def _strip_hid(name: str) -> str:
    m = cm.RE_HID_SUFFIX.match(name)
    return m.group(1).strip() if m else name


def scan_pc() -> list[cm.PCSeries]:
    return cm.scan_pc_library(PC_ROOT)


def build_plan(
    pc: list[cm.PCSeries],
    tablet_folders: list[str],
) -> tuple[list[PlanEntry], list[str], list[str]]:
    """Returns (plan_entries, tablet_only, alias_errors).

    plan_entries: one per PC norm-key group (canonical chosen by chapter
                  count via cm.rank_hid_variants).
    tablet_only: tablet folders with no PC match (preserved).
    alias_errors: tablet folders whose alias maps to a non-existent PC folder.
    """
    # Group PC folders by their norm key
    pc_by_norm: dict[str, list[cm.PCSeries]] = {}
    for s in pc:
        pc_by_norm.setdefault(cm.normalize_series_name(s.folder_name), []).append(s)

    pc_folder_set = {s.folder_name for s in pc}
    alias_errors: list[str] = []

    # Compute effective norm key for each tablet folder
    tablet_to_norm: dict[str, str] = {}
    tablet_uses_alias: dict[str, bool] = {}
    for tf in tablet_folders:
        target = ALIASES_TABLET_TO_PC.get(tf)
        if target is not None:
            if target not in pc_folder_set:
                alias_errors.append(
                    f"alias {tf!r} -> {target!r}: PC folder not found"
                )
            tablet_to_norm[tf] = cm.normalize_series_name(target)
            tablet_uses_alias[tf] = True
        else:
            tablet_to_norm[tf] = cm.normalize_series_name(tf)
            tablet_uses_alias[tf] = False

    tablet_by_norm: dict[str, list[str]] = {}
    for tf, nk in tablet_to_norm.items():
        tablet_by_norm.setdefault(nk, []).append(tf)

    # Build per-PC-group plan entries
    entries: list[PlanEntry] = []
    used_tablet_norms: set[str] = set()
    for nk, variants in pc_by_norm.items():
        canonical = cm.rank_hid_variants(variants)[0]
        if len(canonical.chapter_files) == 0:
            # All variants empty: nothing to push for this norm key.
            continue
        matched = sorted(tablet_by_norm.get(nk, []), key=str.casefold)
        used_tablet_norms.add(nk)

        via_alias = any(tablet_uses_alias.get(tf, False) for tf in matched)

        # Choose the target tablet folder name. For aliased pairs we keep
        # the tablet's existing (often more-readable) name; otherwise the
        # PC base name with hid stripped is cleaner.
        if matched and via_alias and KEEP_TABLET_NAME_FOR_ALIASES:
            target_name = sanitize_tablet_segment(matched[0])
        else:
            target_name = sanitize_tablet_segment(_strip_hid(canonical.folder_name))
        push_basename = canonical.folder_name  # what `adb push` will name the folder
        needs_rename = (push_basename != target_name)

        matched_chapters: dict[str, int] = {}
        # The accurate per-tablet-folder chapter counts come from the caller;
        # we leave them empty here and fill in print_plan() via a side lookup.
        for tf in matched:
            matched_chapters[tf] = 0

        entries.append(PlanEntry(
            norm_key=nk,
            pc_canonical_folder=canonical.folder_name,
            pc_canonical_path=canonical.abs_path,
            pc_variant_folders=[v.folder_name for v in variants],
            pc_chapter_count=len(canonical.chapter_files),
            pc_size_bytes=sum(c.size_bytes for c in canonical.chapter_files),
            matched_tablet_folders=matched,
            matched_tablet_chapters=matched_chapters,
            target_tablet_name=target_name,
            target_tablet_path=tablet_path(target_name),
            push_source_basename=push_basename,
            needs_rename=needs_rename,
            via_alias=via_alias,
        ))

    entries.sort(key=lambda e: e.target_tablet_name.casefold())

    tablet_only = sorted(
        [tf for tf, nk in tablet_to_norm.items() if nk not in used_tablet_norms],
        key=str.casefold,
    )

    return entries, tablet_only, alias_errors


# ============================================================================
# Plan rendering
# ============================================================================


def _fmt_bytes(n: int) -> str:
    f = float(n)
    for unit in ("B", "KB", "MB", "GB"):
        if f < 1024 or unit == "GB":
            return f"{f:.1f}{unit}"
        f /= 1024
    return f"{f:.1f}TB"


def _is_chapter_extension(fmt: str) -> bool:
    """Strip cover.jpg/details.json from chapter counts. The tablet scanner
    accepts any extension; we only consider pdf/cbz files actual chapters."""
    return fmt.lower() in ("pdf", "cbz")


def fill_tablet_chapter_counts(
    entries: list[PlanEntry],
    tablet_series_by_name: dict[str, "cm.TabletSeries"],
) -> None:
    for e in entries:
        for tf in e.matched_tablet_folders:
            ts = tablet_series_by_name.get(tf)
            if ts is None:
                continue
            # Only count depth-1 .pdf/.cbz files (no cover.jpg, details.json,
            # nested anthology pages).
            e.matched_tablet_chapters[tf] = sum(
                1 for cf in ts.chapter_files
                if "/" not in cf.filename and _is_chapter_extension(cf.fmt)
            )


def print_plan(
    entries: list[PlanEntry],
    tablet_only: list[str],
    alias_errors: list[str],
    pc: list[cm.PCSeries],
    tablet_folders: list[str],
    tablet_series_by_name: dict[str, "cm.TabletSeries"],
) -> None:
    print()
    print("=" * 96)
    print(f"  PUSH PLAN — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 96)
    print(f"  PC root:        {PC_ROOT}")
    print(f"  Tablet root:    {TABLET_ROOT}")
    print(f"  PC folders:     {len(pc)}")
    print(f"  Tablet folders: {len(tablet_folders)}")
    print()

    if alias_errors:
        print("!! ALIAS ERRORS (will abort apply):")
        for e in alias_errors:
            print(f"   - {e}")
        print()

    n_replace = sum(1 for e in entries if e.matched_tablet_folders)
    n_new = sum(1 for e in entries if not e.matched_tablet_folders)
    n_delete = sum(len(e.matched_tablet_folders) for e in entries)
    total_chapters = sum(e.pc_chapter_count for e in entries)
    total_bytes = sum(e.pc_size_bytes for e in entries)
    tablet_delete_bytes = 0
    for e in entries:
        for tf in e.matched_tablet_folders:
            ts = tablet_series_by_name.get(tf)
            if ts:
                tablet_delete_bytes += sum(c.size_bytes for c in ts.chapter_files)

    print("  SUMMARY")
    print(f"    PC series to push:           {len(entries)}  "
          f"({total_chapters} chapters, {_fmt_bytes(total_bytes)})")
    print(f"      replacing tablet folder:   {n_replace}")
    print(f"      new (no tablet match):     {n_new}")
    print(f"    Tablet folders to delete:    {n_delete}  "
          f"(~{_fmt_bytes(tablet_delete_bytes)} freed)")
    print(f"    Tablet folders preserved:    {len(tablet_only)}  "
          f"(no PC match)")
    print()

    # Operations table
    print("  OPERATIONS (sorted by target name)")
    hdr = (f"    {'#':>3}  {'target tablet folder':<55}  "
           f"{'PCch':>5}  {'tabCh':>5}  {'Δ':>5}  {'GB':>5}  match")
    print(hdr)
    print("    " + "-" * (len(hdr) - 4))

    big_losses: list[tuple[str, int]] = []
    new_pushes: list[str] = []
    rename_ops: list[tuple[str, str]] = []
    alias_ops: list[tuple[str, str, str]] = []

    for i, e in enumerate(entries, 1):
        target_short = e.target_tablet_name
        if len(target_short) > 53:
            target_short = target_short[:50] + "..."
        tab_ch = sum(e.matched_tablet_chapters.values()) if e.matched_tablet_folders else 0
        delta = e.pc_chapter_count - tab_ch
        gb = e.pc_size_bytes / 1024 / 1024 / 1024
        if not e.matched_tablet_folders:
            match_str = "(new)"
            new_pushes.append(e.target_tablet_name)
        else:
            tabs = e.matched_tablet_folders
            if e.via_alias:
                match_str = "alias: " + ", ".join(tabs)
                alias_ops.append((e.pc_canonical_folder, e.target_tablet_name,
                                  ", ".join(tabs)))
            else:
                match_str = ", ".join(tabs)
            if len(match_str) > 30:
                match_str = match_str[:27] + "..."

        print(f"    {i:>3}  {target_short:<55}  "
              f"{e.pc_chapter_count:>5}  {tab_ch:>5}  {delta:>+5}  "
              f"{gb:>5.1f}  {match_str}")
        if delta <= -20:
            big_losses.append((e.target_tablet_name, delta))
        if e.needs_rename:
            rename_ops.append((e.push_source_basename, e.target_tablet_name))

    print()
    if big_losses:
        print(f"  CHAPTER LOSSES ≥ 20 ({len(big_losses)} series)")
        print(f"    These tablet folders have MORE chapters than PC; "
              f"push will reduce the count.")
        for name, delta in sorted(big_losses, key=lambda x: x[1]):
            print(f"    {delta:>+5}  {name}")
        print()

    if alias_ops:
        print(f"  EXPLICIT ALIAS MAPPINGS ({len(alias_ops)})")
        for pc_folder, target, tablet_name in alias_ops:
            print(f"    tablet {tablet_name!r}")
            print(f"      -> PC {pc_folder!r}")
            print(f"      -> new tablet name {target!r}")
        print()

    if rename_ops:
        print(f"  TABLET-SIDE RENAME (hid suffix or sanitization, {len(rename_ops)})")
        for src, dst in rename_ops:
            print(f"    {src!r}")
            print(f"      -> {dst!r}")
        print()

    if new_pushes:
        print(f"  NEW SERIES PUSHED (no current tablet folder, {len(new_pushes)})")
        for name in new_pushes:
            print(f"    + {name}")
        print()

    if tablet_only:
        print(f"  TABLET-ONLY — PRESERVED ({len(tablet_only)})")
        for name in tablet_only:
            ts = tablet_series_by_name.get(name)
            nc = len(ts.chapter_files) if ts else "?"
            print(f"    = {name}  ({nc} files)")
        print()


# ============================================================================
# Apply
# ============================================================================


def apply_plan(
    entries: list[PlanEntry],
    adb: str,
    device: str,
    log_path: Path,
) -> tuple[int, int]:
    """Execute the plan. Returns (n_ok, n_fail).

    Each entry: delete matched tablet folders, push canonical PC folder,
    rename if needed, strip sidecars. Failures are logged and the loop
    continues — partial completion is the expected mode if e.g. USB
    flickers mid-batch.
    """
    results: list[OpResult] = []
    start_t = time.time()
    for i, e in enumerate(entries, 1):
        op_start = time.time()
        r = OpResult(
            series=e.pc_canonical_folder,
            target=e.target_tablet_path,
        )
        sys.stderr.write(
            f"\n[{i:>3}/{len(entries)}] {e.target_tablet_name}  "
            f"({e.pc_chapter_count} ch, {_fmt_bytes(e.pc_size_bytes)})\n"
        )
        try:
            # 1. Delete matched tablet folders
            for tf in e.matched_tablet_folders:
                tp = tablet_path(tf)
                sys.stderr.write(f"  rm -rf  {tp}\n")
                adb_rm_rf(adb, device, tp)
                r.deleted.append(tf)

            # 2. Pre-clean the target name and any stale push-landing left by a
            #    prior aborted run (rm -rf is silent on ENOENT). The landing may
            #    be a UTF-8-truncated variant of the PC basename (see
            #    adb_landed_basename), so rm that too for a clean retry.
            target_path = e.target_tablet_path
            if e.target_tablet_name not in e.matched_tablet_folders:
                adb_rm_rf(adb, device, target_path)
            for nm in {e.push_source_basename, adb_landed_basename(e.push_source_basename)}:
                if not nm or nm in e.matched_tablet_folders:
                    continue
                p = tablet_path(nm)
                if p != target_path:
                    adb_rm_rf(adb, device, p)

            # 3. Push the canonical PC folder
            sys.stderr.write(
                f"  push    {e.pc_canonical_folder!r}  ->  {TABLET_ROOT}/\n"
            )
            rc, tail = adb_push_folder(
                adb, device, e.pc_canonical_path, TABLET_ROOT,
            )
            if rc != 0:
                raise RuntimeError(
                    f"adb push exited rc={rc}; tail:\n{tail[-1000:]}"
                )

            # 4. Locate the landed folder and rename to target if they differ.
            #    adb truncates non-ASCII basenames, so the landing may not equal
            #    push_source_basename; trust the computed truncation, then fall
            #    back to discovery by listing. This is what makes SPY×FAMILY,
            #    Hell's Paradise, You Can't Be In a Rom-Com... land correctly.
            landed = adb_landed_basename(e.push_source_basename)
            if landed is None or not adb_path_exists(adb, device, tablet_path(landed)):
                landed = _find_landed_by_listing(adb, device, e.push_source_basename)
            if landed is None:
                raise RuntimeError(
                    f"pushed folder not found on tablet under "
                    f"{e.push_source_basename!r} or any truncated variant"
                )
            if landed != e.target_tablet_name:
                sys.stderr.write(
                    f"  mv      {landed!r}  ->  {e.target_tablet_name!r}"
                    + ("  (adb-truncated push)"
                       if landed != e.push_source_basename else "")
                    + "\n"
                )
                adb_mv(adb, device, tablet_path(landed), target_path)

            # 5. Strip sidecars
            adb_remove_sidecars(adb, device, target_path)

            r.pushed_bytes = e.pc_size_bytes
            r.pushed_files = e.pc_chapter_count
            r.ok = True
        except Exception as ex:
            r.ok = False
            r.error = f"{type(ex).__name__}: {ex}"
            sys.stderr.write(f"  !! ERROR: {r.error}\n")
        finally:
            r.duration_sec = round(time.time() - op_start, 2)
            results.append(r)
            # Persist log incrementally so a kill mid-batch still leaves a
            # readable record of progress so far.
            _save_log(log_path, results, started_at=start_t)

    n_ok = sum(1 for r in results if r.ok)
    n_fail = sum(1 for r in results if not r.ok)
    sys.stderr.write(
        f"\nDone. {n_ok} ok, {n_fail} failed. "
        f"Total time: {(time.time() - start_t)/60:.1f} min.\n"
    )
    sys.stderr.write(f"Log: {log_path}\n")
    return n_ok, n_fail


def _save_log(path: Path, results: list[OpResult], *, started_at: float) -> None:
    data = {
        "started_at_unix": started_at,
        "started_at_iso": datetime.fromtimestamp(started_at).isoformat(),
        "completed_at_iso": datetime.now().isoformat(),
        "n_ok": sum(1 for r in results if r.ok),
        "n_fail": sum(1 for r in results if not r.ok),
        "results": [asdict(r) for r in results],
    }
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


# ============================================================================
# Self-test
# ============================================================================


def self_test() -> int:
    """Validate ALIASES_TABLET_TO_PC against the live PC library + tablet."""
    fails = 0
    pc = scan_pc()
    pc_folder_set = {s.folder_name for s in pc}

    print("ALIAS_PC_TARGETS exist in PC library:")
    for tab_name, pc_name in ALIASES_TABLET_TO_PC.items():
        ok = pc_name in pc_folder_set
        marker = "PASS" if ok else "FAIL"
        print(f"  [{marker}] {tab_name!r} -> {pc_name!r}")
        if not ok:
            fails += 1

    print(f"\n{fails} failure(s).")
    return 0 if fails == 0 else 1


# ============================================================================
# CLI
# ============================================================================


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="push_all_to_tablet",
        description="Mirror PC manga library to USB-attached tablet via adb.",
    )
    p.add_argument("--plan", action="store_true", help="Print plan and exit (default).")
    p.add_argument("--apply", action="store_true",
                   help="Execute the plan after confirmation.")
    p.add_argument("--yes", "-y", action="store_true",
                   help="Skip apply confirmation prompt.")
    p.add_argument("--only", action="append", default=[],
                   metavar="PC_FOLDER",
                   help="Only push series whose canonical PC folder name matches. "
                        "Repeatable.")
    p.add_argument("--skip", action="append", default=[],
                   metavar="PC_FOLDER",
                   help="Skip series whose canonical PC folder name matches. "
                        "Repeatable.")
    p.add_argument("--device", default=None,
                   help="adb device serial; defaults to single connected or "
                        f"{cm.DEFAULT_DEVICE_SERIAL!r}.")
    p.add_argument("--log", type=Path, default=None,
                   help=f"Apply-mode log path; default: "
                        f"{SCRIPT_DIR}/transfer-log-<timestamp>.json")
    p.add_argument("--self-test", action="store_true",
                   help="Validate alias table and exit.")
    return p


def main(argv: list[str]) -> int:
    args = build_parser().parse_args(argv)

    if args.self_test:
        return self_test()

    try:
        adb = adb_exe()
    except FileNotFoundError as e:
        sys.stderr.write(f"ERROR: {e}\n")
        return 2
    try:
        device = adb_device(adb, args.device)
    except Exception as e:
        sys.stderr.write(f"ERROR: {e}\n")
        return 2

    if not PC_ROOT.is_dir():
        sys.stderr.write(f"ERROR: PC root not found: {PC_ROOT}\n")
        return 2

    sys.stderr.write(f"adb: {adb}\ndevice: {device}\n")
    sys.stderr.write("Scanning PC library...\n")
    pc = scan_pc()

    sys.stderr.write("Scanning tablet library...\n")
    cache_path = SCRIPT_DIR / ".tablet_cache.json"
    tablet, _scan_anomalies, _cache_status, _n_files = cm.scan_tablet_library(
        adb, device, TABLET_ROOT, cache_path, refresh=True, ttl_hours=0,
    )
    tablet_folders = sorted([t.folder_name for t in tablet], key=str.casefold)
    tablet_by_name = {t.folder_name: t for t in tablet}

    entries, tablet_only, alias_errors = build_plan(pc, tablet_folders)
    fill_tablet_chapter_counts(entries, tablet_by_name)

    # --only / --skip filters
    if args.only:
        keep = set(args.only)
        entries = [e for e in entries if e.pc_canonical_folder in keep]
    if args.skip:
        drop = set(args.skip)
        entries = [e for e in entries if e.pc_canonical_folder not in drop]

    print_plan(entries, tablet_only, alias_errors, pc, tablet_folders, tablet_by_name)

    if alias_errors:
        sys.stderr.write("ERROR: alias errors above; aborting.\n")
        return 1

    if not args.apply:
        return 0

    # Apply mode
    if not args.yes:
        print(
            "\nThis will DELETE the matched tablet folders and PUSH the PC\n"
            "folders to the tablet. Type 'yes' to proceed:"
        )
        resp = input("> ").strip()
        if resp.lower() not in ("yes", "y"):
            print("Aborted.")
            return 3

    log_path = args.log
    if log_path is None:
        ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        log_path = SCRIPT_DIR / f"transfer-log-{ts}.json"

    n_ok, n_fail = apply_plan(entries, adb, device, log_path)
    return 0 if n_fail == 0 else 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

"""
render_seed_links.py — Pretty-print seed_links.json into readable formats.

Reads seed_links.json (written by batch_search.py) and emits:
  - seed_links.md  — Markdown table: folder | top_url | site | score | title
  - seed_links_full.md — same but with up to 5 ranked sources per series, for
                         picking fallbacks by hand if the top one disappoints

Standalone — run any time after batch_search.py has populated some entries
(partial JSON renders cleanly; missing entries show "(not yet searched)").
"""

from __future__ import annotations

import json
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
IN_JSON = SCRIPT_DIR / "seed_links.json"
OUT_TOP = SCRIPT_DIR / "seed_links.md"
OUT_FULL = SCRIPT_DIR / "seed_links_full.md"


def load() -> dict:
    if not IN_JSON.exists():
        raise SystemExit(f"missing {IN_JSON}")
    with open(IN_JSON, "r", encoding="utf-8") as f:
        return json.load(f)


def _series_order(d: dict) -> list[str]:
    """Render in the same order batch_search.py iterates — folder name asc."""
    return sorted(d.keys(), key=str.casefold)


def render_top(d: dict) -> str:
    rows = ["| # | Tablet folder | Best site | Match | Composite | Top URL |",
            "|---|---|---|---|---|---|"]
    for i, folder in enumerate(_series_order(d), 1):
        rec = d[folder]
        if rec.get("error"):
            rows.append(f"| {i} | `{folder}` | ERROR | – | – | {rec['error']} |")
            continue
        cands = rec.get("candidates") or []
        if not cands or not cands[0].get("sources"):
            rows.append(f"| {i} | `{folder}` | (none) | – | – | (no candidates) |")
            continue
        s = cands[0]["sources"][0]
        match = f"{s['title_match']:.2f}"
        comp = f"{s['composite_score']:.3f}"
        rows.append(
            f"| {i} | `{folder}` | {s['site']} | {match} | {comp} | <{s['url']}> |"
        )
    return "# Best seed link per tablet series\n\n" + "\n".join(rows) + "\n"


def render_full(d: dict) -> str:
    chunks = ["# Full seed-link candidates (top 5 sources per series)\n"]
    for i, folder in enumerate(_series_order(d), 1):
        rec = d[folder]
        chunks.append(f"## {i}. `{folder}`")
        chunks.append(f"_search query_: `{rec.get('query', folder)}`  ")
        if rec.get("error"):
            chunks.append(f"**ERROR:** {rec['error']}\n")
            continue
        cands = rec.get("candidates") or []
        if not cands:
            chunks.append("_no candidates_\n")
            continue
        top = cands[0]
        chunks.append(
            f"_top candidate_: **{top['canonical_title']}** "
            f"(year={top.get('canonical_year')}, sources={len(top['sources'])})\n"
        )
        chunks.append("| Rank | Site | Match | Seed | Img | Composite | Chapters | DMCA | URL |")
        chunks.append("|---|---|---|---|---|---|---|---|---|")
        for j, s in enumerate(top["sources"][:5], 1):
            img = (f"{s['img_quality_score']:.2f}"
                   if s.get("img_quality_score") is not None else "–")
            ch = s.get("actual_chapter_count") or s.get("chapter_count_hint") or "–"
            chunks.append(
                f"| {j} | {s['site']} | {s['title_match']:.2f} | "
                f"{s['seed_quality']:.2f} | {img} | "
                f"{s['composite_score']:.3f} | {ch} | "
                f"{'yes' if s['dmca_likely'] else 'no'} | "
                f"<{s['url']}> |"
            )
        chunks.append("")
    return "\n".join(chunks) + "\n"


def main() -> int:
    d = load()
    with open(OUT_TOP, "w", encoding="utf-8") as f:
        f.write(render_top(d))
    with open(OUT_FULL, "w", encoding="utf-8") as f:
        f.write(render_full(d))
    n_ok = sum(1 for r in d.values() if r.get("candidates"))
    n_err = sum(1 for r in d.values() if r.get("error"))
    print(f"{n_ok}/{len(d)} ok, {n_err} errors. Wrote {OUT_TOP.name} and {OUT_FULL.name}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

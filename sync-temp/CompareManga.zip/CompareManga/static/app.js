// app.js — selection state, HTMX glue, and SSE consumer.
// No bundler, no framework. Loaded with `defer` so DOMContentLoaded order is
// natural. Owns: window.MangaSelection (the only global it exports).

(function () {
  "use strict";

  // ---- Selection state ------------------------------------------------------
  // Set of canonical keys "op|series_key|label". Whole-series uses label "*".

  const MangaSelection = (() => {
    const set = new Set();
    const subscribers = new Set();

    function key(op, seriesKey, label) { return op + "|" + seriesKey + "|" + label; }

    function add(op, seriesKey, label) {
      set.add(key(op, seriesKey, label));
      notify();
    }
    function remove(op, seriesKey, label) {
      set.delete(key(op, seriesKey, label));
      notify();
    }
    function has(op, seriesKey, label) {
      return set.has(key(op, seriesKey, label));
    }
    function clear() {
      set.clear();
      // Sync checkboxes in DOM.
      document.querySelectorAll(".sel:checked").forEach((cb) => { cb.checked = false; });
      document.querySelectorAll(".btn--ghost.is-on").forEach((b) => b.classList.remove("is-on"));
      notify();
    }
    function size() { return set.size; }
    function serialize() {
      return Array.from(set).map((k) => {
        const parts = k.split("|");
        return { op: parts[0], series_key: parts[1], label: parts[2] };
      });
    }
    function summarize() {
      let pushes = 0, deletes = 0, wholes = 0;
      for (const k of set) {
        const [op, , label] = k.split("|");
        if (op === "push") pushes++;
        else if (op === "delete") deletes++;
        if (label === "*") wholes++;
      }
      return { pushes, deletes, wholes };
    }
    function subscribe(fn) { subscribers.add(fn); return () => subscribers.delete(fn); }

    function notify() {
      document.body.classList.toggle("has-selection", set.size > 0);
      subscribers.forEach((fn) => { try { fn(set.size); } catch (_) {} });
    }

    function toggleAllInDetail(op) {
      const root = document.getElementById("detail-panel");
      if (!root) return;
      const boxes = Array.from(root.querySelectorAll('.chapter-table .sel[data-op="' + op + '"]'));
      if (!boxes.length) return;
      const allChecked = boxes.every((cb) => cb.checked);
      boxes.forEach((cb) => {
        cb.checked = !allChecked;
        const { op: o, seriesKey, label } = cb.dataset;
        if (cb.checked) add(o, seriesKey, label); else remove(o, seriesKey, label);
      });
    }

    return { add, remove, has, clear, size, serialize, summarize, subscribe, toggleAllInDetail };
  })();
  window.MangaSelection = MangaSelection;

  // ---- Checkbox event delegation -------------------------------------------

  document.body.addEventListener("change", (e) => {
    const cb = e.target.closest && e.target.closest(".sel");
    if (!cb) return;
    const { op, seriesKey, label } = cb.dataset;
    if (!op || !seriesKey || !label) return;
    if (cb.checked) MangaSelection.add(op, seriesKey, label);
    else MangaSelection.remove(op, seriesKey, label);
  });

  // ---- Restore checkbox state after HTMX swaps -----------------------------

  document.body.addEventListener("htmx:afterSettle", () => {
    document.querySelectorAll(".sel").forEach((cb) => {
      const { op, seriesKey, label } = cb.dataset;
      if (!op || !seriesKey || !label) return;
      cb.checked = MangaSelection.has(op, seriesKey, label);
    });
    // Re-bind any progress modals that just landed.
    document.querySelectorAll("[data-transfer-id]").forEach((el) => {
      if (!el.__progressBound) {
        el.__progressBound = true;
        bindProgress(el);
      }
    });
  });

  // ---- Selection counter + hint --------------------------------------------

  MangaSelection.subscribe((n) => {
    const countEl = document.getElementById("selection-count");
    const hintEl = document.getElementById("selection-hint");
    if (countEl) countEl.textContent = String(n);
    if (hintEl) {
      const s = MangaSelection.summarize();
      const parts = [];
      if (s.pushes) parts.push(s.pushes + " push");
      if (s.deletes) parts.push(s.deletes + " delete");
      if (s.wholes) parts.push("(" + s.wholes + " whole-series)");
      hintEl.textContent = parts.join(" · ");
    }
  });

  // ---- Apply button shake (one-shot) ---------------------------------------

  document.body.addEventListener("htmx:beforeRequest", (e) => {
    const btn = e.target && e.target.closest && e.target.closest(".btn--apply");
    if (!btn) return;
    btn.classList.remove("is-working");
    // Force reflow so the keyframe can replay.
    void btn.offsetWidth;
    btn.classList.add("is-working");
  });

  // ---- SSE progress consumer -----------------------------------------------

  function bindProgress(rootEl) {
    const id = rootEl.dataset.transferId;
    const sseUrl = rootEl.dataset.sseUrl;
    if (!id || !sseUrl) return;

    const dom = {
      fileLabel: rootEl.querySelector(".js-file-label"),
      fileBar:   rootEl.querySelector(".js-file-bar"),
      batchBar:  rootEl.querySelector(".js-batch-bar"),
      counter:   rootEl.querySelector(".js-counter"),
      succeeded: rootEl.querySelector(".js-succeeded"),
      failed:    rootEl.querySelector(".js-failed"),
      log:       rootEl.querySelector(".js-log"),
      cancelBtn: rootEl.querySelector(".js-cancel"),
      closeBtn:  rootEl.querySelector(".js-close"),
    };

    let total = 0, doneFiles = 0, succeeded = 0, failed = 0;
    const es = new EventSource(sseUrl);

    function setFileBar(pct) {
      if (dom.fileBar) dom.fileBar.style.setProperty("--pct", pct + "%");
    }
    function setBatchBar() {
      if (dom.counter) dom.counter.textContent = doneFiles + " of " + total;
      if (dom.batchBar && total) {
        dom.batchBar.style.setProperty("--pct", ((doneFiles / total) * 100) + "%");
      }
    }
    function appendLog(prefix, label, extra) {
      if (!dom.log) return;
      const div = document.createElement("div");
      div.className = "log-line" + (extra && extra.failed ? " is-failed" : "");
      const time = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
      div.textContent = "[" + time + "] " + prefix.padEnd(10) + " " + (label || "") + (extra && extra.err ? "  ← " + extra.err : "");
      dom.log.prepend(div);
    }
    function finish(state) {
      es.close();
      rootEl.classList.add("is-finished", "is-" + state);
      if (dom.cancelBtn) dom.cancelBtn.setAttribute("disabled", "");
      if (dom.closeBtn) {
        dom.closeBtn.removeAttribute("disabled");
        dom.closeBtn.addEventListener("click", () => {
          document.getElementById("modal-root").replaceChildren();
        });
      }
      if (state === "done") MangaSelection.clear();
    }

    const handlers = {
      batch_start: (e) => {
        total = e.total_files | 0;
        setBatchBar();
        appendLog("start", "batch · " + total + " files");
      },
      file_start: (e) => {
        if (dom.fileLabel) dom.fileLabel.textContent = (e.op || "?").toUpperCase() + "  " + (e.label || "");
        setFileBar(0);
      },
      file_progress: (e) => setFileBar(e.pct | 0),
      file_done: (e) => {
        doneFiles++;
        if (e.ok) {
          succeeded++;
          if (dom.succeeded) dom.succeeded.textContent = String(succeeded);
          appendLog("ok", e.label);
        } else {
          failed++;
          if (dom.failed) dom.failed.textContent = String(failed);
          appendLog("fail", e.label, { failed: true, err: e.error });
        }
        setBatchBar();
      },
      batch_done: () => finish("done"),
      batch_cancelled: () => { appendLog("cancel", "by user"); finish("cancelled"); },
      batch_aborted_due_to_errors: (e) => {
        appendLog("abort", (e.consecutive_failures || "?") + " consecutive failures");
        finish("aborted");
      },
    };

    es.onmessage = (msg) => {
      let evt;
      try { evt = JSON.parse(msg.data); } catch (_) { return; }
      const h = handlers[evt.type];
      if (h) h(evt);
    };
    es.onerror = () => {
      // Browser will reconnect automatically until close() is called.
      // After terminal events we have already closed via finish().
    };
  }

  // ---- Esc to close modal ---------------------------------------------------

  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    const root = document.getElementById("modal-root");
    if (!root || !root.firstChild) return;
    // Don't close the progress modal mid-transfer.
    if (root.querySelector(".progress-card") && !root.querySelector(".progress-card.is-finished")) return;
    root.replaceChildren();
  });
})();

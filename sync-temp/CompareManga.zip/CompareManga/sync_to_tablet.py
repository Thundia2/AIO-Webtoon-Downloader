"""
sync_to_tablet.py — File-level, content-hash, resumable PC -> tablet mirror.

Owns the incremental sync of the PC manga library (D:\\AIO\\manga) onto the
USB-attached Android tablet. Unlike push_all_to_tablet.py (which wipes and
re-pushes whole series folders every run), this tool diffs PC vs tablet at the
*individual file* level using SHA-256 content hashes, so it:

  * pushes only files that are new or whose CONTENT changed (mtime is ignored
    entirely — see below), and deletes files removed from the PC;
  * is perfectly resumable: a persistent per-file record (.sync_state-<dev>.json)
    is flushed atomically after every push/delete batch, so a kill mid-run
    (USB flicker, reboot) resumes exactly where it stopped with zero re-push of
    already-confirmed files.

Why content hash, not mtime/size: `adb push` does NOT preserve source mtime
(tablet mtimes are push-time), and the AIO metadata pipeline can change a
CBZ's embedded ComicInfo.xml (or cover.jpg / details.json) WITHOUT bumping the
mtime the user sees. So the only faithful "did this change?" signal is the
bytes. We re-hash the whole PC library each run (cheap on the NVMe D: drive)
and compare against a record of what we last pushed. See the design notes in
build_plan().

Change-detection layers (default, no --verify):
  desired_file_ok  ==  tablet has it at the right SIZE (fresh cheap `find`)
                       AND our record's hash == the PC file's fresh hash
  --verify upgrades the tablet side from "size only" to a full `adb shell
  sha256sum` of every tablet file, rebuilding the record from ground truth
  (use it on the FIRST run to adopt already-present files, and periodically to
  catch tablet-side corruption / manual edits).
  --fast trusts a (size,mtime) PC hash cache instead of re-hashing the PC.

Naming / matching policy is inherited verbatim from push_all_to_tablet.py:
  aliased series keep their readable tablet name (SPY×FAMILY -> SPY_x_FAMILY,
  Code Breaker -> CØDEBREAKER, ...); everything else uses the PC folder name
  with any "(hid=...)" suffix stripped and sanitized. Unmatched tablet folders
  (no PC source, e.g. a side-loaded series) are PRESERVED, never touched.

Reads:
  - PC root:     compare_manga.DEFAULT_PC_ROOT
  - Tablet root: compare_manga.DEFAULT_TABLET_ROOT  (/storage/self/primary/Documents)
  - adb:         compare_manga.resolve_adb / resolve_device
  - Aliases:     push_all_to_tablet.ALIASES_TABLET_TO_PC (single source of truth)

Writes:
  - .sync_state-<device>.json  — record of what is (believed) on the tablet
  - .pc_hash_cache.json        — (path,size,mtime) -> sha256, for --fast
  - sync-log-<timestamp>.json  — per-run apply results

Depends on: compare_manga (scan/adb/normalize), push_all_to_tablet (aliases +
adb push/shell/mkdir helpers), manga_ops (sanitize + path validation).
grep sync_to_tablet for callers; this module has no importers (CLI entry only).

Python 3.10+.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
import shlex
import sys
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path

# Same-directory siblings; ensure importable when run as a script.
sys.path.insert(0, str(Path(__file__).resolve().parent))
import compare_manga as cm  # noqa: E402
import push_all_to_tablet as pat  # noqa: E402
from manga_ops import (  # noqa: E402
    sanitize_tablet_segment,
    _validate_tablet_path,
    TransferError,
)


# ============================================================================
# Constants
# ============================================================================

PC_ROOT: Path = cm.DEFAULT_PC_ROOT
TABLET_ROOT: str = cm.DEFAULT_TABLET_ROOT.rstrip("/")
SCRIPT_DIR: Path = Path(__file__).resolve().parent

STATE_VERSION = 1

# Dot-sidecars AIO writes next to chapters that must NOT be mirrored. We never
# put them in the push list (so, unlike the old tool, there is nothing to strip
# afterward), and we exclude them from tablet hash scans. Anything beginning
# with "." is skipped regardless; this tuple is the explicit cleanup set for
# folders that already contain them (e.g. the raw-pushed 'Tis Time test).
SIDECARS = (".aio_series.json", ".mangafire_hid", ".series_hid", ".cover.webp")

# The only non-chapter files we DO mirror (Komikku reads them at the series
# root). Everything else that isn't a .cbz is ignored.
COVER_NAME = "cover.jpg"
DETAILS_NAME = "details.json"

# PC folder name -> preferred tablet folder name. Inverse of the tablet->PC
# alias table in push_all_to_tablet (that one is keyed by the tablet name
# because the old tool matched an existing tablet folder; on a fresh tablet we
# go PC -> tablet, so we invert). grep ALIASES_TABLET_TO_PC for the source.
PC_TO_TABLET_ALIAS: dict[str, str] = {
    pc: tab for tab, pc in pat.ALIASES_TABLET_TO_PC.items()
}

# Push batching: multiple local files go into ONE `adb push f1 f2 ... dest/`
# call to amortize the per-invocation adb roundtrip over a whole series instead
# of paying it per chapter. Capped by file count AND cumulative arg length so
# the Windows CreateProcess 32 KB command-line limit is never hit.
MAX_BATCH_FILES = 50
MAX_BATCH_ARGLEN = 12000


# ============================================================================
# Dataclasses
# ============================================================================


@dataclass
class PCFile:
    """One mirrorable file inside a PC series folder."""
    rel: str            # bare filename, e.g. "Ch.001 - Torture 1.cbz" / "cover.jpg"
    abs_path: Path
    size: int
    mtime: float
    sha256: str = ""    # filled by hash_pc_files()


@dataclass
class SeriesPlan:
    """Per-series diff: what to push, what to delete on the tablet."""
    pc_folder: str            # raw PC folder name (may carry "(hid=...)")
    pc_path: Path
    target: str               # tablet folder basename (alias / hid-stripped / sanitized)
    tablet_dir: str           # absolute tablet path of the folder
    pc_files: list[PCFile]
    to_push: list[PCFile] = field(default_factory=list)
    to_delete: list[str] = field(default_factory=list)   # tablet-rel filenames
    is_new_folder: bool = False

    @property
    def push_bytes(self) -> int:
        return sum(f.size for f in self.to_push)


@dataclass
class SeriesResult:
    target: str
    pushed_files: int = 0
    pushed_bytes: int = 0
    deleted_files: int = 0
    duration_sec: float = 0.0
    ok: bool = False
    error: str | None = None


# ============================================================================
# PC scan
# ============================================================================


def is_content_file(name: str) -> bool:
    """True if `name` is a file we mirror (a chapter, the cover, or details)."""
    if name.startswith("."):
        return False
    low = name.lower()
    return low.endswith(".cbz") or name == COVER_NAME or name == DETAILS_NAME


def scan_pc(pc_root: Path) -> list[tuple[str, Path, list[PCFile]]]:
    """Enumerate (folder_name, folder_path, content_files) for each PC series.

    Content files are unsorted here (hashing reorders by size anyway); each has
    size+mtime from a single stat, sha256 left blank for hash_pc_files().
    """
    if not pc_root.is_dir():
        raise FileNotFoundError(f"PC root not found: {pc_root}")
    out: list[tuple[str, Path, list[PCFile]]] = []
    with os.scandir(pc_root) as it:
        for entry in it:
            if entry.name.startswith(".") or entry.name in cm.IGNORE_TOP_LEVEL:
                continue
            try:
                if not entry.is_dir():
                    continue
            except OSError:
                continue
            files: list[PCFile] = []
            try:
                with os.scandir(entry.path) as sit:
                    for e in sit:
                        if not is_content_file(e.name):
                            continue
                        try:
                            if not e.is_file():
                                continue
                            st = e.stat()
                        except OSError:
                            continue
                        files.append(PCFile(
                            rel=e.name,
                            abs_path=Path(e.path),
                            size=st.st_size,
                            mtime=st.st_mtime,
                        ))
            except OSError:
                pass
            out.append((entry.name, Path(entry.path), files))
    out.sort(key=lambda t: t[0].casefold())
    return out


def resolve_target_name(pc_folder: str) -> str:
    """PC folder name -> tablet folder basename, per the inherited naming policy.

    Aliased series keep their readable tablet name; others drop the "(hid=...)"
    suffix. Both paths run through sanitize_tablet_segment so the result is a
    safe single path component. Mirrors push_all_to_tablet.build_plan's choice.
    """
    if pat.KEEP_TABLET_NAME_FOR_ALIASES and pc_folder in PC_TO_TABLET_ALIAS:
        return sanitize_tablet_segment(PC_TO_TABLET_ALIAS[pc_folder])
    return sanitize_tablet_segment(pat._strip_hid(pc_folder))


# ============================================================================
# Hashing (PC side)
# ============================================================================


def sha256_file(path: Path, _buf: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(_buf), b""):
            h.update(chunk)
    return h.hexdigest()


def load_pc_cache(path: Path) -> dict[str, dict]:
    if not path.is_file():
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("entries", {}) if isinstance(data, dict) else {}
    except (json.JSONDecodeError, OSError, UnicodeDecodeError):
        return {}


def save_pc_cache(path: Path, entries: dict[str, dict]) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"entries": entries}, f, ensure_ascii=False)
    os.replace(tmp, path)


def hash_pc_files(
    series: list[tuple[str, Path, list[PCFile]]],
    *,
    use_cache: bool,
    cache: dict[str, dict],
    workers: int,
    progress: bool,
) -> tuple[int, int, int]:
    """Fill .sha256 on every PCFile. Returns (n_hashed, n_cached, bytes_hashed).

    Default (use_cache=False) re-hashes everything — the honest answer to "did
    the content change?" even when size+mtime are unchanged. --fast passes
    use_cache=True and trusts a (size,mtime)-keyed cache to skip unchanged
    files. The cache is ALWAYS updated (so a later --fast run is warm) whether
    or not it was consulted for reads.
    """
    all_files = [f for _, _, fs in series for f in fs]
    to_hash: list[PCFile] = []
    n_cached = 0
    for f in all_files:
        key = str(f.abs_path)
        if use_cache:
            c = cache.get(key)
            if c and c.get("size") == f.size and c.get("mtime") == f.mtime and c.get("sha256"):
                f.sha256 = c["sha256"]
                n_cached += 1
                continue
        to_hash.append(f)

    total_bytes = sum(f.size for f in to_hash)
    done_bytes = 0
    done_n = 0
    t0 = time.time()

    def _work(pf: PCFile) -> tuple[PCFile, str]:
        return pf, sha256_file(pf.abs_path)

    if to_hash:
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
            for pf, digest in ex.map(_work, to_hash):
                pf.sha256 = digest
                cache[str(pf.abs_path)] = {
                    "size": pf.size, "mtime": pf.mtime, "sha256": digest,
                }
                done_bytes += pf.size
                done_n += 1
                if progress and (done_n % 200 == 0 or done_n == len(to_hash)):
                    el = time.time() - t0
                    rate = (done_bytes / el / 1e6) if el > 0 else 0
                    pct = (done_bytes / total_bytes * 100) if total_bytes else 100
                    sys.stderr.write(
                        f"\r  hashing PC: {done_n}/{len(to_hash)} files "
                        f"{done_bytes/1e9:.1f}/{total_bytes/1e9:.1f} GB "
                        f"({pct:4.1f}%, {rate:.0f} MB/s)   "
                    )
                    sys.stderr.flush()
    if progress and to_hash:
        sys.stderr.write("\n")
    return len(to_hash), n_cached, done_bytes


# ============================================================================
# adb helpers (tablet side)
# ============================================================================


def tablet_join(*parts: str) -> str:
    return "/".join([TABLET_ROOT] + [p.strip("/") for p in parts])


def list_tablet_state(adb: str, device: str) -> tuple[dict[str, int], set[str]]:
    """Cheap one-roundtrip enumeration of the tablet.

    Returns (files, dirs): files maps tablet-relative path -> size (dot-files
    excluded); dirs is the set of top-level series folder names. Reuses
    compare_manga._run_adb_find (bulk `find -printf`, with a stat fallback).
    """
    entries, dpaths, _dur, _fallback = cm._run_adb_find(adb, device, TABLET_ROOT)
    root_norm = TABLET_ROOT + "/"
    files: dict[str, int] = {}
    for size, _mtime, path in entries:
        if not path.startswith(root_norm):
            continue
        rel = path[len(root_norm):]
        base = os.path.basename(rel)
        if not rel or base.startswith("."):
            continue
        files[rel] = size
    dirs: set[str] = set()
    for dpath in dpaths:
        if not dpath.startswith(root_norm):
            continue
        folder = dpath[len(root_norm):].rstrip("/")
        if folder and "/" not in folder:
            dirs.add(folder)
    return files, dirs


def hash_tablet_folder(adb: str, device: str, folder: str) -> dict[str, str]:
    """`adb shell sha256sum` every non-dot file under one tablet series folder.

    Returns tablet-relative-path -> sha256 hex. Used only by --verify. Runs one
    shell per folder (bounded output, per-series progress) rather than one giant
    call over the whole tree.
    """
    path = tablet_join(folder)
    _validate_tablet_path(path, TABLET_ROOT)
    remote = (
        f'find {shlex.quote(path)} -type f ! -name ".*" '
        f'-exec sha256sum {{}} + 2>/dev/null'
    )
    rc, out, err = pat.adb_shell(adb, device, remote, timeout=7200)
    result: dict[str, str] = {}
    root_norm = TABLET_ROOT + "/"
    for line in out.splitlines():
        if len(line) < 68 or line[64:66] != "  ":
            continue
        digest = line[:64]
        apath = line[66:]
        if not apath.startswith(root_norm):
            continue
        rel = apath[len(root_norm):]
        if os.path.basename(rel).startswith("."):
            continue
        result[rel] = digest
    return result


def mkdir_p(adb: str, device: str, path: str) -> None:
    pat.adb_mkdir_p(adb, device, path)  # validates + mkdir -p (UTF-8 safe via shell)


def rm_files(adb: str, device: str, paths: list[str]) -> None:
    """rm -f a batch of individual tablet files. Never -rf; files only."""
    if not paths:
        return
    for p in paths:
        _validate_tablet_path(p, TABLET_ROOT)
    quoted = " ".join(shlex.quote(p) for p in paths)
    rc, out, err = pat.adb_shell(adb, device, f"rm -f {quoted}", timeout=120)
    if rc != 0:
        raise RuntimeError(f"rm -f failed rc={rc}: {err.strip()[:200]}")


def rm_rf_dir(adb: str, device: str, path: str) -> None:
    _validate_tablet_path(path, TABLET_ROOT)
    rc, out, err = pat.adb_shell(adb, device, f"rm -rf {shlex.quote(path)}", timeout=600)
    if rc != 0:
        raise RuntimeError(f"rm -rf failed for {path!r}: rc={rc} {err.strip()[:200]}")


def _is_ascii(s: str) -> bool:
    return all(ord(c) < 128 for c in s)


def push_batch(adb: str, device: str, files: list[PCFile], dest_dir: str) -> None:
    """`adb push f1 f2 ... dest_dir/` — many files with an ALL-ASCII source path.

    dest_dir MUST already exist (mkdir_p first) so adb never has to CREATE the
    destination folder. CRITICAL: adb push (36.x, Windows) truncates the leaf it
    writes by the SOURCE path's (utf-8 bytes − char count) — it bites the
    destination FOLDER basename (the known bug in
    push_all_to_tablet.adb_landed_basename) and the pushed FILE leaf, and the
    source that drives it can be a non-ASCII filename OR a non-ASCII parent
    folder ("SPY×FAMILY\\Ch.001 - Mission 1.cbz" -> "…Mission 1.cb"). So callers
    must send only all-ASCII-source-path files here and route the rest through
    push_explicit(). Verified live via the scratch probe.
    """
    if not files:
        return
    _validate_tablet_path(dest_dir.rstrip("/") + "/__probe__", TABLET_ROOT)
    dest = dest_dir.rstrip("/") + "/"
    args = ["push"] + [str(f.abs_path) for f in files] + [dest]
    total = sum(f.size for f in files)
    # Pessimistic USB-2 floor of ~4 MB/s for the timeout, plus generous slack.
    timeout = max(180.0, total / 4_000_000 + 120.0)
    rc, out, _err = pat._adb_run(adb, device, args, timeout=timeout, stream_output=True)
    if rc != 0:
        raise RuntimeError(f"adb push exited rc={rc}; tail:\n{out[-800:]}")


def push_explicit(adb: str, device: str, f: PCFile, dest_dir: str) -> None:
    """Push ONE file to an explicit remote path `dest_dir/<f.rel>` (no trailing
    slash), which preserves a non-ASCII leaf name verbatim.

    When the remote target is given as a full path rather than a directory, adb
    writes those exact bytes as the filename instead of recomputing (and
    truncating) the leaf from the source basename. This is the fix for the ~203
    non-ASCII chapter filenames in the library; proven by the write-probe
    ("EXPLICIT_…Jötunn's ñ.cbz" landed intact). One adb call per such file — a
    negligible tail relative to the ~20k ASCII files that batch.
    """
    dest_path = dest_dir.rstrip("/") + "/" + f.rel
    _validate_tablet_path(dest_path, TABLET_ROOT)
    timeout = max(180.0, f.size / 4_000_000 + 120.0)
    rc, out, _err = pat._adb_run(
        adb, device, ["push", str(f.abs_path), dest_path],
        timeout=timeout, stream_output=True,
    )
    if rc != 0:
        raise RuntimeError(f"adb push (explicit) exited rc={rc}; tail:\n{out[-800:]}")


def _chunk_files(files: list[PCFile]) -> list[list[PCFile]]:
    """Split a series' push list into batches under the count/arg-length caps."""
    batches: list[list[PCFile]] = []
    cur: list[PCFile] = []
    cur_len = 0
    for f in files:
        add = len(str(f.abs_path)) + 1
        if cur and (len(cur) >= MAX_BATCH_FILES or cur_len + add > MAX_BATCH_ARGLEN):
            batches.append(cur)
            cur, cur_len = [], 0
        cur.append(f)
        cur_len += add
    if cur:
        batches.append(cur)
    return batches


# ============================================================================
# State record (the resume journal + incremental baseline)
# ============================================================================


def state_path_for(device: str) -> Path:
    return SCRIPT_DIR / f".sync_state-{device}.json"


def load_state(path: Path, device: str) -> dict:
    if not path.is_file():
        return {"version": STATE_VERSION, "device": device,
                "tablet_root": TABLET_ROOT, "files": {}}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError, UnicodeDecodeError):
        return {"version": STATE_VERSION, "device": device,
                "tablet_root": TABLET_ROOT, "files": {}}
    if not isinstance(data, dict) or "files" not in data:
        data = {"version": STATE_VERSION, "device": device,
                "tablet_root": TABLET_ROOT, "files": {}}
    data.setdefault("files", {})
    return data


def save_state(path: Path, state: dict) -> None:
    state["updated_at_iso"] = datetime.now().isoformat()
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False)
    os.replace(tmp, path)


# ============================================================================
# Plan
# ============================================================================


def build_plan(
    pc_series: list[tuple[str, Path, list[PCFile]]],
    tablet_files: dict[str, int],
    tablet_dirs: set[str],
    state: dict,
    *,
    only: set[str],
    skip: set[str],
) -> tuple[list[SeriesPlan], list[str], list[str], list[str]]:
    """Diff PC (hashed) vs tablet (sizes) + our record.

    Returns (plans, preserved, orphaned, warnings):
      plans      — per-series push/delete lists (only series with work OR new).
      preserved  — live tablet folders with no PC source and no record (kept).
      orphaned   — folders in the record/tablet whose PC series is GONE
                   (candidates for --prune; never auto-deleted).
      warnings   — target-name collisions and other oddities.

    A desired file is considered already-good on the tablet iff the tablet has
    it at the matching SIZE *and* our record's stored hash equals the PC file's
    freshly computed hash. Without --verify the record is trusted for the tablet
    hash; with --verify the record was just rebuilt from real tablet hashes, so
    the same comparison becomes ground truth. This is the whole change-detection
    contract — mtime never enters into it.
    """
    warnings: list[str] = []
    rec: dict[str, dict] = state["files"]

    # Resolve target names and detect collisions (two PC folders -> one tablet
    # folder). None exist in the current library, but a future duplicate hid
    # variant would; keep the one with more content and warn about the rest.
    by_target: dict[str, tuple[str, Path, list[PCFile]]] = {}
    for folder, path, files in pc_series:
        if only and folder not in only:
            continue
        if folder in skip:
            continue
        if not files:
            warnings.append(f"empty PC folder skipped (no content files): {folder!r}")
            continue
        target = resolve_target_name(folder)
        prev = by_target.get(target)
        if prev is None or len(files) > len(prev[2]):
            if prev is not None:
                warnings.append(
                    f"target collision {target!r}: {folder!r} vs {prev[0]!r}; "
                    f"keeping the larger ({folder if len(files) > len(prev[2]) else prev[0]!r})"
                )
            by_target[target] = (folder, path, files)
        else:
            warnings.append(
                f"target collision {target!r}: {folder!r} vs {prev[0]!r}; keeping {prev[0]!r}"
            )

    plans: list[SeriesPlan] = []

    for target, (folder, path, files) in sorted(by_target.items(), key=lambda kv: kv[0].casefold()):
        tablet_dir = tablet_join(target)
        is_new = target not in tablet_dirs
        sp = SeriesPlan(
            pc_folder=folder, pc_path=path, target=target,
            tablet_dir=tablet_dir, pc_files=files, is_new_folder=is_new,
        )
        desired_names = {f.rel for f in files}

        for f in files:
            key = f"{target}/{f.rel}"
            tb_size = tablet_files.get(key)
            r = rec.get(key)
            good = (
                tb_size == f.size
                and r is not None
                and r.get("sha256") == f.sha256
            )
            if not good:
                sp.to_push.append(f)

        # Deletions: files the record OR the live tablet has under THIS managed
        # folder that the PC no longer lists (removed / renamed chapters).
        seen_del: set[str] = set()
        for key in list(rec.keys()):
            if key.startswith(target + "/"):
                name = key[len(target) + 1:]
                if "/" not in name and name not in desired_names and name not in seen_del:
                    sp.to_delete.append(name)
                    seen_del.add(name)
        for key in tablet_files:
            if key.startswith(target + "/"):
                name = key[len(target) + 1:]
                if "/" not in name and name not in desired_names and name not in seen_del:
                    sp.to_delete.append(name)
                    seen_del.add(name)

        if sp.to_push or sp.to_delete or is_new:
            plans.append(sp)

    # Orphaned vs preserved — the distinction is RECORD MEMBERSHIP:
    #   orphaned  = a folder we once pushed (in the record) whose PC series is
    #               now gone. Never auto-deleted; surfaced for --prune.
    #   preserved = a live tablet folder we never recorded and that has no PC
    #               target — side-loaded content, left untouched (user policy).
    # This is why --verify must NOT record non-managed folders (see
    # verify_rebuild_state): doing so would turn side-loaded content into a
    # prune candidate.
    all_targets_full = {resolve_target_name(folder) for folder, _p, _f in pc_series}
    recorded_targets = {k.split("/", 1)[0] for k in rec.keys()}
    orphaned = sorted(t for t in recorded_targets if t not in all_targets_full)

    # Preserved: live tablet folders with neither a current PC target nor a
    # record entry — side-loaded content we must not touch (user policy).
    preserved = sorted(
        d for d in tablet_dirs
        if d not in all_targets_full and d not in recorded_targets
    )

    return plans, preserved, orphaned, warnings


# ============================================================================
# Plan rendering
# ============================================================================


def _fmt_bytes(n: int | float) -> str:
    f = float(n)
    for unit in ("B", "KB", "MB", "GB"):
        if f < 1024 or unit == "GB":
            return f"{f:.1f}{unit}"
        f /= 1024
    return f"{f:.1f}TB"


def print_plan(
    plans: list[SeriesPlan],
    preserved: list[str],
    orphaned: list[str],
    warnings: list[str],
    *,
    n_pc: int,
    n_tablet_dirs: int,
    verify: bool,
    state_seeded: bool,
) -> None:
    push_files = sum(len(p.to_push) for p in plans)
    push_bytes = sum(p.push_bytes for p in plans)
    del_files = sum(len(p.to_delete) for p in plans)
    n_new = sum(1 for p in plans if p.is_new_folder)
    n_changed = sum(1 for p in plans if not p.is_new_folder and (p.to_push or p.to_delete))

    print()
    print("=" * 92)
    print(f"  SYNC PLAN — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
          + ("   [--verify: tablet re-hashed]" if verify else ""))
    print("=" * 92)
    print(f"  PC root:        {PC_ROOT}")
    print(f"  Tablet root:    {TABLET_ROOT}")
    print(f"  PC series:      {n_pc}      Tablet folders: {n_tablet_dirs}")
    print()
    print("  SUMMARY")
    print(f"    Series with changes:     {len(plans)}  "
          f"({n_new} new folder(s), {n_changed} updated)")
    print(f"    Files to push:           {push_files}  ({_fmt_bytes(push_bytes)})")
    print(f"    Files to delete:         {del_files}")
    print(f"    Folders preserved:       {len(preserved)}  (no PC source, untouched)")
    if orphaned:
        print(f"    Folders orphaned:        {len(orphaned)}  (PC series gone; --prune to remove)")
    print()

    if warnings:
        print("  WARNINGS")
        for w in warnings:
            print(f"    ! {w}")
        print()

    if not plans:
        print("  Nothing to do — tablet already matches the PC library.")
    else:
        print("  OPERATIONS (sorted by tablet folder)")
        hdr = f"    {'tablet folder':<52}  {'push':>5}  {'GB':>6}  {'del':>4}  note"
        print(hdr)
        print("    " + "-" * (len(hdr) - 4))
        for p in plans:
            name = p.target if len(p.target) <= 50 else p.target[:47] + "..."
            note = "NEW" if p.is_new_folder else ""
            gb = p.push_bytes / 1024 / 1024 / 1024
            print(f"    {name:<52}  {len(p.to_push):>5}  {gb:>6.2f}  "
                  f"{len(p.to_delete):>4}  {note}")
        print()

    if orphaned:
        print(f"  ORPHANED (in record, PC series gone) — {len(orphaned)}")
        for t in orphaned:
            print(f"    ? {t}")
        print()

    if preserved:
        print(f"  PRESERVED (untouched) — {len(preserved)}")
        for t in preserved:
            print(f"    = {t}")
        print()

    if not state_seeded and not verify:
        print("  NOTE: no prior record for this device. The first run should use")
        print("        --verify so already-present tablet files are adopted from")
        print("        their real hashes instead of being re-pushed.")
        print()


# ============================================================================
# Verify / seed
# ============================================================================


def verify_rebuild_state(
    adb: str, device: str, state: dict,
    tablet_files: dict[str, int], tablet_dirs: set[str],
    managed: set[str], state_path: Path,
) -> None:
    """Re-hash MANAGED tablet folders and refresh their record from ground truth.

    Only folders that match a current PC target are scanned. This:
      * adopts already-correct files so the first run doesn't re-push them;
      * detects corruption / partial pushes / manual edits in what we manage;
      * seeds the record for a brand-new device;
    while deliberately NOT touching side-loaded folders (no PC target) — their
    absence from the record is exactly what keeps them "preserved" rather than
    "orphaned" in build_plan(). Existing record entries for folders we don't
    re-scan (e.g. a series removed from the PC) are kept, so --prune still sees
    them. Each folder's entries are cleared then rewritten, and the record is
    flushed per folder so a killed verify keeps the folders it finished.
    """
    rec: dict[str, dict] = state["files"]
    dirs = sorted(tablet_dirs & managed, key=str.casefold)
    sys.stderr.write(f"Verifying (hashing) {len(dirs)} managed tablet folder(s)...\n")
    for i, folder in enumerate(dirs, 1):
        sys.stderr.write(f"\r  [{i}/{len(dirs)}] {folder[:60]:<60}")
        sys.stderr.flush()
        try:
            hashes = hash_tablet_folder(adb, device, folder)
        except Exception as ex:
            sys.stderr.write(f"\n  ! hash failed for {folder!r}: {ex}\n")
            continue
        for k in [k for k in rec if k.split("/", 1)[0] == folder]:
            rec.pop(k, None)
        for rel, digest in hashes.items():
            rec[rel] = {"size": tablet_files.get(rel, 0), "sha256": digest}
        save_state(state_path, state)
    sys.stderr.write("\n")


# ============================================================================
# Apply
# ============================================================================


def apply_plan(
    plans: list[SeriesPlan],
    adb: str,
    device: str,
    state: dict,
    state_path: Path,
    log_path: Path,
) -> tuple[int, int]:
    """Execute the plan. Returns (n_ok, n_fail).

    Per series: mkdir -p the target, strip any stray sidecars, delete removed
    chapters, then push changed/new files in batches. The record is flushed
    after every delete batch and every push batch — that atomic, incremental
    flush is exactly what makes an interrupted run resume cleanly.
    """
    results: list[SeriesResult] = []
    rec: dict[str, dict] = state["files"]
    t_start = time.time()
    total_push_bytes = sum(p.push_bytes for p in plans)
    pushed_bytes_so_far = 0

    for i, p in enumerate(plans, 1):
        r = SeriesResult(target=p.target)
        op_start = time.time()
        sys.stderr.write(
            f"\n[{i}/{len(plans)}] {p.target}  "
            f"(+{len(p.to_push)} files {_fmt_bytes(p.push_bytes)}, -{len(p.to_delete)})\n"
        )
        try:
            mkdir_p(adb, device, p.tablet_dir)

            # Best-effort sidecar cleanup (parity with the old tool; harmless if
            # absent — e.g. the raw-pushed 'Tis Time carried them).
            sidecar_paths = [tablet_join(p.target, s) for s in SIDECARS]
            try:
                rm_files(adb, device, sidecar_paths)
            except Exception:
                pass

            # Deletes first (frees space before the push).
            if p.to_delete:
                del_paths = [tablet_join(p.target, name) for name in p.to_delete]
                rm_files(adb, device, del_paths)
                for name in p.to_delete:
                    rec.pop(f"{p.target}/{name}", None)
                r.deleted_files = len(p.to_delete)
                save_state(state_path, state)

            # Pushes: files with a fully-ASCII SOURCE PATH batch efficiently
            # into the dir; anything with a non-ASCII byte in its source path
            # goes one-at-a-time via explicit dest. adb truncates the dest leaf
            # by the source path's (bytes - chars), so this bites BOTH non-ASCII
            # filenames AND ASCII files sitting in a non-ASCII SERIES FOLDER
            # (e.g. SPY×FAMILY\Ch.001 - Mission 1.cbz -> tablet "…Mission 1.cb").
            # Keying on the whole source path covers both. Confirmed live via the
            # scratch probe; see [[bug-adb-push-utf8-truncation]]. Record + flush
            # after every batch/file so an interrupted run resumes cleanly.
            ascii_files = [f for f in p.to_push if _is_ascii(str(f.abs_path))]
            unicode_files = [f for f in p.to_push if not _is_ascii(str(f.abs_path))]

            def _record(fs: list[PCFile]) -> None:
                nonlocal pushed_bytes_so_far
                for f in fs:
                    rec[f"{p.target}/{f.rel}"] = {"size": f.size, "sha256": f.sha256}
                    r.pushed_files += 1
                    r.pushed_bytes += f.size
                    pushed_bytes_so_far += f.size
                save_state(state_path, state)
                if total_push_bytes:
                    pct = pushed_bytes_so_far / total_push_bytes * 100
                    sys.stderr.write(
                        f"  … {pushed_bytes_so_far/1e9:.1f}/{total_push_bytes/1e9:.1f} GB "
                        f"({pct:.1f}% of run)\n"
                    )

            for batch in _chunk_files(ascii_files):
                push_batch(adb, device, batch, p.tablet_dir)
                _record(batch)
            for f in unicode_files:
                push_explicit(adb, device, f, p.tablet_dir)
                _record([f])
            r.ok = True
        except Exception as ex:
            r.ok = False
            r.error = f"{type(ex).__name__}: {ex}"
            sys.stderr.write(f"  !! ERROR: {r.error}\n")
        finally:
            r.duration_sec = round(time.time() - op_start, 2)
            results.append(r)
            _save_log(log_path, results, started_at=t_start)

    n_ok = sum(1 for r in results if r.ok)
    n_fail = sum(1 for r in results if not r.ok)
    sys.stderr.write(
        f"\nDone. {n_ok} ok, {n_fail} failed. "
        f"Total: {(time.time()-t_start)/60:.1f} min. Log: {log_path}\n"
    )
    return n_ok, n_fail


def prune_orphans(adb: str, device: str, orphaned: list[str], state: dict, state_path: Path) -> None:
    rec: dict[str, dict] = state["files"]
    for t in orphaned:
        path = tablet_join(t)
        sys.stderr.write(f"  prune rm -rf {path}\n")
        try:
            rm_rf_dir(adb, device, path)
            for key in [k for k in rec if k.split("/", 1)[0] == t]:
                rec.pop(key, None)
            save_state(state_path, state)
        except Exception as ex:
            sys.stderr.write(f"  !! prune failed for {t!r}: {ex}\n")


def _save_log(path: Path, results: list[SeriesResult], *, started_at: float) -> None:
    data = {
        "started_at_iso": datetime.fromtimestamp(started_at).isoformat(),
        "completed_at_iso": datetime.now().isoformat(),
        "n_ok": sum(1 for r in results if r.ok),
        "n_fail": sum(1 for r in results if not r.ok),
        "pushed_files": sum(r.pushed_files for r in results),
        "pushed_bytes": sum(r.pushed_bytes for r in results),
        "deleted_files": sum(r.deleted_files for r in results),
        "results": [asdict(r) for r in results],
    }
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


# ============================================================================
# Self-test (pure functions; no device)
# ============================================================================


def run_self_test() -> int:
    fails = 0

    def expect(label, got, want):
        nonlocal fails
        ok = got == want
        print(f"  [{'PASS' if ok else 'FAIL'}] {label}")
        if not ok:
            print(f"         got={got!r}\n        want={want!r}")
            fails += 1

    print("resolve_target_name (alias / hid / plain):")
    expect("SPY×FAMILY -> alias", resolve_target_name("SPY×FAMILY"), "SPY_x_FAMILY")
    expect("Code Breaker -> alias", resolve_target_name("Code Breaker"), "CØDEBREAKER")
    expect("Isekai Shikkaku -> alias", resolve_target_name("Isekai Shikkaku"),
           "No Longer Allowed In Another World")
    expect("hid stripped", resolve_target_name("Bungo Stray Dogs (hid=PW1SJ)"),
           "Bungo Stray Dogs")
    expect("plain unchanged", resolve_target_name("Bleach"), "Bleach")

    print("\nis_content_file:")
    expect("cbz", is_content_file("Ch.001 - Torture 1.cbz"), True)
    expect("cover", is_content_file("cover.jpg"), True)
    expect("details", is_content_file("details.json"), True)
    expect("sidecar .aio", is_content_file(".aio_series.json"), False)
    expect("dot-cover", is_content_file(".cover.webp"), False)
    expect("stray json", is_content_file("something.json"), False)

    print("\nalias inversion is a bijection (no PC name maps twice):")
    expect("PC_TO_TABLET_ALIAS size == source size",
           len(PC_TO_TABLET_ALIAS), len(pat.ALIASES_TABLET_TO_PC))

    print("\nbuild_plan diff logic (synthetic):")
    pf_same = PCFile("a.cbz", Path("x/a.cbz"), 100, 1.0, sha256="AAA")
    pf_chg = PCFile("b.cbz", Path("x/b.cbz"), 200, 1.0, sha256="BBB")
    pf_new = PCFile("c.cbz", Path("x/c.cbz"), 50, 1.0, sha256="CCC")
    series = [("SeriesX", Path("x"), [pf_same, pf_chg, pf_new])]
    tablet_files = {"SeriesX/a.cbz": 100, "SeriesX/b.cbz": 200,
                    "SeriesX/old.cbz": 10}
    tablet_dirs = {"SeriesX"}
    state = {"files": {
        "SeriesX/a.cbz": {"size": 100, "sha256": "AAA"},       # unchanged -> skip
        "SeriesX/b.cbz": {"size": 200, "sha256": "OLD"},       # hash differs -> push
        "SeriesX/old.cbz": {"size": 10, "sha256": "ZZZ"},      # gone from PC -> delete
    }}
    plans, preserved, orphaned, warns = build_plan(
        series, tablet_files, tablet_dirs, state, only=set(), skip=set())
    assert len(plans) == 1, plans
    sp = plans[0]
    got_push = sorted(f.rel for f in sp.to_push)
    expect("push = changed + new", got_push, ["b.cbz", "c.cbz"])
    expect("delete = removed chapter", sorted(sp.to_delete), ["old.cbz"])

    print("\nbuild_plan preserve vs orphan:")
    # A tablet folder with no PC source and no record -> preserved.
    # A recorded folder whose PC series vanished -> orphaned.
    series2 = [("Bleach", Path("x"), [pf_new])]
    tf2 = {"Bleach/c.cbz": 50, "SHELTER/only.cbz": 1}
    td2 = {"Bleach", "SHELTER", "GhostSeries"}
    st2 = {"files": {"GhostSeries/x.cbz": {"size": 1, "sha256": "Q"}}}
    _pl, pres, orph, _w = build_plan(series2, tf2, td2, st2, only=set(), skip=set())
    expect("SHELTER preserved", "SHELTER" in pres, True)
    expect("GhostSeries orphaned", "GhostSeries" in orph, True)
    expect("Bleach not preserved", "Bleach" in pres, False)

    print("\n_chunk_files respects the count cap:")
    many = [PCFile(f"{i}.cbz", Path(f"d/{i}.cbz"), 1, 1.0) for i in range(120)]
    chunks = _chunk_files(many)
    expect("all files chunked", sum(len(c) for c in chunks), 120)
    expect("no chunk over cap", max(len(c) for c in chunks) <= MAX_BATCH_FILES, True)

    print("\n_is_ascii routing on the SOURCE PATH (non-ASCII path must NOT batch):")
    expect("ascii path", _is_ascii(r"D:\AIO\manga\Bleach\Ch.001 - x.cbz"), True)
    expect("non-ascii filename", _is_ascii(r"D:\AIO\manga\Cuckoos\Ch.232 - It’s Harder.cbz"), False)
    # The regression the first push hit: ASCII filename, non-ASCII SERIES FOLDER.
    expect("non-ascii source folder, ascii file",
           _is_ascii(r"D:\AIO\manga\SPY×FAMILY\Ch.001 - Mission 1.cbz"), False)
    expect("non-ascii dest target still fine to compute", _is_ascii("SPY_x_FAMILY"), True)

    print(f"\n{fails} failure(s).")
    return 0 if fails == 0 else 1


# ============================================================================
# CLI
# ============================================================================


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="sync_to_tablet",
        description="File-level, content-hash, resumable PC->tablet manga mirror.",
    )
    p.add_argument("--plan", action="store_true",
                   help="Print the plan and exit (default).")
    p.add_argument("--apply", action="store_true",
                   help="Execute the plan after a confirmation prompt.")
    p.add_argument("--yes", "-y", action="store_true",
                   help="Skip the apply confirmation prompt.")
    p.add_argument("--verify", action="store_true",
                   help="Re-hash every tablet file and rebuild the record from "
                        "ground truth before planning (slow; use on first run).")
    p.add_argument("--fast", action="store_true",
                   help="Trust the (size,mtime) PC hash cache instead of "
                        "re-hashing the whole PC library.")
    p.add_argument("--prune", action="store_true",
                   help="With --apply, also rm -rf orphaned folders (recorded "
                        "here but whose PC series no longer exists).")
    p.add_argument("--only", action="append", default=[], metavar="PC_FOLDER",
                   help="Only sync this PC folder name. Repeatable.")
    p.add_argument("--skip", action="append", default=[], metavar="PC_FOLDER",
                   help="Skip this PC folder name. Repeatable.")
    p.add_argument("--device", default=None, help="adb device serial override.")
    p.add_argument("--workers", type=int, default=8,
                   help="PC hashing thread count (default 8).")
    p.add_argument("--state", type=Path, default=None,
                   help="State record path (default .sync_state-<device>.json).")
    p.add_argument("--pc-cache", type=Path, default=SCRIPT_DIR / ".pc_hash_cache.json",
                   help="PC hash cache path (for --fast).")
    p.add_argument("--log", type=Path, default=None, help="Apply log path.")
    p.add_argument("--self-test", action="store_true",
                   help="Run pure-function self-tests and exit.")
    return p


def main(argv: list[str]) -> int:
    args = build_parser().parse_args(argv)

    if args.self_test:
        return run_self_test()

    try:
        adb = cm.resolve_adb(None)
        device = cm.resolve_device(adb, args.device)
    except Exception as e:
        sys.stderr.write(f"ERROR: {e}\n")
        return 2
    if not PC_ROOT.is_dir():
        sys.stderr.write(f"ERROR: PC root not found: {PC_ROOT}\n")
        return 2

    sys.stderr.write(f"adb: {adb}\ndevice: {device}\n")
    state_path = args.state or state_path_for(device)
    state = load_state(state_path, device)
    state_seeded = bool(state["files"])

    sys.stderr.write("Scanning PC library...\n")
    pc_series = scan_pc(PC_ROOT)

    sys.stderr.write("Hashing PC files"
                     + (" (--fast: using cache where possible)" if args.fast else "")
                     + "...\n")
    cache = load_pc_cache(args.pc_cache)
    n_hashed, n_cached, hbytes = hash_pc_files(
        pc_series, use_cache=args.fast, cache=cache,
        workers=max(1, args.workers), progress=True,
    )
    save_pc_cache(args.pc_cache, cache)
    sys.stderr.write(f"  hashed {n_hashed} file(s) ({_fmt_bytes(hbytes)}), "
                     f"{n_cached} from cache.\n")

    sys.stderr.write("Listing tablet...\n")
    try:
        tablet_files, tablet_dirs = list_tablet_state(adb, device)
    except Exception as e:
        sys.stderr.write(f"ERROR: tablet listing failed: {e}\n")
        return 2

    if args.verify:
        # Managed = every current PC target (unfiltered by --only/--skip, so
        # verify adopts the whole tablet truth, not just the sync subset).
        managed = {resolve_target_name(folder) for folder, _p, _f in pc_series}
        verify_rebuild_state(adb, device, state, tablet_files, tablet_dirs,
                             managed, state_path)
        state_seeded = bool(state["files"])

    only = set(args.only)
    skip = set(args.skip)
    plans, preserved, orphaned, warnings = build_plan(
        pc_series, tablet_files, tablet_dirs, state, only=only, skip=skip)

    print_plan(plans, preserved, orphaned, warnings,
               n_pc=len(pc_series), n_tablet_dirs=len(tablet_dirs),
               verify=args.verify, state_seeded=state_seeded)

    if not args.apply:
        return 0

    if not (plans or (args.prune and orphaned)):
        sys.stderr.write("Nothing to apply.\n")
        return 0

    if not args.yes:
        push_files = sum(len(p.to_push) for p in plans)
        del_files = sum(len(p.to_delete) for p in plans)
        prune_note = f", PRUNE {len(orphaned)} folder(s)" if (args.prune and orphaned) else ""
        print(f"\nThis will PUSH {push_files} file(s), DELETE {del_files} file(s)"
              f"{prune_note} on device {device}. Type 'yes' to proceed:")
        if input("> ").strip().lower() not in ("yes", "y"):
            print("Aborted.")
            return 3

    log_path = args.log or (SCRIPT_DIR / f"sync-log-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json")
    n_ok, n_fail = apply_plan(plans, adb, device, state, state_path, log_path)

    if args.prune and orphaned:
        sys.stderr.write(f"\nPruning {len(orphaned)} orphaned folder(s)...\n")
        prune_orphans(adb, device, orphaned, state, state_path)

    return 0 if n_fail == 0 else 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

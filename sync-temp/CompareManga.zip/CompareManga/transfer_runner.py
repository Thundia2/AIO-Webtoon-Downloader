"""
transfer_runner.py — batch transfer orchestration over manga_ops.

Owns the worker thread, the in-memory _TRANSFERS map, the SSE event
queue, and the one-batch-at-a-time interlock.

Public surface:
  - TransferOp                          frozen dataclass
  - TransferState                       mutable dataclass with queue + cancel
  - start_transfer(...)                 spawn worker; raises RuntimeError('busy')
  - cancel_transfer(id)                 cooperatively cancel a running transfer
  - get_transfer(id)                    lookup
  - iter_events(id, *, heartbeat_sec)   generator for SSE consumption

Depends on manga_ops for push_chapter / delete_tablet_file. Knows nothing
about Flask; the Flask layer turns iter_events output into SSE frames.

State retention: completed transfers stay in _TRANSFERS until the process
restarts. Personal-tool scale — no eviction policy in v1.
"""

from __future__ import annotations

import queue
import secrets
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

import manga_ops
from manga_ops import TransferError


@dataclass(frozen=True)
class TransferOp:
    """One unit of work in a batch.

    `tablet_path` is interpreted by op kind:
      - "push":   destination DIRECTORY on the tablet (file lands as
                  <tablet_path>/<pc_path.name>)
      - "delete": full FILE path on the tablet to remove
    """
    op: str                       # "push" | "delete"
    series_key: str               # normalized series name
    label: str                    # canonicalized chapter label
    pc_path: Path | None          # source for push; None for delete
    tablet_path: str
    bytes: int                    # known size in bytes
    display: str                  # human label, e.g. "Bleach Ch 61.1"


@dataclass
class TransferState:
    id: str
    ops: list[TransferOp]
    status: str = "queued"        # queued | running | done | cancelled | aborted_errors
    current_index: int = 0
    succeeded: int = 0
    failed: int = 0
    started_at: float = 0.0
    finished_at: float | None = None
    cancel_event: threading.Event = field(default_factory=threading.Event)
    _q: queue.Queue = field(default_factory=lambda: queue.Queue(maxsize=4096))


# Module-level registry; guarded by _TRANSFERS_LOCK.
_TRANSFERS: dict[str, TransferState] = {}
_TRANSFERS_LOCK = threading.Lock()

_TERMINAL_TYPES = frozenset({
    "batch_done", "batch_cancelled", "batch_aborted_due_to_errors",
})

# Per-op progress throttling: emit at most one file_progress per this
# interval (unless percent jumps to 100 — that always passes).
_PROGRESS_MIN_INTERVAL = 0.2


def get_transfer(transfer_id: str) -> TransferState | None:
    with _TRANSFERS_LOCK:
        return _TRANSFERS.get(transfer_id)


def start_transfer(
    ops: list[TransferOp],
    *,
    adb_exe: str,
    device: str,
    tablet_root: str,
    error_budget: int = 3,
) -> TransferState:
    """Spawn a daemon worker thread to run `ops`. One batch at a time
    globally — raises RuntimeError('busy') if another transfer is
    currently running. State is registered before thread start so callers
    can attach via get_transfer / iter_events immediately."""
    if not ops:
        raise ValueError("no ops to transfer")
    with _TRANSFERS_LOCK:
        for st in _TRANSFERS.values():
            if st.status == "running":
                raise RuntimeError("busy")
        state = TransferState(
            id=secrets.token_hex(8),
            ops=list(ops),
            status="running",
            started_at=time.time(),
        )
        _TRANSFERS[state.id] = state
    t = threading.Thread(
        target=_worker_main,
        args=(state, adb_exe, device, tablet_root, error_budget),
        name=f"transfer-{state.id}",
        daemon=True,
    )
    t.start()
    return state


def cancel_transfer(transfer_id: str) -> bool:
    """Signal cooperative cancellation. Returns True if the transfer was
    found and running."""
    state = get_transfer(transfer_id)
    if state is None or state.status != "running":
        return False
    state.cancel_event.set()
    return True


def iter_events(transfer_id: str, *, heartbeat_sec: float = 15.0):
    """Generator yielding events from `transfer_id`'s queue.

    Emits {"type":"heartbeat"} every `heartbeat_sec` while idle so SSE
    proxies don't time out. Returns after a terminal event is yielded
    OR when the queue's sentinel (None) is reached. Handles GeneratorExit
    (client disconnect) without cancelling the worker — the transfer
    continues server-side and can be re-attached in a future revision.
    """
    state = get_transfer(transfer_id)
    if state is None:
        return
    try:
        while True:
            try:
                evt = state._q.get(timeout=heartbeat_sec)
            except queue.Empty:
                yield {"type": "heartbeat"}
                continue
            if evt is None:  # sentinel
                return
            yield evt
            if evt.get("type") in _TERMINAL_TYPES:
                return
    except GeneratorExit:
        return


# --- worker -------------------------------------------------------------------


def _emit(state: TransferState, type_: str, **fields) -> None:
    """Put one event on the queue.

    file_progress events drop silently on Full (non-critical).
    All other events block up to 30 s — if the consumer is truly gone we
    accept the loss rather than wedge the worker forever.
    """
    evt = {"type": type_, **fields}
    if type_ == "file_progress":
        try:
            state._q.put_nowait(evt)
        except queue.Full:
            pass
    else:
        try:
            state._q.put(evt, timeout=30.0)
        except queue.Full:
            pass


def _worker_main(
    state: TransferState,
    adb_exe: str,
    device: str,
    tablet_root: str,
    error_budget: int,
) -> None:
    total_files = len(state.ops)
    total_bytes = sum(op.bytes for op in state.ops)
    _emit(state, "batch_start", total_files=total_files, total_bytes=total_bytes)

    consecutive_failures = 0
    recent_errors: list[str] = []

    try:
        for i, op in enumerate(state.ops):
            state.current_index = i
            if state.cancel_event.is_set():
                _emit(state, "batch_cancelled")
                state.status = "cancelled"
                return

            _emit(state, "file_start", label=op.display, op=op.op, bytes=op.bytes)
            ok, err = _run_one_op(state, op, adb_exe, device, tablet_root)

            if ok:
                state.succeeded += 1
                consecutive_failures = 0
                _emit(state, "file_done", label=op.display, ok=True)
            else:
                state.failed += 1
                consecutive_failures += 1
                recent_errors.append(err or "")
                if len(recent_errors) > 3:
                    del recent_errors[:-3]
                _emit(state, "file_done", label=op.display, ok=False, error=err or "")

                if state.cancel_event.is_set():
                    # The failure was probably the cancel signal terminating
                    # the subprocess. Surface as a clean cancellation.
                    _emit(state, "batch_cancelled")
                    state.status = "cancelled"
                    return

                if consecutive_failures >= error_budget:
                    _emit(
                        state, "batch_aborted_due_to_errors",
                        consecutive_failures=consecutive_failures,
                        errors=list(recent_errors),
                    )
                    state.status = "aborted_errors"
                    return

        _emit(state, "batch_done", succeeded=state.succeeded, failed=state.failed)
        state.status = "done"
    finally:
        state.finished_at = time.time()
        # Sentinel terminates iter_events even if a consumer attaches late.
        try:
            state._q.put_nowait(None)
        except queue.Full:
            pass


def _run_one_op(
    state: TransferState,
    op: TransferOp,
    adb_exe: str,
    device: str,
    tablet_root: str,
) -> tuple[bool, str | None]:
    """Execute one op. Returns (ok, error_message_or_None)."""
    last_emit_t = [0.0]
    last_pct = [-1]

    def on_progress(pct: int, bytes_done: int) -> None:
        if pct == last_pct[0]:
            return
        now = time.monotonic()
        if pct != 100 and (now - last_emit_t[0]) < _PROGRESS_MIN_INTERVAL:
            return
        last_pct[0] = pct
        last_emit_t[0] = now
        _emit(state, "file_progress", label=op.display, pct=pct, bytes_done=bytes_done)

    try:
        if op.op == "push":
            if op.pc_path is None:
                return (False, "push op missing pc_path")
            manga_ops.mkdir_p_on_tablet(
                adb_exe, device, op.tablet_path, root=tablet_root,
            )
            manga_ops.push_chapter(
                adb_exe, device,
                op.pc_path, op.tablet_path,
                root=tablet_root,
                on_progress=on_progress,
                cancel_event=state.cancel_event,
            )
        elif op.op == "delete":
            manga_ops.delete_tablet_file(
                adb_exe, device, op.tablet_path, root=tablet_root,
            )
            on_progress(100, op.bytes)
        else:
            return (False, f"unknown op: {op.op!r}")
        return (True, None)
    except TransferError as e:
        msg = str(e)
        if e.stderr_tail:
            msg = f"{msg} ({e.stderr_tail.strip()[:200]})"
        return (False, msg)
    except Exception as e:
        return (False, f"{type(e).__name__}: {e}")

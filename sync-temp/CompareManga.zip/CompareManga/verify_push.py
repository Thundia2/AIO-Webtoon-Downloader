"""
verify_push.py — Post-push verification of the PC -> tablet mirror.

Reads the most recent transfer-log-*.json plus a fresh PC + tablet scan, and
reports:
  - Series that failed during apply (from the log).
  - Series where tablet chapter count != PC chapter count (a non-zero diff is
    informational rather than fatal — many series have known sub-chapter
    splits or numbering differences documented in DELTA_FINDINGS.md).
  - Tablet folders whose name doesn't match an expected target (sanity check
    for the rename step).
  - SHELTER (the lone preserved tablet-only series) still exists.

Exit 0 if all push ops in the log succeeded AND SHELTER is preserved.
Exit 1 otherwise.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import compare_manga as cm
import push_all_to_tablet as pat


def latest_log() -> Path | None:
    candidates = sorted(
        Path(__file__).resolve().parent.glob("transfer-log-*.json"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    return candidates[0] if candidates else None


def main() -> int:
    log = latest_log()
    if log is None:
        print("ERROR: no transfer-log-*.json found in script dir")
        return 1
    print(f"log:      {log.name}")
    with open(log, "r", encoding="utf-8") as f:
        data = json.load(f)
    print(f"started:  {data.get('started_at_iso')}")
    print(f"finished: {data.get('completed_at_iso')}")
    print(f"results:  {data['n_ok']} ok, {data['n_fail']} failed "
          f"(of {len(data['results'])} ops)")
    print()

    failures = [r for r in data["results"] if not r.get("ok")]
    if failures:
        print(f"FAILURES ({len(failures)}):")
        for f_ in failures:
            print(f"  {f_['series']}")
            print(f"    target: {f_['target']}")
            print(f"    error:  {f_.get('error')}")
        print()

    # Fresh scans
    print("Re-scanning PC + tablet for cross-check...")
    pc = pat.scan_pc()
    adb = pat.adb_exe()
    device = pat.adb_device(adb, None)
    tablet, _, _, _ = cm.scan_tablet_library(
        adb, device, pat.TABLET_ROOT,
        Path(__file__).resolve().parent / ".tablet_cache.json",
        refresh=True, ttl_hours=0,
    )
    tablet_names = {t.folder_name for t in tablet}

    # Build expected targets from a fresh plan
    tablet_folders_list = sorted(tablet_names, key=str.casefold)
    entries, tablet_only, alias_errors = pat.build_plan(pc, tablet_folders_list)

    # Expected targets after a successful apply
    expected_targets = {e.target_tablet_name for e in entries}
    expected_targets |= set(tablet_only)  # preserved
    print(f"PC series:               {len(pc)}")
    print(f"Plan target tablet folders: {len(expected_targets)}")
    print(f"Tablet folders present:  {len(tablet_names)}")
    print()

    missing_on_tablet = expected_targets - tablet_names
    extra_on_tablet = tablet_names - expected_targets

    if missing_on_tablet:
        print(f"MISSING ON TABLET (expected but absent): {len(missing_on_tablet)}")
        for n in sorted(missing_on_tablet):
            print(f"  {n}")
        print()

    if extra_on_tablet:
        print(f"EXTRA ON TABLET (present but not in plan): {len(extra_on_tablet)}")
        for n in sorted(extra_on_tablet):
            print(f"  {n}")
        print()

    # Chapter count comparison
    pc_by_norm = {}
    for s in pc:
        pc_by_norm.setdefault(cm.normalize_series_name(s.folder_name), []).append(s)

    mismatches: list[tuple[str, int, int]] = []
    for e in entries:
        ts = next((t for t in tablet if t.folder_name == e.target_tablet_name),
                  None)
        if ts is None:
            continue
        tab_ch = sum(
            1 for cf in ts.chapter_files
            if "/" not in cf.filename and cf.fmt.lower() in ("pdf", "cbz")
        )
        # PC chapter count from canonical
        pc_canon_ch = e.pc_chapter_count
        if tab_ch != pc_canon_ch:
            mismatches.append((e.target_tablet_name, pc_canon_ch, tab_ch))

    if mismatches:
        print(f"CHAPTER COUNT MISMATCHES POST-PUSH ({len(mismatches)}):")
        print("  series                                                       PCch  tabCh    Δ")
        for name, pc_ch, tab_ch in sorted(mismatches, key=lambda x: abs(x[2] - x[1]), reverse=True):
            short = name[:55] + "..." if len(name) > 58 else name
            print(f"  {short:<58}  {pc_ch:>5}  {tab_ch:>5}  {tab_ch - pc_ch:>+4}")
        print()

    if "SHELTER" in tablet_names:
        sh = next(t for t in tablet if t.folder_name == "SHELTER")
        n = sum(1 for cf in sh.chapter_files
                if "/" not in cf.filename and cf.fmt.lower() in ("pdf", "cbz"))
        print(f"SHELTER preserved: yes ({n} chapters)")
    else:
        print("SHELTER preserved: NO -- FAIL")
        return 1

    if not failures and not missing_on_tablet:
        print("\nVERIFICATION: all push ops succeeded, all targets present.")
        return 0
    else:
        print("\nVERIFICATION: discrepancies above; review failure list.")
        return 1


if __name__ == "__main__":
    sys.exit(main())

Snapshot of D:/AIO/manga (the AIO library root on the user's PC).
23106 files listed in tree.tsv; 479 depth-2 sidecar files copied under sidecars/.
Chapter archives and covers are listed, never copied.
